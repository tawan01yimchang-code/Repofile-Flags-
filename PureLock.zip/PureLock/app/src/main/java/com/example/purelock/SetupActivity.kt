package com.example.purelock

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

class SetupActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setup)

        val pin1 = findViewById<TextInputEditText>(R.id.pin1)
        val pin2 = findViewById<TextInputEditText>(R.id.pin2)
        val layout1 = findViewById<TextInputLayout>(R.id.layout1)
        val layout2 = findViewById<TextInputLayout>(R.id.layout2)

        findViewById<View>(R.id.save).setOnClickListener {
            val p = pin1.text?.toString().orEmpty()
            val c = pin2.text?.toString().orEmpty()
            layout1.error = null
            layout2.error = null
            when {
                !Regex("\\d{4,6}").matches(p) -> layout1.error = getString(R.string.pin_invalid)
                p != c -> layout2.error = getString(R.string.pin_mismatch)
                else -> {
                    PinStore.save(this, p)
                    startActivity(
                        Intent(this, HomeActivity::class.java)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                    )
                    finish()
                }
            }
        }
    }
}
