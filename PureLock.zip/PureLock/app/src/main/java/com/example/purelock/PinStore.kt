package com.example.purelock

import android.content.Context
import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom

object PinStore {
    private const val FILE = "purelock"

    private fun prefs(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    private fun hash(salt: String, pin: String): String {
        val d = MessageDigest.getInstance("SHA-256").digest((salt + pin).toByteArray())
        return Base64.encodeToString(d, Base64.NO_WRAP)
    }

    fun isSet(c: Context) = prefs(c).contains("hash")

    fun length(c: Context) = prefs(c).getInt("len", 0)

    fun save(c: Context, pin: String) {
        val saltBytes = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val salt = Base64.encodeToString(saltBytes, Base64.NO_WRAP)
        prefs(c).edit()
            .putString("salt", salt)
            .putString("hash", hash(salt, pin))
            .putInt("len", pin.length)
            .apply()
    }

    fun verify(c: Context, pin: String): Boolean {
        val p = prefs(c)
        val salt = p.getString("salt", null) ?: return false
        return hash(salt, pin) == p.getString("hash", null)
    }
}
