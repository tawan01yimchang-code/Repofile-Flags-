package com.example.purelock

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Restarts the always-on service after reboot / app update. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (LockState.isEnabled(c) && LockState.canOverlay(c) && PinStore.isSet(c)) {
            try { LockService.start(c) } catch (_: Exception) { }
        }
    }
}
