package com.example.purelock

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.LayoutInflater
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.materialswitch.MaterialSwitch

/** Main app screen: always-on switch, permissions, clock customization, PIN. */
class HomeActivity : AppCompatActivity() {

    private class PermRow(val desc: TextView, val btn: MaterialButton)

    private lateinit var sw: MaterialSwitch
    private lateinit var statusText: TextView
    private lateinit var overlayRow: PermRow
    private lateinit var notifRow: PermRow
    private lateinit var batteryRow: PermRow
    private var syncing = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!PinStore.isSet(this)) {
            startActivity(Intent(this, SetupActivity::class.java))
            finish()
            return
        }
        setContentView(R.layout.activity_home)

        sw = findViewById(R.id.switchEnable)
        statusText = findViewById(R.id.statusText)
        val container = findViewById<LinearLayout>(R.id.permContainer)

        overlayRow = addPerm(container, R.string.perm_overlay, R.string.perm_overlay_desc) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        notifRow = addPerm(container, R.string.perm_notif, R.string.perm_notif_desc) {
            if (Build.VERSION.SDK_INT >= 33) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
        }
        batteryRow = addPerm(container, R.string.perm_battery, R.string.perm_battery_desc) {
            try {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                )
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }

        sw.setOnCheckedChangeListener { _, on ->
            if (syncing) return@setOnCheckedChangeListener
            if (on) enable() else disable()
        }

        val swAod = findViewById<MaterialSwitch>(R.id.switchAod)
        swAod.isChecked = LockState.aodEnabled(this)
        swAod.setOnCheckedChangeListener { _, v -> LockState.setAodEnabled(this, v) }
        val grp = findViewById<MaterialButtonToggleGroup>(R.id.aodDuration)
        val secs = mapOf(R.id.aod15 to 15, R.id.aod30 to 30, R.id.aod60 to 60, R.id.aod300 to 300)
        secs.entries.firstOrNull { it.value == LockState.aodSeconds(this) }?.let { grp.check(it.key) }
        grp.addOnButtonCheckedListener { _, id, checked ->
            if (checked) secs[id]?.let { LockState.setAodSeconds(this, it) }
        }

        findViewById<MaterialButton>(R.id.btnClock).setOnClickListener {
            startActivity(Intent(this, ClockSettingsActivity::class.java))
        }
        findViewById<MaterialButton>(R.id.btnChange).setOnClickListener {
            startActivity(Intent(this, SetupActivity::class.java))
        }
        findViewById<MaterialButton>(R.id.btnTest).setOnClickListener {
            LockLauncher.show(this, 0, false)
        }
    }

    override fun onResume() {
        super.onResume()
        if (::sw.isInitialized) refresh()
    }

    private fun addPerm(parent: LinearLayout, title: Int, desc: Int, onClick: () -> Unit): PermRow {
        val v = LayoutInflater.from(this).inflate(R.layout.item_perm, parent, false)
        v.findViewById<TextView>(R.id.permTitle).setText(title)
        val d = v.findViewById<TextView>(R.id.permDesc)
        d.setText(desc)
        val b = v.findViewById<MaterialButton>(R.id.permBtn)
        b.setOnClickListener { onClick() }
        parent.addView(v)
        return PermRow(d, b)
    }

    private fun notifGranted() =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

    private fun batteryOk() =
        getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)

    private fun setRow(row: PermRow, ok: Boolean) {
        row.btn.isEnabled = !ok
        row.btn.setText(if (ok) R.string.granted else R.string.grant)
    }

    private fun setSwitch(v: Boolean) {
        syncing = true
        sw.isChecked = v
        syncing = false
    }

    private fun enable() {
        if (!LockState.canOverlay(this)) {
            Toast.makeText(this, R.string.need_overlay, Toast.LENGTH_LONG).show()
            setSwitch(false)
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        if (!notifGranted() && Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        LockState.setEnabled(this, true)
        LockService.start(this)
        refresh()
    }

    private fun disable() {
        LockState.setEnabled(this, false)
        LockService.stop(this)
        refresh()
    }

    private fun refresh() {
        val overlay = LockState.canOverlay(this)
        setRow(overlayRow, overlay)
        setRow(notifRow, notifGranted())
        setRow(batteryRow, batteryOk())

        if (LockState.isEnabled(this) && !overlay) {
            LockState.setEnabled(this, false)
            LockService.stop(this)
        }
        val on = LockState.isEnabled(this)
        setSwitch(on)
        statusText.setText(if (on) R.string.status_on else R.string.status_off)
        if (on) {
            try { LockService.start(this) } catch (_: Exception) { }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (::sw.isInitialized) refresh()
    }
}
