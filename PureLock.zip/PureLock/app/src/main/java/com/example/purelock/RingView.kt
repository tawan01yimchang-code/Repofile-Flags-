package com.example.purelock

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

/** Thin ring with a sweeping arc, used by the fake fingerprint scan. */
class RingView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) :
    View(context, attrs) {

    var sweep = 0f            // 0..1
        set(v) { field = v; invalidate() }
    var ringColor = Color.argb(90, 255, 255, 255)
        set(v) { field = v; invalidate() }
    var arcColor = Color.WHITE
        set(v) { field = v; invalidate() }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val r = RectF()

    override fun onDraw(c: Canvas) {
        val w = resources.displayMetrics.density * 3f
        p.strokeWidth = w
        r.set(w, w, width - w, height - w)
        p.color = ringColor
        c.drawOval(r, p)
        if (sweep > 0f) {
            p.color = arcColor
            c.drawArc(r, -90f, 360f * sweep, false, p)
        }
    }
}
