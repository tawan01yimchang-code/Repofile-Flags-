package com.example.purelock

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.provider.Settings

object LockState {
    /** true from the moment the screen turned off until the PIN was entered. */
    @Volatile var locked = false

    private const val FILE = "purelock"

    fun isEnabled(c: Context) =
        c.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean("enabled", false)

    fun setEnabled(c: Context, v: Boolean) {
        c.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putBoolean("enabled", v).apply()
    }

    fun canOverlay(c: Context) = Settings.canDrawOverlays(c)
}

object LockLauncher {
    private val handler = Handler(Looper.getMainLooper())

    fun show(c: Context, delayMs: Long = 0L) {
        val app = c.applicationContext
        if (!PinStore.isSet(app)) return
        LockState.locked = true
        val run = Runnable {
            try {
                app.startActivity(
                    Intent(app, LockActivity::class.java).addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_CLEAR_TOP or
                            Intent.FLAG_ACTIVITY_NO_ANIMATION
                    )
                )
            } catch (_: Exception) { }
        }
        if (delayMs > 0) handler.postDelayed(run, delayMs) else run.run()
    }
}
