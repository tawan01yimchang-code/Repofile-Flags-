package com.example.purelock

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.provider.Settings

object LockState {
    /** true from the moment the screen turned off until the PIN was entered. */
    @Volatile var locked = false

    /** Away-on-display screen is currently showing. */
    @Volatile var aodActive = false

    /** AOD timed out; do not start it again until the user touches the screen. */
    @Volatile var aodSuppressed = false

    private const val FILE = "purelock"

    fun isEnabled(c: Context) =
        c.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean("enabled", false)

    fun setEnabled(c: Context, v: Boolean) {
        c.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putBoolean("enabled", v).apply()
    }

    fun aodEnabled(c: Context) =
        c.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean("aod", false)

    fun setAodEnabled(c: Context, v: Boolean) {
        c.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putBoolean("aod", v).apply()
    }

    fun aodSeconds(c: Context) =
        c.getSharedPreferences(FILE, Context.MODE_PRIVATE).getInt("aod_sec", 30)

    fun setAodSeconds(c: Context, v: Int) {
        c.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putInt("aod_sec", v).apply()
    }

    fun canOverlay(c: Context) = Settings.canDrawOverlays(c)
}

object LockLauncher {
    private val handler = Handler(Looper.getMainLooper())

    fun show(c: Context, delayMs: Long = 0L, allowAod: Boolean = true) {
        val app = c.applicationContext
        if (!PinStore.isSet(app)) return
        LockState.locked = true
        // AOD only for a normal screen-off, not when the user pressed power during AOD
        val aod = allowAod && LockState.aodEnabled(app) && !LockState.aodActive && !LockState.aodSuppressed
        val run = Runnable {
            try {
                app.startActivity(
                    Intent(app, LockActivity::class.java).putExtra("aod", aod).addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_CLEAR_TOP or
                            Intent.FLAG_ACTIVITY_NO_ANIMATION
                    )
                )
            } catch (_: Exception) { }
        }
        if (delayMs > 0) handler.postDelayed(run, delayMs) else run.run()
    }
}
