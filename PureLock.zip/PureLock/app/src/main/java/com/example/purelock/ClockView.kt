package com.example.purelock

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.util.AttributeSet
import android.util.TypedValue
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/**
 * Self-drawn clock. Styles: digital, stacked (hour over minute), analog.
 * Digits animate one by one when they change (slide / fade / pop).
 */
class ClockView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) :
    View(context, attrs) {

    private var cfg = ClockConfig()
    private var color = Color.WHITE

    private val tPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private val bounds = Rect()

    private val cal: Calendar = Calendar.getInstance()
    private var dateFmt = SimpleDateFormat(ClockPrefs.DATE_FORMATS[0], Locale.getDefault())
    private var lines: List<String> = emptyList()
    private var prevLines: List<String> = emptyList()
    private var dateText = ""
    private var lastSecond = -1L

    private var animT = 1f
    private var floatY = 0f
    private var floatAnim: ValueAnimator? = null
    private val changeAnim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 420
        interpolator = DecelerateInterpolator()
        addUpdateListener { animT = it.animatedValue as Float; invalidate() }
    }

    // layout results
    private var layoutW = -1
    private var pad = 0f
    private var timeSize = 0f
    private var secSize = 0f
    private var base1 = 0f
    private var base2 = 0f
    private var base3 = 0f
    private var dateSize = 0f
    private var dateBase = 0f
    private var analogD = 0f
    private var analogCx = 0f
    private var analogCy = 0f
    private var totalH = 0f

    private fun dp(v: Float) = v * resources.displayMetrics.density
    private fun sp(v: Float) =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, resources.displayMetrics)

    fun setConfig(c: ClockConfig, accent: Int) {
        cfg = c
        color = accent
        dateFmt = SimpleDateFormat(ClockPrefs.DATE_FORMATS[c.dateFormat], Locale.getDefault())
        tPaint.typeface = ClockPrefs.typeface(c.font)
        dPaint.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        cal.timeInMillis = System.currentTimeMillis()
        lines = buildLines()
        prevLines = lines
        animT = 1f
        lastSecond = -1L
        layoutW = -1
        updateDate(force = true)
        updateFloat()
        requestLayout()
        invalidate()
        if (isAttachedToWindow) { removeCallbacks(ticker); post(ticker) }
    }

    // ---------------- time ----------------
    private fun buildLines(): List<String> {
        val h24 = cal.get(Calendar.HOUR_OF_DAY)
        val m = cal.get(Calendar.MINUTE)
        val s = cal.get(Calendar.SECOND)
        val h12 = (h24 % 12).let { if (it == 0) 12 else it }
        val mm = String.format(Locale.US, "%02d", m)
        val ss = String.format(Locale.US, "%02d", s)
        return when (cfg.style) {
            0 -> {
                val hs = if (cfg.hour24) String.format(Locale.US, "%02d", h24) else h12.toString()
                listOf("$hs:$mm" + if (cfg.seconds) ":$ss" else "")
            }
            1 -> {
                val hs = String.format(Locale.US, "%02d", if (cfg.hour24) h24 else h12)
                if (cfg.seconds) listOf(hs, mm, ss) else listOf(hs, mm)
            }
            else -> emptyList()
        }
    }

    private fun updateDate(force: Boolean) {
        val sec = cal.timeInMillis / 1000L
        if (!force && sec == lastSecond) return
        lastSecond = sec
        dateText = if (cfg.showDate) dateFmt.format(cal.time) else ""
    }

    private fun update() {
        cal.timeInMillis = System.currentTimeMillis()
        val nl = buildLines()
        if (nl != lines) {
            prevLines = lines
            lines = nl
            if (cfg.anim != 0 && cfg.style != 2 && prevLines.isNotEmpty()) {
                changeAnim.cancel()
                changeAnim.start()
            } else {
                animT = 1f
            }
        }
        updateDate(force = false)
        invalidate()
    }

    private val ticker = object : Runnable {
        override fun run() {
            update()
            if (cfg.style == 2 && cfg.seconds && cfg.anim != 0) {
                postOnAnimation(this)
            } else {
                postDelayed(this, 1000L - System.currentTimeMillis() % 1000L + 3L)
            }
        }
    }

    private fun updateFloat() {
        floatAnim?.cancel()
        floatAnim = null
        floatY = 0f
        if (cfg.floating && isAttachedToWindow) {
            floatAnim = ValueAnimator.ofFloat(-1f, 1f).apply {
                duration = 3200
                repeatMode = ValueAnimator.REVERSE
                repeatCount = ValueAnimator.INFINITE
                interpolator = AccelerateDecelerateInterpolator()
                addUpdateListener { floatY = (it.animatedValue as Float) * dp(5f); invalidate() }
                start()
            }
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        removeCallbacks(ticker)
        post(ticker)
        updateFloat()
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(ticker)
        changeAnim.cancel()
        floatAnim?.cancel()
        super.onDetachedFromWindow()
    }

    // ---------------- layout ----------------
    private fun digitW(): Float {
        var m = 0f
        for (c in '0'..'9') m = max(m, tPaint.measureText(c.toString()))
        return m
    }

    private fun adv(ch: Char, dw: Float): Float =
        if (ch.isDigit()) dw else tPaint.measureText(ch.toString())

    private fun lineWidth(s: String, size: Float): Float {
        tPaint.textSize = size
        val dw = digitW()
        var w = 0f
        for (ch in s) w += adv(ch, dw)
        return w
    }

    private fun digitHeight(size: Float): Float {
        tPaint.textSize = size
        tPaint.getTextBounds("0", 0, 1, bounds)
        return (-bounds.top).toFloat()
    }

    private fun computeLayout(w: Int) {
        layoutW = w
        pad = dp(28f)
        val avail = max(w - 2 * pad, dp(80f))
        val scale = cfg.scale / 100f
        tPaint.typeface = ClockPrefs.typeface(cfg.font)

        var y = dp(10f)
        when (cfg.style) {
            2 -> {
                analogD = min(avail, dp(240f) * scale)
                analogCy = y + analogD / 2f
                analogCx = when (cfg.align) {
                    0 -> pad + analogD / 2f
                    2 -> w - pad - analogD / 2f
                    else -> w / 2f
                }
                y += analogD
            }
            1 -> {
                val fit = avail * 100f / lineWidth("00", 100f)
                timeSize = min(sp(112f) * scale, fit)
                val h = digitHeight(timeSize)
                base1 = y + h
                base2 = base1 + h * 1.18f
                y = base2
                if (cfg.seconds) {
                    secSize = timeSize * 0.28f
                    val h3 = digitHeight(secSize)
                    base3 = base2 + timeSize * 0.12f + h3
                    y = base3
                }
            }
            else -> {
                val probe = if (cfg.seconds) "00:00:00" else "00:00"
                val fit = avail * 100f / lineWidth(probe, 100f)
                timeSize = min(sp(84f) * scale, fit)
                base1 = y + digitHeight(timeSize)
                y = base1
            }
        }
        dateSize = sp(15f) * (0.85f + 0.15f * scale)
        dPaint.textSize = dateSize
        if (cfg.showDate) {
            dateBase = y + dp(14f) + dateSize * 0.8f
            y = dateBase + dPaint.descent()
        }
        totalH = y + dp(14f)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        if (w != layoutW) computeLayout(w)
        setMeasuredDimension(w, ceil(totalH).toInt())
    }

    // ---------------- drawing ----------------
    private fun glyph(c: Canvas, s: String, x: Float, y: Float, alpha: Float) {
        tPaint.color = color
        tPaint.alpha = (alpha.coerceIn(0f, 1f) * 255f).toInt()
        c.drawText(s, x, y, tPaint)
    }

    private fun drawLine(c: Canvas, cur: String, prev: String, size: Float, baseline: Float) {
        tPaint.textSize = size
        val dw = digitW()
        var total = 0f
        for (ch in cur) total += adv(ch, dw)
        var x = when (cfg.align) {
            0 -> pad
            2 -> layoutW - pad - total
            else -> (layoutW - total) / 2f
        }
        val off = cur.length - prev.length
        val t = animT
        val animating = t < 1f && cfg.anim != 0
        for (i in cur.indices) {
            val ch = cur[i]
            val a = adv(ch, dw)
            val gx = x + (a - tPaint.measureText(ch.toString())) / 2f
            val pi = i - off
            val pch = if (animating && pi in prev.indices) prev[pi] else ch
            if (animating && pch != ch) {
                val pgx = x + (a - tPaint.measureText(pch.toString())) / 2f
                when (cfg.anim) {
                    1 -> {
                        val travel = size * 0.28f
                        glyph(c, pch.toString(), pgx, baseline - travel * t, 1f - t)
                        glyph(c, ch.toString(), gx, baseline + travel * (1f - t), t)
                    }
                    2 -> {
                        glyph(c, pch.toString(), pgx, baseline, 1f - t)
                        glyph(c, ch.toString(), gx, baseline, t)
                    }
                    else -> {
                        glyph(c, pch.toString(), pgx, baseline, 1f - t * 2f)
                        val sc = 0.5f + 0.5f * t
                        c.save()
                        c.scale(sc, sc, x + a / 2f, baseline - size * 0.35f)
                        glyph(c, ch.toString(), gx, baseline, t)
                        c.restore()
                    }
                }
            } else {
                glyph(c, ch.toString(), gx, baseline, 1f)
            }
            x += a
        }
    }

    private fun prevOf(i: Int): String = prevLines.getOrNull(i) ?: lines[i]

    override fun onDraw(canvas: Canvas) {
        if (layoutW != width && width > 0) computeLayout(width)
        canvas.save()
        canvas.translate(0f, floatY)

        if (cfg.shadow) {
            val sh = Color.argb(150, 0, 0, 0)
            tPaint.setShadowLayer(dp(8f), 0f, dp(2f), sh)
            dPaint.setShadowLayer(dp(6f), 0f, dp(1f), sh)
        } else {
            tPaint.clearShadowLayer()
            dPaint.clearShadowLayer()
        }

        when (cfg.style) {
            2 -> drawAnalog(canvas)
            1 -> {
                if (lines.size >= 2) {
                    drawLine(canvas, lines[0], prevOf(0), timeSize, base1)
                    drawLine(canvas, lines[1], prevOf(1), timeSize, base2)
                    if (lines.size >= 3) drawLine(canvas, lines[2], prevOf(2), secSize, base3)
                }
            }
            else -> if (lines.isNotEmpty()) drawLine(canvas, lines[0], prevOf(0), timeSize, base1)
        }

        if (cfg.showDate && dateText.isNotEmpty()) {
            dPaint.textSize = dateSize
            dPaint.color = color
            dPaint.alpha = 225
            val w = dPaint.measureText(dateText)
            val x = when (cfg.align) {
                0 -> pad
                2 -> layoutW - pad - w
                else -> (layoutW - w) / 2f
            }
            canvas.drawText(dateText, x, dateBase, dPaint)
        }
        canvas.restore()
    }

    private fun hand(c: Canvas, cx: Float, cy: Float, deg: Float, len: Float, tail: Float, w: Float, alpha: Int) {
        sPaint.style = Paint.Style.STROKE
        sPaint.strokeWidth = w
        sPaint.color = color
        sPaint.alpha = alpha
        c.save()
        c.rotate(deg, cx, cy)
        c.drawLine(cx, cy + tail, cx, cy - len, sPaint)
        c.restore()
    }

    private fun drawAnalog(c: Canvas) {
        val r = analogD / 2f
        val cx = analogCx
        val cy = analogCy

        sPaint.style = Paint.Style.FILL
        sPaint.color = Color.argb(70, 0, 0, 0)
        c.drawCircle(cx, cy, r, sPaint)

        sPaint.style = Paint.Style.STROKE
        sPaint.strokeWidth = dp(2f)
        sPaint.color = color
        sPaint.alpha = 160
        c.drawCircle(cx, cy, r - dp(1f), sPaint)

        for (i in 0 until 60) {
            val big = i % 5 == 0
            val len = if (big) r * 0.12f else r * 0.05f
            sPaint.strokeWidth = if (big) dp(3f) else dp(1.2f)
            sPaint.color = color
            sPaint.alpha = if (big) 255 else 120
            c.save()
            c.rotate(i * 6f, cx, cy)
            val top = cy - r + dp(9f)
            c.drawLine(cx, top, cx, top + len, sPaint)
            c.restore()
        }

        val smooth = cfg.anim != 0
        val secRaw = cal.get(Calendar.SECOND) + cal.get(Calendar.MILLISECOND) / 1000f
        val sec = if (smooth && cfg.seconds) secRaw else floor(secRaw)
        val minute = cal.get(Calendar.MINUTE) + sec / 60f
        val hour = cal.get(Calendar.HOUR) + minute / 60f

        hand(c, cx, cy, hour * 30f, r * 0.50f, r * 0.06f, dp(6f), 255)
        hand(c, cx, cy, minute * 6f, r * 0.74f, r * 0.08f, dp(4f), 255)
        if (cfg.seconds) hand(c, cx, cy, sec * 6f, r * 0.82f, r * 0.16f, dp(1.8f), 190)

        sPaint.style = Paint.Style.FILL
        sPaint.color = color
        sPaint.alpha = 255
        c.drawCircle(cx, cy, dp(5f), sPaint)
    }
}
