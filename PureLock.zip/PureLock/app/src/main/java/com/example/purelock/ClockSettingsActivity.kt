package com.example.purelock

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.color.MaterialColors
import com.google.android.material.materialswitch.MaterialSwitch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Free customization of the lock-screen clock, with a live preview on top. */
class ClockSettingsActivity : AppCompatActivity() {

    private lateinit var cfg: ClockConfig
    private lateinit var preview: ClockView
    private val swatches = mutableListOf<Pair<View, Int>>() // view to palette index (-1 = Material You)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = getString(R.string.clock_settings)
        cfg = ClockPrefs.load(this)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(32))
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(MaterialColors.getColor(this@ClockSettingsActivity,
                com.google.android.material.R.attr.colorSurface, Color.BLACK))
            fitsSystemWindows = true
            isFillViewport = true
            addView(col, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        setContentView(scroll)

        // ---- live preview ----
        val frame = FrameLayout(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#0F1B26"), Color.parseColor("#33485C"))
            ).apply { cornerRadius = dp(28).toFloat() }
            minimumHeight = dp(220)
        }
        preview = ClockView(this)
        frame.addView(preview, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        col.addView(frame, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        preview.setConfig(cfg, resolveColor(cfg))

        // ---- style ----
        section(col, R.string.s_style)
        col.addView(toggle(
            listOf(R.string.style_digital, R.string.style_stacked, R.string.style_analog), cfg.style
        ) { update(cfg.copy(style = it)) })

        // ---- font ----
        section(col, R.string.s_font)
        col.addView(chips(ClockPrefs.FONTS.map { it.first }, cfg.font) { update(cfg.copy(font = it)) })

        // ---- size ----
        col.addView(seek(R.string.s_size, 60, 130, cfg.scale, { "$it%" }) { update(cfg.copy(scale = it)) })

        // ---- colour ----
        section(col, R.string.s_color)
        col.addView(swatchRow())
        col.addView(seek(R.string.s_color_custom, 0, 360, cfg.hue, { "$it°" }) { h ->
            val c = Color.HSVToColor(floatArrayOf(h.toFloat(), 0.55f, 1f))
            update(cfg.copy(colorSystem = false, color = c, hue = h))
            refreshSwatches()
        })

        // ---- date ----
        col.addView(switchRow(R.string.s_show_date, cfg.showDate) { update(cfg.copy(showDate = it)) })
        val now = Date()
        val dateNames = ClockPrefs.DATE_FORMATS.map { SimpleDateFormat(it, Locale.getDefault()).format(now) }
        section(col, R.string.s_date_format)
        col.addView(chips(dateNames, cfg.dateFormat) { update(cfg.copy(dateFormat = it)) })

        // ---- toggles ----
        col.addView(switchRow(R.string.s_seconds, cfg.seconds) { update(cfg.copy(seconds = it)) })
        col.addView(switchRow(R.string.s_hour24, cfg.hour24) { update(cfg.copy(hour24 = it)) })
        col.addView(switchRow(R.string.s_shadow, cfg.shadow) { update(cfg.copy(shadow = it)) })
        col.addView(switchRow(R.string.s_float, cfg.floating) { update(cfg.copy(floating = it)) })

        // ---- layout ----
        section(col, R.string.s_align)
        col.addView(toggle(
            listOf(R.string.align_left, R.string.align_center, R.string.align_right), cfg.align
        ) { update(cfg.copy(align = it)) })
        col.addView(seek(R.string.s_position, 0, 50, cfg.posY, { "$it%" }) { update(cfg.copy(posY = it)) })

        // ---- animation ----
        section(col, R.string.s_anim)
        col.addView(toggle(
            listOf(R.string.anim_none, R.string.anim_slide, R.string.anim_fade, R.string.anim_pop), cfg.anim
        ) { update(cfg.copy(anim = it)) })

        col.addView(seek(R.string.s_dim, 0, 80, cfg.dim, { "$it%" }) { update(cfg.copy(dim = it)) })

        section(col, R.string.s_aod)
        col.addView(switchRow(R.string.s_aod_enable, cfg.aod) { update(cfg.copy(aod = it)) })
        col.addView(switchRow(R.string.s_fake_fingerprint, cfg.fakeFingerprint) { update(cfg.copy(fakeFingerprint = it)) })
        col.addView(seek(R.string.s_fingerprint_size, 56, 120, cfg.fingerprintSize, { "$it dp" }) {
            update(cfg.copy(fingerprintSize = it))
        })

        // ---- actions ----
        col.addView(MaterialButton(this).apply {
            setText(R.string.test_lock)
            setOnClickListener { LockLauncher.show(this@ClockSettingsActivity) }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)).apply { topMargin = dp(24) })

        col.addView(MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            setText(R.string.s_reset)
            setOnClickListener {
                ClockPrefs.reset(this@ClockSettingsActivity)
                recreate()
            }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)).apply { topMargin = dp(10) })
    }

    // ---------------- state ----------------
    private fun resolveColor(c: ClockConfig) = if (c.colorSystem) ClockPrefs.accent(this) else c.color

    private fun update(n: ClockConfig) {
        cfg = n
        ClockPrefs.save(this, n)
        preview.setConfig(n, resolveColor(n))
    }

    // ---------------- widgets ----------------
    private fun section(parent: LinearLayout, text: Int) {
        parent.addView(TextView(this).apply {
            setText(text)
            textSize = 14f
            setTextColor(MaterialColors.getColor(this@ClockSettingsActivity,
                com.google.android.material.R.attr.colorPrimary, Color.WHITE))
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(22); bottomMargin = dp(8) })
    }

    private fun toggle(labels: List<Int>, selected: Int, onSel: (Int) -> Unit): MaterialButtonToggleGroup {
        val g = MaterialButtonToggleGroup(this).apply {
            isSingleSelection = true
            isSelectionRequired = true
        }
        val ids = labels.map { View.generateViewId() }
        labels.forEachIndexed { i, res ->
            val b = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
                id = ids[i]
                setText(res)
                maxLines = 1
            }
            g.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        g.check(ids[selected.coerceIn(0, ids.lastIndex)])
        g.addOnButtonCheckedListener { _, id, checked ->
            if (checked) onSel(ids.indexOf(id))
        }
        return g
    }

    private fun chips(names: List<String>, selected: Int, onSel: (Int) -> Unit): View {
        val group = ChipGroup(this).apply {
            isSingleLine = true
            isSingleSelection = true
            isSelectionRequired = true
        }
        val ids = names.map { View.generateViewId() }
        names.forEachIndexed { i, n ->
            val chip = LayoutInflater.from(this).inflate(R.layout.item_chip, group, false) as Chip
            chip.id = ids[i]
            chip.text = n
            group.addView(chip)
        }
        group.check(ids[selected.coerceIn(0, ids.lastIndex)])
        group.setOnCheckedStateChangeListener { _, checked ->
            val id = checked.firstOrNull() ?: return@setOnCheckedStateChangeListener
            onSel(ids.indexOf(id))
        }
        return HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(group)
        }
    }

    private fun seek(label: Int, minV: Int, maxV: Int, value: Int, fmt: (Int) -> String, onChange: (Int) -> Unit): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val name = TextView(this).apply { setText(label); textSize = 15f }
        val valueText = TextView(this).apply { text = fmt(value); textSize = 15f }
        row.addView(name, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(valueText)
        val bar = SeekBar(this).apply {
            max = maxV - minV
            progress = value - minV
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    valueText.text = fmt(p + minV)
                    if (fromUser) onChange(p + minV)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        box.addView(row)
        box.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        box.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(16) }
        return box
    }

    private fun switchRow(label: Int, checked: Boolean, onChange: (Boolean) -> Unit): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        row.addView(TextView(this).apply { setText(label); textSize = 16f },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(MaterialSwitch(this).apply {
            isChecked = checked
            setOnCheckedChangeListener { _, v -> onChange(v) }
        })
        row.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(12) }
        return row
    }

    private fun swatchRow(): View {
        swatches.clear()
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val entries = listOf(-1) + ClockPrefs.PALETTE.indices.toList()
        for (idx in entries) {
            val v = View(this)
            swatches += v to idx
            v.setOnClickListener {
                update(
                    if (idx == -1) cfg.copy(colorSystem = true)
                    else cfg.copy(colorSystem = false, color = ClockPrefs.PALETTE[idx])
                )
                refreshSwatches()
            }
            row.addView(v, LinearLayout.LayoutParams(dp(44), dp(44)).apply { rightMargin = dp(10) })
        }
        refreshSwatches()
        return HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(row)
        }
    }

    private fun refreshSwatches() {
        val outline = MaterialColors.getColor(this,
            com.google.android.material.R.attr.colorOnSurface, Color.WHITE)
        for ((v, idx) in swatches) {
            val c = if (idx == -1) ClockPrefs.accent(this) else ClockPrefs.PALETTE[idx]
            val selected = if (idx == -1) cfg.colorSystem else (!cfg.colorSystem && cfg.color == c)
            v.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(c)
                setStroke(if (selected) dp(3) else dp(1), if (selected) outline else Color.argb(90, 128, 128, 128))
            }
        }
    }
}
