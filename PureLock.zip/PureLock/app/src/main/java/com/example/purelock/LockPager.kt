package com.example.purelock

import android.animation.ValueAnimator
import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import kotlin.math.abs

/**
 * Two full-screen pages in one container: the clock page is always in place and
 * the PIN page slides up from the bottom, following the finger (progress 0..1).
 */
class LockPager @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) :
    FrameLayout(context, attrs) {

    var pinPage: View? = null
        set(v) { field = v; applyProgress(progress) }
    var onProgress: ((Float) -> Unit)? = null
    var swipeEnabled = true

    var progress = 0f
        private set

    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private var downX = 0f
    private var downY = 0f
    private var baseP = 0f
    private var dragging = false
    private var tracker: VelocityTracker? = null
    private var settleAnim: ValueAnimator? = null

    private fun applyProgress(p: Float) {
        progress = p
        pinPage?.let {
            it.visibility = if (p > 0f) View.VISIBLE else View.INVISIBLE
            it.translationY = (1f - p) * height
        }
        onProgress?.invoke(p)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        applyProgress(progress)
    }

    fun open(animated: Boolean = true) = settle(1f, animated)
    fun close(animated: Boolean = true) = settle(0f, animated)

    private fun settle(target: Float, animated: Boolean) {
        settleAnim?.cancel()
        if (!animated || abs(progress - target) < 0.001f) {
            applyProgress(target)
            return
        }
        settleAnim = ValueAnimator.ofFloat(progress, target).apply {
            duration = (abs(progress - target) * 320f).toLong() + 100L
            interpolator = DecelerateInterpolator(1.6f)
            addUpdateListener { applyProgress(it.animatedValue as Float) }
            start()
        }
    }

    private fun isDragStart(ev: MotionEvent): Boolean {
        val dy = ev.y - downY
        val dx = ev.x - downX
        if (abs(dy) <= slop || abs(dy) <= abs(dx)) return false
        return if (baseP > 0.5f) dy > 0 else dy < 0
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.x; downY = ev.y
                baseP = progress
                dragging = false
                settleAnim?.cancel()
                tracker?.recycle()
                tracker = VelocityTracker.obtain().also { it.addMovement(ev) }
            }
            MotionEvent.ACTION_MOVE -> {
                tracker?.addMovement(ev)
                if (!dragging && swipeEnabled && isDragStart(ev)) {
                    dragging = true
                    parent?.requestDisallowInterceptTouchEvent(true)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (!dragging) { tracker?.recycle(); tracker = null }
            }
        }
        return dragging
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (tracker == null) tracker = VelocityTracker.obtain()
                downX = ev.x; downY = ev.y
                baseP = progress
                tracker?.addMovement(ev)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                tracker?.addMovement(ev)
                if (!dragging && swipeEnabled && isDragStart(ev)) dragging = true
                if (dragging && height > 0) {
                    val p = (baseP - (ev.y - downY) / height).coerceIn(0f, 1f)
                    applyProgress(p)
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                tracker?.addMovement(ev)
                if (dragging) {
                    tracker?.computeCurrentVelocity(1000)
                    val vy = tracker?.yVelocity ?: 0f
                    val target = when {
                        vy < -900f -> 1f
                        vy > 900f -> 0f
                        progress > 0.5f -> 1f
                        else -> 0f
                    }
                    settle(target, true)
                }
                tracker?.recycle()
                tracker = null
                dragging = false
                return true
            }
        }
        return super.onTouchEvent(ev)
    }
}
