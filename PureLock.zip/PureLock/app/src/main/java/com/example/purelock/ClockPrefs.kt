package com.example.purelock

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.text.format.DateFormat
import android.view.ContextThemeWrapper
import com.google.android.material.color.MaterialColors

/** Everything the user can change about the clock. */
data class ClockConfig(
    val style: Int = 0,              // 0 digital, 1 stacked, 2 analog
    val font: Int = 1,               // index in ClockPrefs.FONTS
    val scale: Int = 100,            // 60..130 (%)
    val colorSystem: Boolean = true, // true = Material You accent
    val color: Int = Color.WHITE,
    val hue: Int = 200,
    val showDate: Boolean = true,
    val dateFormat: Int = 0,
    val seconds: Boolean = false,
    val hour24: Boolean = true,
    val shadow: Boolean = true,
    val align: Int = 1,              // 0 left, 1 center, 2 right
    val posY: Int = 8,               // top margin, % of screen height
    val anim: Int = 1,               // 0 none, 1 slide, 2 fade, 3 pop
    val floating: Boolean = false,
    val dim: Int = 35                // wallpaper dimming %
)

object ClockPrefs {
    val FONTS = listOf(
        "Thin" to "sans-serif-thin",
        "Light" to "sans-serif-light",
        "Regular" to "sans-serif",
        "Medium" to "sans-serif-medium",
        "Black" to "sans-serif-black",
        "Condensed" to "sans-serif-condensed",
        "Serif" to "serif",
        "Mono" to "monospace",
        "Cursive" to "cursive",
        "Casual" to "casual"
    )
    val DATE_FORMATS = listOf("EEEE d MMMM", "EEE d MMM", "d MMMM yyyy", "dd/MM/yyyy", "MMM d")

    val PALETTE: List<Int> = listOf(
        "#FFFFFF", "#FFE082", "#FFAB91", "#F48FB1", "#CE93D8",
        "#90CAF9", "#80DEEA", "#A5D6A7", "#E6EE9C"
    ).map { Color.parseColor(it) }

    fun typeface(i: Int): Typeface =
        Typeface.create(FONTS[i.coerceIn(0, FONTS.lastIndex)].second, Typeface.NORMAL)

    /** Material You accent colour as the (dark) lock-screen theme sees it. */
    fun accent(c: Context): Int = MaterialColors.getColor(
        ContextThemeWrapper(c, R.style.Theme_PureLock_Lock),
        com.google.android.material.R.attr.colorPrimary,
        Color.WHITE
    )

    private fun p(c: Context) = c.getSharedPreferences("purelock_clock", Context.MODE_PRIVATE)

    fun load(c: Context): ClockConfig {
        val s = p(c)
        val d = ClockConfig()
        return ClockConfig(
            style = s.getInt("style", d.style),
            font = s.getInt("font", d.font).coerceIn(0, FONTS.lastIndex),
            scale = s.getInt("scale", d.scale),
            colorSystem = s.getBoolean("colorSystem", d.colorSystem),
            color = s.getInt("color", d.color),
            hue = s.getInt("hue", d.hue),
            showDate = s.getBoolean("showDate", d.showDate),
            dateFormat = s.getInt("dateFormat", d.dateFormat).coerceIn(0, DATE_FORMATS.lastIndex),
            seconds = s.getBoolean("seconds", d.seconds),
            hour24 = s.getBoolean("hour24", DateFormat.is24HourFormat(c)),
            shadow = s.getBoolean("shadow", d.shadow),
            align = s.getInt("align", d.align),
            posY = s.getInt("posY", d.posY),
            anim = s.getInt("anim", d.anim),
            floating = s.getBoolean("floating", d.floating),
            dim = s.getInt("dim", d.dim)
        )
    }

    fun save(c: Context, f: ClockConfig) {
        p(c).edit()
            .putInt("style", f.style).putInt("font", f.font).putInt("scale", f.scale)
            .putBoolean("colorSystem", f.colorSystem).putInt("color", f.color).putInt("hue", f.hue)
            .putBoolean("showDate", f.showDate).putInt("dateFormat", f.dateFormat)
            .putBoolean("seconds", f.seconds).putBoolean("hour24", f.hour24)
            .putBoolean("shadow", f.shadow).putInt("align", f.align).putInt("posY", f.posY)
            .putInt("anim", f.anim).putBoolean("floating", f.floating).putInt("dim", f.dim)
            .apply()
    }

    fun reset(c: Context) { p(c).edit().clear().apply() }
}
