package com.example.purelock

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.KeyguardManager
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.MediaStore
import android.graphics.Color
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.addCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.color.MaterialColors

/**
 * Page 1 = clock, page 2 = PIN. Swipe up to move from page 1 to page 2.
 * Correct PIN -> the phone's real home screen.
 */
class LockActivity : AppCompatActivity() {

    private lateinit var pager: LockPager
    private lateinit var scrim: View
    private lateinit var clockPage: View
    private lateinit var clockView: ClockView
    private lateinit var bottomBar: View
    private lateinit var hintBlock: View
    private lateinit var pinPage: View
    private lateinit var pinMessage: TextView
    private lateinit var dotsRow: LinearLayout
    private lateinit var keypad: LinearLayout
    private lateinit var hint: TextView
    private lateinit var fpHolder: View
    private lateinit var fpRing: RingView
    private lateinit var fpIcon: ImageView
    private var scanning = false
    private var scanAnim: ValueAnimator? = null
    private var pulseAnim: ObjectAnimator? = null

    private val handler = Handler(Looper.getMainLooper())
    private val pin = StringBuilder()
    private val keyViews = mutableListOf<View>()
    private val animItems = mutableListOf<View>()
    private var pinLen = 4
    private var baseDim = 0.35f
    private var keysShown = false
    private var failCount = 0
    private var lockedOut = false
    private var leaving = false
    private var allowLeave = false
    private var timer: CountDownTimer? = null
    private var hintAnim: ObjectAnimator? = null
    private lateinit var aodLayer: View
    private lateinit var aodClock: ClockView
    private val aodTimeout = Runnable { endAodTimer() }
    private val aodShift = object : Runnable {
        override fun run() {
            val r = java.util.Random()
            aodClock.translationX = (r.nextInt(41) - 20) * resources.displayMetrics.density
            aodClock.translationY = (r.nextInt(81) - 40) * resources.displayMetrics.density
            handler.postDelayed(this, 60_000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!PinStore.isSet(this)) {
            startActivity(Intent(this, SetupActivity::class.java))
            finish()
            return
        }

        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED)
        }
        LockState.locked = true

        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_lock)
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }

        pager = findViewById(R.id.root)
        scrim = findViewById(R.id.scrim)
        clockPage = findViewById(R.id.clockPage)
        clockView = findViewById(R.id.clockView)
        bottomBar = findViewById(R.id.bottomBar)
        hintBlock = findViewById(R.id.hintBlock)
        pinPage = findViewById(R.id.pinPage)
        pinMessage = findViewById(R.id.pinMessage)
        dotsRow = findViewById(R.id.dotsRow)
        keypad = findViewById(R.id.keypad)
        hint = findViewById(R.id.hint)
        fpHolder = findViewById(R.id.fpHolder)
        fpRing = findViewById(R.id.fpRing)
        fpIcon = findViewById(R.id.fpIcon)
        resetFingerprint()
        // touch down (or hold) starts the scan right away
        fpHolder.setOnTouchListener { v, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN) {
                v.isPressed = true
                startScan()
            } else if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) {
                v.isPressed = false
            }
            true
        }
        aodLayer = findViewById(R.id.aodLayer)
        aodClock = findViewById(R.id.aodClock)
        aodLayer.setOnClickListener { exitAod() }

        ViewCompat.setOnApplyWindowInsetsListener(pager) { _, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            clockPage.setPadding(b.left, b.top, b.right, b.bottom)
            pinPage.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }

        pinLen = PinStore.length(this).coerceIn(4, 6)
        buildDots()
        buildKeypad()
        animItems.clear()
        animItems += pinMessage
        animItems += dotsRow
        animItems += keyViews
        animItems += findViewById<View>(R.id.btnEmergency)
        resetKeys()

        pager.pinPage = pinPage
        pager.onProgress = { p -> onProgress(p) }

        findViewById<View>(R.id.btnCamera).setOnClickListener { openCamera() }
        findViewById<View>(R.id.btnPhone).setOnClickListener { safeStart(Intent(Intent.ACTION_DIAL)) }
        findViewById<View>(R.id.btnEmergency).setOnClickListener {
            safeStart(Intent(Intent.ACTION_DIAL, Uri.parse("tel:112")))
        }

        // Back: PIN page -> clock page. On the clock page it does nothing.
        onBackPressedDispatcher.addCallback(this) {
            if (pager.progress > 0f) pager.close()
        }

        applyConfig()
        playEntrance()
        if (intent.getBooleanExtra("aod", false) && LockState.aodEnabled(this)) enterAod()
    }

    override fun onUserInteraction() {
        super.onUserInteraction()
        LockState.aodSuppressed = false
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (!::pager.isInitialized) return
        leaving = false
        LockState.locked = true
        pin.clear()
        updateDots(false)
        resetFingerprint()
        pager.close(false)
        pager.alpha = 1f
        pager.scaleX = 1f
        pager.scaleY = 1f
        applyConfig()
        playEntrance()
        if (intent.getBooleanExtra("aod", false) && LockState.aodEnabled(this)) enterAod()
        else exitAod()
    }

    override fun onResume() {
        super.onResume()
        if (!::pager.isInitialized) return
        allowLeave = false
        if (!leaving) LockState.locked = true
        applyConfig()
        startHintBounce()
    }

    override fun onPause() {
        hintAnim?.cancel()
        super.onPause()
    }

    override fun onStop() {
        super.onStop()
        // Still locked and the user pressed Home/Recents -> put the lock screen back.
        if (::pager.isInitialized && LockState.locked && !isFinishing && !allowLeave) {
            val pm = getSystemService(PowerManager::class.java)
            if (pm.isInteractive) LockLauncher.show(this, 150, false)
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            WindowCompat.getInsetsController(window, window.decorView).apply {
                systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                hide(WindowInsetsCompat.Type.navigationBars())
            }
        }
    }

    // ---------- Away on display ----------
    private fun enterAod() {
        LockState.aodActive = true
        if (Build.VERSION.SDK_INT >= 27) {
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.attributes = window.attributes.also { it.screenBrightness = 0.01f }
        aodLayer.animate().cancel()
        aodLayer.alpha = 1f
        aodLayer.visibility = View.VISIBLE
        handler.removeCallbacks(aodTimeout)
        handler.postDelayed(aodTimeout, LockState.aodSeconds(this) * 1000L)
        handler.removeCallbacks(aodShift)
        aodShift.run()
    }

    /** Release the screen so it can turn off by itself; the layer stays black. */
    private fun releaseScreen() {
        handler.removeCallbacks(aodTimeout)
        handler.removeCallbacks(aodShift)
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.attributes = window.attributes.also {
            it.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        }
        if (Build.VERSION.SDK_INT >= 27) setTurnScreenOn(false)
        LockState.aodActive = false
    }

    private fun endAodTimer() {
        LockState.aodSuppressed = true
        releaseScreen()
    }

    private fun exitAod() {
        if (aodLayer.visibility != View.VISIBLE) return
        releaseScreen()
        aodLayer.animate().alpha(0f).setDuration(250).withEndAction {
            aodLayer.visibility = View.GONE
        }.start()
    }

    // ---------- helpers ----------
    private fun dp(v: Int): Float = v * resources.displayMetrics.density

    private fun attrColor(attr: Int): Int =
        MaterialColors.getColor(this, attr, android.graphics.Color.WHITE)

    private val cError get() = attrColor(com.google.android.material.R.attr.colorError)
    private val cOnSurfaceVariant get() = attrColor(com.google.android.material.R.attr.colorOnSurfaceVariant)

    private fun applyConfig() {
        val cfg = ClockPrefs.load(this)
        val color = if (cfg.colorSystem) attrColor(com.google.android.material.R.attr.colorPrimary) else cfg.color
        clockView.setConfig(cfg, color)
        val lp = clockView.layoutParams as FrameLayout.LayoutParams
        lp.topMargin = (resources.displayMetrics.heightPixels * cfg.posY / 100f).toInt()
        clockView.layoutParams = lp
        baseDim = cfg.dim / 100f
        fpHolder.visibility = if (cfg.fakeFingerprint) View.VISIBLE else View.GONE
        val dim = Color.rgb(
            (Color.red(color) * 0.65f).toInt(),
            (Color.green(color) * 0.65f).toInt(),
            (Color.blue(color) * 0.65f).toInt()
        )
        aodClock.setConfig(cfg.copy(shadow = false, seconds = false, anim = 0, floating = false), dim)
        onProgress(pager.progress)
    }

    private fun playEntrance() {
        clockView.animate().cancel()
        clockView.alpha = 0f
        clockView.translationY = dp(24)
        clockView.animate().alpha(1f).translationY(0f).setDuration(650)
            .setInterpolator(DecelerateInterpolator()).start()
        bottomBar.animate().cancel()
        bottomBar.alpha = 0f
        bottomBar.animate().alpha(1f).setStartDelay(250).setDuration(500).start()
    }

    private fun startHintBounce() {
        hintAnim?.cancel()
        hintBlock.translationY = 0f
        hintAnim = ObjectAnimator.ofFloat(hintBlock, "translationY", 0f, -dp(10)).apply {
            duration = 900
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
    }

    private fun safeStart(i: Intent) {
        allowLeave = true
        try { startActivity(i) } catch (_: ActivityNotFoundException) {
            allowLeave = false
            Toast.makeText(this, R.string.camera_missing, Toast.LENGTH_SHORT).show()
        }
    }

    private fun openCamera() {
        val intents = listOf(
            Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        for (i in intents) {
            allowLeave = true
            try { startActivity(i); return } catch (_: ActivityNotFoundException) { }
        }
        allowLeave = false
        Toast.makeText(this, R.string.camera_missing, Toast.LENGTH_SHORT).show()
    }

    private fun vibrateError() {
        try {
            val v: Vibrator = if (Build.VERSION.SDK_INT >= 31) {
                (getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            } else {
                @Suppress("DEPRECATION") (getSystemService(VIBRATOR_SERVICE) as Vibrator)
            }
            v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 40, 60, 40), -1))
        } catch (_: Exception) { }
    }

    private fun shake(v: View) {
        ObjectAnimator.ofFloat(v, "translationX", 0f, dp(16), -dp(16), dp(10), -dp(10), 0f)
            .setDuration(380).start()
    }

    // ---------- fake fingerprint (always "fails") ----------
    private fun resetFingerprint() {
        scanAnim?.cancel()
        pulseAnim?.cancel()
        scanning = false
        fpHolder.scaleX = 1f
        fpHolder.scaleY = 1f
        fpRing.sweep = 0f
        fpRing.arcColor = attrColor(com.google.android.material.R.attr.colorPrimary)
        fpIcon.setColorFilter(attrColor(com.google.android.material.R.attr.colorOnSecondaryContainer))
        hint.setText(R.string.swipe_hint)
    }

    private fun startScan() {
        if (scanning || leaving || pager.progress > 0f) return
        scanning = true
        val primary = attrColor(com.google.android.material.R.attr.colorPrimary)
        hint.setText(R.string.scanning)
        fpIcon.setColorFilter(primary)
        fpRing.arcColor = primary
        pulseAnim = ObjectAnimator.ofPropertyValuesHolder(
            fpHolder,
            android.animation.PropertyValuesHolder.ofFloat("scaleX", 1f, 1.1f),
            android.animation.PropertyValuesHolder.ofFloat("scaleY", 1f, 1.1f)
        ).apply {
            duration = 150
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            start()
        }
        scanAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 400
            interpolator = android.view.animation.LinearInterpolator()
            addUpdateListener { fpRing.sweep = it.animatedValue as Float }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(a: android.animation.Animator) { cancelled = true }
                override fun onAnimationEnd(a: android.animation.Animator) { if (!cancelled) scanFailed() }
            })
            start()
        }
    }

    private fun scanFailed() {
        pulseAnim?.cancel()
        fpHolder.scaleX = 1f
        fpHolder.scaleY = 1f
        vibrateError()
        fpIcon.setColorFilter(cError)
        fpRing.arcColor = cError
        fpRing.sweep = 1f
        hint.setText(R.string.fp_not_recognized)
        shake(fpHolder)
        handler.postDelayed({
            if (leaving) return@postDelayed
            pager.open()
            setMessage(getString(R.string.fp_failed_use_pin), true)
            resetFingerprint()
            hint.setText(R.string.fp_not_recognized)
        }, 500)
    }

    // ---------- page transition ----------
    private fun onProgress(p: Float) {
        scrim.alpha = baseDim + (maxOf(baseDim, 0.72f) - baseDim) * p
        clockPage.alpha = (1f - p * 1.4f).coerceIn(0f, 1f)
        clockPage.translationY = -p * dp(70)
        clockPage.scaleX = 1f - 0.06f * p
        clockPage.scaleY = 1f - 0.06f * p
        clockPage.visibility = if (p >= 1f) View.INVISIBLE else View.VISIBLE

        if (p <= 0f) {
            if (keysShown) {
                keysShown = false
                resetKeys()
                pin.clear()
                updateDots(false)
                setMessage(getString(R.string.enter_pin), false)
            }
        } else if (p >= 0.45f && !keysShown) {
            keysShown = true
            staggerKeys()
        }
    }

    private fun resetKeys() {
        animItems.forEach {
            it.animate().cancel()
            it.alpha = 0f
            it.translationY = dp(28)
        }
    }

    private fun staggerKeys() {
        animItems.forEachIndexed { i, v ->
            v.animate().cancel()
            v.alpha = 0f
            v.translationY = dp(28)
            v.animate().alpha(1f).translationY(0f)
                .setStartDelay(i * 22L).setDuration(260)
                .setInterpolator(DecelerateInterpolator()).start()
        }
    }

    // ---------- PIN ----------
    private fun setMessage(text: String, isError: Boolean) {
        pinMessage.text = text
        pinMessage.setTextColor(if (isError) cError else cOnSurfaceVariant)
    }

    private fun buildDots() {
        dotsRow.removeAllViews()
        val size = dp(14).toInt()
        val m = dp(8).toInt()
        repeat(pinLen) {
            val d = View(this)
            d.setBackgroundResource(R.drawable.dot_empty)
            dotsRow.addView(d, LinearLayout.LayoutParams(size, size).apply { setMargins(m, 0, m, 0) })
        }
    }

    private fun updateDots(pop: Boolean) {
        for (i in 0 until dotsRow.childCount) {
            val d = dotsRow.getChildAt(i)
            val filled = i < pin.length
            d.setBackgroundResource(if (filled) R.drawable.dot else R.drawable.dot_empty)
            if (pop && filled && i == pin.length - 1) {
                d.scaleX = 0.4f
                d.scaleY = 0.4f
                d.animate().scaleX(1f).scaleY(1f).setDuration(220)
                    .setInterpolator(OvershootInterpolator(3f)).start()
            } else {
                d.scaleX = 1f
                d.scaleY = 1f
            }
        }
    }

    private fun buildKeypad() {
        keypad.removeAllViews()
        keyViews.clear()
        val rows = listOf(
            listOf("1", "2", "3"),
            listOf("4", "5", "6"),
            listOf("7", "8", "9"),
            listOf("", "0", "<")
        )
        for (r in rows) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            for (k in r) {
                val b = layoutInflater.inflate(R.layout.key_button, row, false) as MaterialButton
                when (k) {
                    "" -> {
                        b.visibility = View.INVISIBLE
                        b.isEnabled = false
                    }
                    "<" -> {
                        b.setIconResource(R.drawable.ic_backspace)
                        b.contentDescription = getString(R.string.delete)
                        b.setOnLongClickListener { pin.clear(); updateDots(false); true }
                    }
                    else -> b.text = k
                }
                if (k.isNotEmpty()) {
                    b.setOnClickListener { onKey(k) }
                    b.setOnTouchListener { v, e ->
                        when (e.actionMasked) {
                            MotionEvent.ACTION_DOWN ->
                                v.animate().scaleX(0.88f).scaleY(0.88f).setDuration(80).start()
                            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                                v.animate().scaleX(1f).scaleY(1f).setDuration(160)
                                    .setInterpolator(OvershootInterpolator(2.5f)).start()
                        }
                        false
                    }
                }
                keyViews += b
                row.addView(b)
            }
            keypad.addView(row)
        }
    }

    private fun onKey(k: String) {
        if (lockedOut || leaving) return
        if (k == "<") {
            if (pin.isNotEmpty()) pin.deleteCharAt(pin.length - 1)
            updateDots(false)
            return
        }
        if (pin.length >= pinLen) return
        pin.append(k)
        updateDots(true)
        if (pin.length == pinLen) handler.postDelayed({ submit() }, 140)
    }

    private fun submit() {
        if (leaving || pin.length != pinLen) return
        if (PinStore.verify(this, pin.toString())) {
            failCount = 0
            unlock()
        } else {
            failCount++
            vibrateError()
            shake(dotsRow)
            setMessage(getString(R.string.pin_wrong), true)
            handler.postDelayed({ pin.clear(); updateDots(false) }, 380)
            if (failCount >= 5) startLockout()
        }
    }

    private fun startLockout() {
        lockedOut = true
        keyViews.forEach { it.alpha = 0.4f }
        timer = object : CountDownTimer(30_000, 1_000) {
            override fun onTick(ms: Long) {
                setMessage(getString(R.string.try_again_in, (ms / 1000 + 1).toInt()), true)
            }

            override fun onFinish() {
                lockedOut = false
                failCount = 0
                keyViews.forEach { it.alpha = 1f }
                setMessage(getString(R.string.enter_pin), false)
            }
        }.start()
    }

    // ---------- unlock -> real home screen ----------
    private fun unlock() {
        if (leaving) return
        leaving = true
        LockState.locked = false
        pager.animate().alpha(0f).scaleX(1.06f).scaleY(1.06f).setDuration(240)
            .setInterpolator(DecelerateInterpolator())
            .withEndAction { goHome() }.start()
    }

    private var homeStarted = false

    private fun goHome() {
        val km = getSystemService(KeyguardManager::class.java)
        if (km.isKeyguardLocked) {
            // dismiss the (non-secure) system keyguard that sits underneath us
            km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
                override fun onDismissSucceeded() { startHome() }
                override fun onDismissCancelled() { startHome() }
                override fun onDismissError() { startHome() }
            })
            handler.postDelayed({ startHome() }, 1500)
        } else {
            startHome()
        }
    }

    private fun startHome() {
        if (homeStarted) return
        homeStarted = true
        startActivity(
            Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        )
        finish()
        @Suppress("DEPRECATION")
        overridePendingTransition(0, android.R.anim.fade_out)
    }

    override fun onDestroy() {
        scanAnim?.cancel()
        pulseAnim?.cancel()
        if (LockState.aodActive) LockState.aodActive = false
        timer?.cancel()
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
