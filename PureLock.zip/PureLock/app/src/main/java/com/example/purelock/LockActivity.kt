package com.example.purelock

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.MediaStore
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.addCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.color.MaterialColors

class LockActivity : AppCompatActivity() {

    private lateinit var bottomBar: View
    private lateinit var hint: TextView
    private lateinit var fpHolder: View
    private lateinit var fpIcon: ImageView
    private lateinit var pinPanel: View
    private lateinit var pinMessage: TextView
    private lateinit var dotsRow: LinearLayout

    private val handler = Handler(Looper.getMainLooper())
    private val pin = StringBuilder()
    private val keyViews = mutableListOf<View>()
    private var scanning = false
    private var panelShown = false
    private var failCount = 0
    private var lockedOut = false
    private var timer: CountDownTimer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!PinStore.isSet(this)) {
            startActivity(Intent(this, SetupActivity::class.java))
            finish()
            return
        }

        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_lock)
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }

        val content = findViewById<View>(R.id.content)
        ViewCompat.setOnApplyWindowInsetsListener(content) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }

        bottomBar = findViewById(R.id.bottomBar)
        hint = findViewById(R.id.hint)
        fpHolder = findViewById(R.id.fpHolder)
        fpIcon = findViewById(R.id.fpIcon)
        pinPanel = findViewById(R.id.pinPanel)
        pinMessage = findViewById(R.id.pinMessage)
        dotsRow = findViewById(R.id.dotsRow)

        resetFingerprint()
        buildKeypad(findViewById(R.id.keypad))

        findViewById<View>(R.id.btnCamera).setOnClickListener { openCamera() }
        findViewById<View>(R.id.btnPhone).setOnClickListener { safeStart(Intent(Intent.ACTION_DIAL)) }
        findViewById<View>(R.id.btnEmergency).setOnClickListener {
            safeStart(Intent(Intent.ACTION_DIAL, Uri.parse("tel:112")))
        }
        fpHolder.setOnClickListener { startScan() }

        // Swipe up anywhere to open the PIN screen
        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (vy < -800f && !panelShown && !scanning) {
                    showPanel(getString(R.string.enter_pin), false)
                    return true
                }
                return false
            }
        })
        findViewById<View>(R.id.root).setOnTouchListener { _, e -> detector.onTouchEvent(e) }

        // Back goes from PIN screen to lock screen; on lock screen it does nothing
        onBackPressedDispatcher.addCallback(this) { if (panelShown && !scanning) hidePanel() }
    }

    // ---------- helpers ----------
    private fun dp(v: Int): Float = v * resources.displayMetrics.density

    private fun attrColor(attr: Int): Int =
        MaterialColors.getColor(this, attr, android.graphics.Color.WHITE)

    private val cPrimary get() = attrColor(com.google.android.material.R.attr.colorPrimary)
    private val cError get() = attrColor(com.google.android.material.R.attr.colorError)
    private val cOnSurface get() = attrColor(com.google.android.material.R.attr.colorOnSurface)
    private val cOnSurfaceVariant get() = attrColor(com.google.android.material.R.attr.colorOnSurfaceVariant)
    private val cOnSecondary get() = attrColor(com.google.android.material.R.attr.colorOnSecondaryContainer)

    private fun safeStart(i: Intent) {
        try { startActivity(i) } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, R.string.camera_missing, Toast.LENGTH_SHORT).show()
        }
    }

    private fun openCamera() {
        val intents = listOf(
            Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        for (i in intents) {
            try { startActivity(i); return } catch (_: ActivityNotFoundException) { }
        }
        Toast.makeText(this, R.string.camera_missing, Toast.LENGTH_SHORT).show()
    }

    private fun vibrateError() {
        try {
            val v: Vibrator = if (Build.VERSION.SDK_INT >= 31) {
                (getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            } else {
                @Suppress("DEPRECATION") (getSystemService(VIBRATOR_SERVICE) as Vibrator)
            }
            v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 40, 60, 40), -1))
        } catch (_: Exception) { }
    }

    private fun shake(v: View) {
        ObjectAnimator.ofFloat(v, "translationX", 0f, dp(16), -dp(16), dp(10), -dp(10), 0f)
            .setDuration(380).start()
    }

    // ---------- fake fingerprint ----------
    private fun resetFingerprint() {
        scanning = false
        fpIcon.setColorFilter(cOnSecondary)
        hint.setText(R.string.swipe_hint)
    }

    private fun startScan() {
        if (scanning || panelShown) return
        scanning = true
        hint.setText(R.string.scanning)
        fpIcon.setColorFilter(cPrimary)
        ObjectAnimator.ofPropertyValuesHolder(
            fpHolder,
            PropertyValuesHolder.ofFloat("scaleX", 1f, 1.12f),
            PropertyValuesHolder.ofFloat("scaleY", 1f, 1.12f)
        ).apply {
            duration = 225
            repeatCount = 3
            repeatMode = ValueAnimator.REVERSE
            start()
        }
        handler.postDelayed({ scanFailed() }, 900)
    }

    private fun scanFailed() {
        vibrateError()
        fpIcon.setColorFilter(cError)
        hint.setText(R.string.fp_not_recognized)
        shake(fpHolder)
        handler.postDelayed({
            showPanel(getString(R.string.fp_failed_use_pin), true)
            resetFingerprint()
            hint.setText(R.string.fp_not_recognized)
        }, 650)
    }

    // ---------- PIN panel ----------
    private fun showPanel(message: String, isError: Boolean) {
        setMessage(message, isError)
        if (panelShown) return
        panelShown = true
        pinPanel.visibility = View.VISIBLE
        pinPanel.alpha = 0f
        pinPanel.translationY = dp(120)
        pinPanel.animate().alpha(1f).translationY(0f).setDuration(280)
            .setInterpolator(DecelerateInterpolator()).start()
        bottomBar.animate().alpha(0f).setDuration(150)
            .withEndAction { if (panelShown) bottomBar.visibility = View.INVISIBLE }.start()
    }

    private fun hidePanel() {
        panelShown = false
        pin.clear()
        updateDots()
        pinPanel.animate().alpha(0f).translationY(dp(120)).setDuration(220)
            .withEndAction { if (!panelShown) pinPanel.visibility = View.GONE }.start()
        bottomBar.visibility = View.VISIBLE
        bottomBar.animate().alpha(1f).setDuration(220).start()
        resetFingerprint()
    }

    private fun setMessage(text: String, isError: Boolean) {
        pinMessage.text = text
        pinMessage.setTextColor(if (isError) cError else cOnSurfaceVariant)
    }

    private fun updateDots() {
        dotsRow.removeAllViews()
        val size = dp(12).toInt()
        val m = dp(6).toInt()
        repeat(pin.length) {
            val d = View(this)
            d.setBackgroundResource(R.drawable.dot)
            dotsRow.addView(d, LinearLayout.LayoutParams(size, size).apply { setMargins(m, 0, m, 0) })
        }
    }

    private fun buildKeypad(keypad: LinearLayout) {
        val rows = listOf(
            listOf("1", "2", "3"),
            listOf("4", "5", "6"),
            listOf("7", "8", "9"),
            listOf("<", "0", "ok")
        )
        for (r in rows) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            for (k in r) {
                val b = layoutInflater.inflate(R.layout.key_button, row, false) as MaterialButton
                when (k) {
                    "<" -> {
                        b.setIconResource(R.drawable.ic_backspace)
                        b.contentDescription = getString(R.string.delete)
                        b.setOnLongClickListener { pin.clear(); updateDots(); true }
                    }
                    "ok" -> {
                        b.setIconResource(R.drawable.ic_enter)
                        b.contentDescription = getString(R.string.confirm_key)
                        b.backgroundTintList = ColorStateList.valueOf(cPrimary)
                        b.iconTint = ColorStateList.valueOf(
                            attrColor(com.google.android.material.R.attr.colorOnPrimary)
                        )
                    }
                    else -> b.text = k
                }
                b.setOnClickListener { onKey(k) }
                keyViews += b
                row.addView(b)
            }
            keypad.addView(row)
        }
    }

    private fun onKey(k: String) {
        if (lockedOut) return
        when (k) {
            "<" -> if (pin.isNotEmpty()) pin.deleteCharAt(pin.length - 1)
            "ok" -> { submit(); return }
            else -> if (pin.length < 6) pin.append(k)
        }
        updateDots()
        if (k != "<" && pin.length == PinStore.length(this)) submit()
    }

    private fun submit() {
        if (pin.length < 4) {
            setMessage(getString(R.string.pin_too_short), true)
            shake(dotsRow)
            return
        }
        if (PinStore.verify(this, pin.toString())) {
            failCount = 0
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        } else {
            failCount++
            vibrateError()
            shake(dotsRow)
            setMessage(getString(R.string.pin_wrong), true)
            handler.postDelayed({ pin.clear(); updateDots() }, 380)
            if (failCount >= 5) startLockout()
        }
    }

    private fun startLockout() {
        lockedOut = true
        keyViews.forEach { it.alpha = 0.4f }
        timer = object : CountDownTimer(30_000, 1_000) {
            override fun onTick(ms: Long) {
                setMessage(getString(R.string.try_again_in, (ms / 1000 + 1).toInt()), true)
            }
            override fun onFinish() {
                lockedOut = false
                failCount = 0
                keyViews.forEach { it.alpha = 1f }
                setMessage(getString(R.string.enter_pin), false)
            }
        }.start()
    }

    override fun onDestroy() {
        timer?.cancel()
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
