# Pure Lock

Pure Android / LineageOS style lock screen (Material You, dynamic color from the system).

- PIN 4-6 digits (set on first launch, stored salted + hashed)
- Fake fingerprint in the center: tap it -> scan animation -> vibrates -> "not recognized" -> PIN screen
- Phone shortcut (left) and Camera shortcut (right)
- Swipe up to open the PIN screen, 5 wrong PINs = 30 s lockout
- Real wallpaper behind the lock screen

Build: open in Android Studio (Koala+) and Run, or push to GitHub and download the APK
from Actions (.github/workflows/build.yml).
