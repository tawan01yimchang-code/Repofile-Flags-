# Pure Lock

Lock screen app, Pure Android / Material You style.

## How it works
- Main app (HomeActivity): **Always on** switch, permission status, clock customization, change PIN, test lock.
- When "Always on" is enabled, a foreground service (`LockService`) listens for screen-off and
  shows the lock screen over the system keyguard every time. It restarts after reboot.
- Lock screen has **two separate pages**:
  1. Clock page (swipe up; phone + camera shortcuts)
  2. PIN page (slides up following your finger, animated keypad)
- Correct PIN -> the phone's real home screen (launcher).
- 5 wrong PINs = 30 s lockout.

## Clock customization (Main app -> Customize clock)
Style (digital / stacked / analog), 10 fonts, size, colour (Material You, palette, custom hue),
date on/off + 5 formats, seconds, 12/24h, shadow, gentle floating, alignment, vertical position,
digit animation (none / slide / fade / pop), wallpaper dimming. Live preview.

## Setup on the phone
1. Install, set a PIN.
2. Turn on **Always on**, allow "Display over other apps" (required), notifications, and
   set battery to Unrestricted.
3. Set the system screen lock to **None** or **Swipe** (otherwise two locks stack).

## Build
Open in Android Studio (Koala+) and Run, or push to GitHub and download the APK from Actions.
