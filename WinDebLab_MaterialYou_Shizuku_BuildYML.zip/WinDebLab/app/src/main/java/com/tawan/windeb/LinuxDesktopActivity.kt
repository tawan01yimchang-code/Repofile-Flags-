package com.tawan.windeb

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.content.pm.PackageManager
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import rikka.shizuku.Shizuku

class LinuxDesktopActivity : Activity() {
  private lateinit var status: TextView
  private lateinit var connectButton: Button
  private lateinit var startButton: Button
  private val requestCode = 4102

  private val permissionListener = Shizuku.OnRequestPermissionResultListener { code, result ->
    if (code == requestCode) refreshState(if (result == PackageManager.PERMISSION_GRANTED)
      "อนุญาต Shizuku แล้ว" else "ยังไม่ได้รับอนุญาต Shizuku")
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    window.statusBarColor = BG
    window.navigationBarColor = BG
    Shizuku.addRequestPermissionResultListener(permissionListener)

    val page = LinearLayout(this).apply {
      orientation = LinearLayout.VERTICAL
      setPadding(dp(18), dp(22), dp(18), dp(24))
      setBackgroundColor(BG)
    }
    page.addView(label("Linux Environment", 25f, ON_SURFACE, true))
    page.addView(label("Debian • XFCE Desktop", 14f, ACCENT, true).apply {
      setPadding(0, dp(4), 0, dp(18))
    })

    val panel = LinearLayout(this).apply {
      orientation = LinearLayout.VERTICAL
      setPadding(dp(16), dp(16), dp(16), dp(16))
      background = shape(CARD, 22, 1, OUTLINE)
    }
    panel.addView(label("การเชื่อมต่อ Shizuku", 17f, ON_SURFACE, true))
    panel.addView(label("ต้องเปิด Shizuku ผ่าน Wireless debugging หรือ ADB และอนุญาต WinDeb Lab ก่อน", 13f, MUTED).apply {
      setPadding(0, dp(7), 0, dp(12))
    })
    connectButton = Button(this).apply {
      text = "ตรวจสอบ / ขอสิทธิ์ Shizuku"
      isAllCaps = false
      setOnClickListener { connectShizuku() }
    }
    panel.addView(connectButton, LinearLayout.LayoutParams(MATCH_PARENT, dp(50)))
    page.addView(panel)

    val statePanel = LinearLayout(this).apply {
      orientation = LinearLayout.VERTICAL
      setPadding(dp(16), dp(14), dp(16), dp(14))
      background = shape(SURFACE, 18)
    }
    statePanel.addView(label("สถานะระบบ", 14f, ACCENT, true))
    status = label("กำลังตรวจสอบ Shizuku…", 13f, MUTED).apply { setPadding(0, dp(8), 0, 0) }
    statePanel.addView(status)
    page.addView(statePanel, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(14) })

    startButton = Button(this).apply {
      text = "Start Linux"
      isAllCaps = false
      setOnClickListener { startLinux() }
    }
    page.addView(startButton, LinearLayout.LayoutParams(MATCH_PARENT, dp(54)).apply { topMargin = dp(18) })

    page.addView(label(
      "ข้อกำหนดของ Linux runtime
Shizuku เป็นช่องทางเรียกคำสั่ง ADB Shell เท่านั้น ไม่ได้มี Debian หรือ proot ติดมาด้วย ตัวแพ็กเกจนี้ยังต้องเพิ่มชุดติดตั้ง proot และ Debian root filesystem แบบฝังในแอปก่อน จึงจะเริ่มเดสก์ท็อปจริงได้ โดยไม่ต้องใช้ Termux หรือแอป Terminal ภายนอก",
      12.5f, MUTED
    ).apply {
      setPadding(dp(4), dp(16), dp(4), dp(8))
    })
    setContentView(ScrollView(this).apply { addView(page) })
    refreshState()
  }

  private fun connectShizuku() {
    if (!Shizuku.pingBinder()) {
      status.text = "ไม่พบ Shizuku service กรุณาเปิดแอป Shizuku และเริ่มบริการก่อน"
      return
    }
    when {
      Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED ->
        refreshState("เชื่อมต่อ Shizuku และได้รับสิทธิ์แล้ว")
      Shizuku.shouldShowRequestPermissionRationale() ->
        Shizuku.requestPermission(requestCode)
      else -> Shizuku.requestPermission(requestCode)
    }
  }

  private fun refreshState(message: String? = null) {
    val connected = Shizuku.pingBinder()
    val granted = connected && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    status.text = message ?: when {
      !connected -> "ยังไม่พบ Shizuku service"
      granted -> "เชื่อมต่อแล้ว • ได้รับสิทธิ์ ADB Shell"
      else -> "พบ Shizuku แล้ว • รออนุญาตสิทธิ์"
    }
    startButton.isEnabled = granted
    startButton.alpha = if (granted) 1f else 0.55f
  }

  private fun startLinux() {
    if (!Shizuku.pingBinder() || Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
      connectShizuku()
      return
    }
    // Deliberately do not report a successful Linux launch until the embedded
    // proot + Debian rootfs runtime is shipped and initialized.
    status.text = "Shizuku พร้อมแล้ว แต่ยังเริ่ม Linux ไม่ได้: ยังไม่มี embedded proot และ Debian rootfs ในแพ็กเกจ"
  }

  override fun onDestroy() {
    Shizuku.removeRequestPermissionResultListener(permissionListener)
    super.onDestroy()
  }
}
