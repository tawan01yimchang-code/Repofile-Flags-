package com.tawan.windeb

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import com.google.android.material.button.MaterialButton
import com.google.android.material.color.DynamicColors
import rikka.shizuku.Shizuku

/** Linux control page: Shizuku connection, install Debian, open the terminal, install/start the XFCE desktop. */
class LinuxDesktopActivity : Activity() {
  private lateinit var p: Pal
  private lateinit var shizukuStatus: TextView
  private lateinit var linuxStatus: TextView
  private lateinit var desktopStatus: TextView
  private lateinit var progressText: TextView
  private lateinit var progress: ProgressBar
  private lateinit var btnShizuku: MaterialButton
  private lateinit var btnStart: MaterialButton
  private lateinit var btnTerminal: MaterialButton
  private lateinit var btnInstallDesktop: MaterialButton
  private lateinit var btnDesktop: MaterialButton
  private lateinit var btnTools: MaterialButton
  private val ui = Handler(Looper.getMainLooper())
  private val requestCode = 4102
  @Volatile private var busy = false
  private var linuxOk = false
  private var desktopOk = false

  private val permissionListener = Shizuku.OnRequestPermissionResultListener { code, _ ->
    if (code == requestCode) ui.post { refresh() }
  }
  private val binderListener = Shizuku.OnBinderReceivedListener { ui.post { refresh() } }
  private val deadListener = Shizuku.OnBinderDeadListener { ui.post { refresh() } }

  override fun onCreate(savedInstanceState: Bundle?) {
    DynamicColors.applyToActivityIfAvailable(this)
    super.onCreate(savedInstanceState)
    p = pal()
    styleBars(p)
    Shizuku.addRequestPermissionResultListener(permissionListener)
    Shizuku.addBinderReceivedListenerSticky(binderListener)
    Shizuku.addBinderDeadListener(deadListener)

    val page = LinearLayout(this).apply {
      orientation = LinearLayout.VERTICAL
      setPadding(dp(18), dp(24), dp(18), dp(28))
      setBackgroundColor(p.bg)
    }
    page.addView(label("Linux", 28f, p.text, true))
    page.addView(label("Debian • XFCE สไตล์ macOS • เทอร์มินัลในแอป", 13f, p.accent, true).apply {
      setPadding(0, dp(4), 0, dp(18))
    })

    // 1. Shizuku
    shizukuStatus = label("", 13f, p.muted)
    btnShizuku = mbtn("ตรวจสอบ / ขอสิทธิ์ Shizuku", true).apply { setOnClickListener { connectShizuku() } }
    page.addView(card("1  การเชื่อมต่อ Shizuku", shizukuStatus, btnShizuku))

    // 2. Linux
    linuxStatus = label("", 13f, p.muted)
    btnStart = mbtn("Start Linux").apply { setOnClickListener { startLinux() } }
    btnTerminal = mbtn("เปิด Terminal", true).apply {
      setOnClickListener { startActivity(Intent(this@LinuxDesktopActivity, TerminalActivity::class.java)) }
    }
    page.addView(card("2  ระบบ Debian", linuxStatus, btnStart, btnTerminal))

    // progress
    progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
      max = 100; isIndeterminate = true; visibility = View.GONE
    }
    progressText = label("", 12.5f, p.muted).apply { visibility = View.GONE; setPadding(0, dp(6), 0, 0) }
    page.addView(progress, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(2) })
    page.addView(progressText)

    // 3. Desktop
    desktopStatus = label("", 13f, p.muted)
    btnInstallDesktop = mbtn("ติดตั้ง XFCE + ธีม macOS", true).apply { setOnClickListener { installDesktop() } }
    btnDesktop = mbtn("Start XFCE desktop").apply {
      setOnClickListener { startActivity(Intent(this@LinuxDesktopActivity, XfceActivity::class.java)) }
    }
    page.addView(card("3  เดสก์ท็อป XFCE (macOS)", desktopStatus, btnInstallDesktop, btnDesktop))
    page.addView(label("(ถ้าเน็ตไม่ดีอาจจะไม่สามารถติดตั้งได้)", 12f, p.muted).apply {
      setPadding(dp(4), dp(0), dp(4), dp(12))
    })

    // tools
    btnTools = mbtn("เครื่องมือ / ลบ Linux", true).apply { setOnClickListener { showTools() } }
    page.addView(btnTools, LinearLayout.LayoutParams(MATCH_PARENT, dp(50)).apply { topMargin = dp(6) })

    page.addView(label(
      "Linux รันด้วย proot ผ่านสิทธิ์ ADB Shell ของ Shizuku ไฟล์อยู่ที่ /data/local/tmp/windeb " +
        "ติดตั้ง Debian ครั้งแรกใช้ดาวน์โหลดราว 30 MB ส่วน XFCE + ธีม ราว 300–500 MB",
      12f, p.muted
    ).apply { setPadding(dp(4), dp(16), dp(4), 0) })

    setContentView(ScrollView(this).apply { addView(page) })
    refresh()
  }

  private fun card(title: String, status: TextView, vararg buttons: MaterialButton): View {
    val c = LinearLayout(this).apply {
      orientation = LinearLayout.VERTICAL
      setPadding(dp(16), dp(15), dp(16), dp(16))
      background = shape(p.card, 22, 1, p.outline)
      layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(14) }
    }
    c.addView(label(title, 16f, p.text, true))
    status.setPadding(0, dp(6), 0, dp(12))
    c.addView(status)
    for (b in buttons) c.addView(b, LinearLayout.LayoutParams(MATCH_PARENT, dp(50)).apply { topMargin = dp(8) })
    return c
  }

  // ---------------------------------------------------------------- state

  private fun refresh() {
    val connected = try { Shizuku.pingBinder() } catch (_: Throwable) { false }
    val granted = connected && try { Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED } catch (_: Throwable) { false }
    shizukuStatus.text = when {
      !connected -> "ยังไม่พบ Shizuku service เปิดแอป Shizuku แล้วเริ่มบริการ (Wireless debugging หรือ ADB) ก่อน"
      granted -> "เชื่อมต่อแล้ว • ได้รับสิทธิ์ ADB Shell"
      else -> "พบ Shizuku แล้ว • รออนุญาตสิทธิ์ให้ WinDeb Lab"
    }
    btnShizuku.isEnabled = !granted
    if (!granted) {
      linuxOk = false; desktopOk = false
      updateButtons(granted)
      linuxStatus.text = "ต้องเชื่อมต่อ Shizuku ก่อน จึงจะติดตั้งและเริ่ม Linux ได้"
      desktopStatus.text = "ต้องติดตั้ง Debian ก่อน"
      return
    }
    linuxStatus.text = "กำลังตรวจสอบ…"
    Thread {
      val l = try { Linux.installed() } catch (_: Throwable) { false }
      val d = l && try { Linux.desktopInstalled() } catch (_: Throwable) { false }
      ui.post {
        linuxOk = l; desktopOk = d
        linuxStatus.text = if (l) "ติดตั้ง Debian แล้ว • พร้อมเปิด Terminal"
        else "ยังไม่ได้ติดตั้ง • กด Start Linux เพื่อดาวน์โหลดและตั้งค่า Debian"
        desktopStatus.text = when {
          !l -> "ต้องติดตั้ง Debian ก่อน"
          d -> "ติดตั้ง XFCE แล้ว • กด Start XFCE desktop"
          else -> "ยังไม่ได้ติดตั้ง XFCE กดติดตั้ง ระบบจะรันตัวติดตั้งในเทอร์มินัลให้ดูความคืบหน้า"
        }
        updateButtons(granted)
      }
    }.start()
  }

  private fun updateButtons(granted: Boolean) {
    fun set(b: MaterialButton, on: Boolean) { b.isEnabled = on && !busy; b.alpha = if (b.isEnabled) 1f else 0.5f }
    set(btnStart, granted)
    set(btnTerminal, granted && linuxOk)
    set(btnInstallDesktop, granted && linuxOk)
    set(btnDesktop, granted && linuxOk && desktopOk)
    set(btnTools, granted)
    btnStart.text = if (linuxOk) "Start Linux (เปิด Terminal)" else "Start Linux (ติดตั้งและเริ่ม)"
  }

  private fun connectShizuku() {
    if (!Shizuku.pingBinder()) { refresh(); return }
    if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) { refresh(); return }
    Shizuku.requestPermission(requestCode)
  }

  // ---------------------------------------------------------------- actions

  private fun startLinux() {
    if (!Linux.shizukuReady()) { connectShizuku(); return }
    if (linuxOk) {
      startActivity(Intent(this, TerminalActivity::class.java))
      return
    }
    setBusy(true)
    Thread {
      try {
        Linux.provision(this) { msg, pct -> ui.post { showProgress(msg, pct) } }
        ui.post {
          setBusy(false)
          refresh()
          startActivity(Intent(this, TerminalActivity::class.java))
        }
      } catch (e: Throwable) {
        ui.post {
          setBusy(false)
          showProgress("ล้มเหลว: ${e.message}", -2)
          refresh()
        }
      }
    }.start()
  }

  private fun installDesktop() {
    startActivity(Intent(this, TerminalActivity::class.java)
      .putExtra(TerminalActivity.EXTRA_TITLE, "ติดตั้ง XFCE + ธีม macOS")
      .putExtra(TerminalActivity.EXTRA_CMD, "/bin/bash /root/windeb-setup.sh; echo; echo '[ปิดหน้านี้ได้เมื่อขึ้นคำว่า DONE]'; exec /bin/bash -l"))
  }

  private fun showTools() {
    val items = arrayOf("ปิด Android phantom process killer (กัน Linux ถูกฆ่า)", "ลบ Linux ทั้งหมด")
    AlertDialog.Builder(this)
      .setTitle("เครื่องมือ")
      .setItems(items) { _, which ->
        when (which) {
          0 -> Thread {
            val r = try { Linux.relaxPhantomKiller() } catch (e: Throwable) { e.message ?: "error" }
            ui.post { showProgress("phantom process killer: ${r.trim().take(200)}", -2) }
          }.start()
          1 -> AlertDialog.Builder(this)
            .setTitle("ลบ Linux ทั้งหมด?")
            .setMessage("ไฟล์ Debian, XFCE และข้อมูลใน /root จะถูกลบถาวร")
            .setNegativeButton("ยกเลิก", null)
            .setPositiveButton("ลบ") { _, _ ->
              Thread {
                try { Linux.stopDesktop(); Linux.removeAll() } catch (_: Throwable) {}
                ui.post { showProgress("ลบ Linux แล้ว", -2); refresh() }
              }.start()
            }.show()
        }
      }.show()
  }

  private fun setBusy(b: Boolean) {
    busy = b
    progress.visibility = if (b) View.VISIBLE else View.GONE
    progressText.visibility = if (b) View.VISIBLE else progressText.visibility
    updateButtons(Linux.shizukuReady())
  }

  /** pct: 0..100 determinate, -1 indeterminate, -2 message only */
  private fun showProgress(msg: String, pct: Int) {
    progressText.visibility = View.VISIBLE
    progressText.text = msg
    if (pct >= 0) { progress.isIndeterminate = false; progress.progress = pct }
    else if (pct == -1) progress.isIndeterminate = true
  }

  override fun onResume() {
    super.onResume()
    if (::shizukuStatus.isInitialized && !busy) refresh()
  }

  override fun onDestroy() {
    Shizuku.removeRequestPermissionResultListener(permissionListener)
    Shizuku.removeBinderReceivedListener(binderListener)
    Shizuku.removeBinderDeadListener(deadListener)
    super.onDestroy()
  }
}
