WinDeb Lab  — Android project (Kotlin, no external libraries)
Developer: tawan.01.yimchang@gmail.com

Build:
 1. Open this folder in Android Studio (Koala or newer, JDK 17). Let it sync (it downloads Gradle 8.7).
 2. Run on a device/tablet (Android 8.0+ / API 26+) or Build > Build APK(s).

Menu:
 1) Desktop Simulator  - Windows 10 style desktop inside the app (windows, taskbar, Start, apps)
 2) Linux Debian GUI   - real Debian (proot-distro in Termux) + XFCE themed like Windows 10, shown via noVNC
 3) About              - developer + feature list

Linux mode requirements: Termux from F-Droid, allow-external-apps=true in ~/.termux/termux.properties,
grant "Run commands in Termux environment" permission, ~4 GB free space, internet during install.
