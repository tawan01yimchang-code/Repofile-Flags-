export PREFIX=/data/data/com.termux/files/usr
export PATH=$PREFIX/bin:$PATH
termux-wake-lock 2>/dev/null
ROOTFS=$PREFIX/var/lib/proot-distro/installed-rootfs/debian
cat > "$ROOTFS/root/start.sh" <<'WINDEB_INNER'
@@INNER@@
WINDEB_INNER
chmod +x "$ROOTFS/root/start.sh"
exec proot-distro login debian -- bash /root/start.sh
