#!/bin/bash
export HOME=/root USER=root LANG=C.UTF-8
vncserver -kill :1 >/dev/null 2>&1
pkill -f "[w]ebsockify" >/dev/null 2>&1
rm -rf /tmp/.X1-lock /tmp/.X11-unix/X1
vncserver :1 -geometry @@GEOM@@ -depth 24 -localhost yes -SecurityTypes None --I-KNOW-THIS-IS-INSECURE
exec websockify --web=/usr/share/novnc 6080 127.0.0.1:5901
