export PREFIX=/data/data/com.termux/files/usr
export PATH=$PREFIX/bin:$PATH
proot-distro login debian -- bash -c 'vncserver -kill :1; pkill -f "[w]ebsockify"' 
termux-wake-unlock 2>/dev/null
exit 0
