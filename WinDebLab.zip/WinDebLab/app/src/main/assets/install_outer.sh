export PREFIX=/data/data/com.termux/files/usr
export PATH=$PREFIX/bin:$PATH
termux-wake-lock 2>/dev/null
pkg update -y
pkg install -y proot-distro
ROOTFS=$PREFIX/var/lib/proot-distro/installed-rootfs/debian
[ -d "$ROOTFS" ] || proot-distro install debian
cat > "$ROOTFS/root/install.sh" <<'WINDEB_INNER'
@@INNER@@
WINDEB_INNER
chmod +x "$ROOTFS/root/install.sh"
proot-distro login debian -- bash /root/install.sh
echo "WINDEB_INSTALL_DONE"
