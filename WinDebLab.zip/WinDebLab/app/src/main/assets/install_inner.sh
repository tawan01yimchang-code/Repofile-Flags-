#!/bin/bash
export DEBIAN_FRONTEND=noninteractive
export LANG=C.UTF-8
apt-get update
apt-get install -y --no-install-recommends xfce4 xfce4-whiskermenu-plugin xfce4-notifyd \
  xfce4-terminal thunar mousepad dbus-x11 tigervnc-standalone-server tigervnc-tools \
  novnc websockify git ca-certificates firefox-esr fonts-noto-core fonts-noto-color-emoji \
  fonts-liberation x11-xserver-utils procps

# Windows 10 look: GTK/xfwm theme + icon theme (best effort, needs internet)
cd /tmp
rm -rf w10theme w10icons
git clone --depth 1 https://github.com/B00merang-Project/Windows-10.git w10theme || true
git clone --depth 1 https://github.com/B00merang-Artwork/Windows-10.git w10icons || true
mkdir -p /usr/share/themes /usr/share/icons
[ -d w10theme ] && rm -rf /usr/share/themes/Windows-10 && cp -r w10theme /usr/share/themes/Windows-10
[ -d w10icons ] && rm -rf /usr/share/icons/Windows-10 && cp -r w10icons /usr/share/icons/Windows-10
gtk-update-icon-cache /usr/share/icons/Windows-10 2>/dev/null || true

C=/root/.config/xfce4/xfconf/xfce4-perchannel-xml
mkdir -p $C /tmp/runtime-root

cat > $C/xsettings.xml <<'XEOF'
<?xml version="1.0" encoding="UTF-8"?>
<channel name="xsettings" version="1.0">
  <property name="Net" type="empty">
    <property name="ThemeName" type="string" value="Windows-10"/>
    <property name="IconThemeName" type="string" value="Windows-10"/>
  </property>
  <property name="Gtk" type="empty">
    <property name="FontName" type="string" value="Noto Sans 10"/>
  </property>
</channel>
XEOF

cat > $C/xfwm4.xml <<'XEOF'
<?xml version="1.0" encoding="UTF-8"?>
<channel name="xfwm4" version="1.0">
  <property name="general" type="empty">
    <property name="theme" type="string" value="Windows-10"/>
    <property name="title_alignment" type="string" value="left"/>
    <property name="button_layout" type="string" value="O|HMC"/>
    <property name="use_compositing" type="bool" value="false"/>
  </property>
</channel>
XEOF

cat > $C/xfce4-desktop.xml <<'XEOF'
<?xml version="1.0" encoding="UTF-8"?>
<channel name="xfce4-desktop" version="1.0">
  <property name="backdrop" type="empty">
    <property name="screen0" type="empty">
      <property name="monitorVNC-0" type="empty">
        <property name="workspace0" type="empty">
          <property name="color-style" type="int" value="0"/>
          <property name="image-style" type="int" value="0"/>
          <property name="rgba1" type="array">
            <value type="double" value="0"/>
            <value type="double" value="0.38"/>
            <value type="double" value="0.69"/>
            <value type="double" value="1"/>
          </property>
        </property>
      </property>
    </property>
  </property>
</channel>
XEOF

cat > $C/xfce4-panel.xml <<'XEOF'
<?xml version="1.0" encoding="UTF-8"?>
<channel name="xfce4-panel" version="1.0">
  <property name="configver" type="int" value="2"/>
  <property name="panels" type="array">
    <value type="int" value="1"/>
    <property name="panel-1" type="empty">
      <property name="position" type="string" value="p=8;x=0;y=0"/>
      <property name="length" type="uint" value="100"/>
      <property name="position-locked" type="bool" value="true"/>
      <property name="size" type="uint" value="44"/>
      <property name="background-style" type="uint" value="1"/>
      <property name="background-rgba" type="array">
        <value type="double" value="0.07"/>
        <value type="double" value="0.07"/>
        <value type="double" value="0.07"/>
        <value type="double" value="0.96"/>
      </property>
      <property name="plugin-ids" type="array">
        <value type="int" value="1"/>
        <value type="int" value="2"/>
        <value type="int" value="3"/>
        <value type="int" value="4"/>
        <value type="int" value="5"/>
      </property>
    </property>
  </property>
  <property name="plugins" type="empty">
    <property name="plugin-1" type="string" value="whiskermenu"/>
    <property name="plugin-2" type="string" value="tasklist">
      <property name="grouping" type="uint" value="0"/>
      <property name="show-labels" type="bool" value="true"/>
    </property>
    <property name="plugin-3" type="string" value="separator">
      <property name="expand" type="bool" value="true"/>
      <property name="style" type="uint" value="0"/>
    </property>
    <property name="plugin-4" type="string" value="systray"/>
    <property name="plugin-5" type="string" value="clock">
      <property name="digital-time-format" type="string" value="%H:%M"/>
    </property>
  </property>
</channel>
XEOF

mkdir -p /root/.vnc
cat > /root/.vnc/xstartup <<'XEOF'
#!/bin/sh
unset SESSION_MANAGER
unset DBUS_SESSION_BUS_ADDRESS
export XDG_RUNTIME_DIR=/tmp/runtime-root
mkdir -p $XDG_RUNTIME_DIR
exec dbus-launch --exit-with-session startxfce4
XEOF
chmod +x /root/.vnc/xstartup
echo "inner install finished"
