package com.tawan.windeb

import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.LinearLayout
import android.widget.TextView

/** A draggable Windows-10-style window with minimize / maximize / close. */
class WinWindow(
    ctx: Context,
    title: String,
    content: View,
    private val onClose: (WinWindow) -> Unit,
    private val onFocus: (WinWindow) -> Unit,
    private val onMin: (WinWindow) -> Unit
) : LinearLayout(ctx) {

    private var maximized = false
    private var savedW = 0
    private var savedH = 0
    private var savedX = 0f
    private var savedY = 0f
    private var dx = 0f
    private var dy = 0f

    init {
        orientation = VERTICAL
        background = ctx.shape(Color.WHITE, 0, 1, 0xFF0078D7.toInt())
        elevation = ctx.dp(8).toFloat()

        val bar = LinearLayout(ctx).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0xFF0078D7.toInt())
        }
        val t = ctx.label(title, 13f, Color.WHITE).apply {
            setPadding(ctx.dp(10), 0, 0, 0)
            maxLines = 1
        }
        bar.addView(t, LayoutParams(0, WRAP_CONTENT, 1f))
        bar.addView(ctrl(ctx, "—") { onMin(this@WinWindow) })
        bar.addView(ctrl(ctx, "☐") { toggleMax() })
        bar.addView(ctrl(ctx, "✕") { onClose(this@WinWindow) })

        bar.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dx = x - e.rawX
                    dy = y - e.rawY
                    onFocus(this@WinWindow)
                }
                MotionEvent.ACTION_MOVE -> if (!maximized) {
                    val p = parent as? ViewGroup
                    var nx = e.rawX + dx
                    var ny = e.rawY + dy
                    if (p != null) {
                        nx = nx.coerceIn(-width + ctx.dp(80).toFloat(), (p.width - ctx.dp(40)).toFloat())
                        ny = ny.coerceIn(0f, (p.height - ctx.dp(32)).toFloat())
                    }
                    x = nx
                    y = ny
                }
            }
            true
        }
        addView(bar, LayoutParams(MATCH_PARENT, ctx.dp(32)))
        addView(content, LayoutParams(MATCH_PARENT, 0, 1f))
    }

    private fun ctrl(ctx: Context, s: String, f: () -> Unit): TextView =
        ctx.label(s, 14f, Color.WHITE).apply {
            gravity = Gravity.CENTER
            minWidth = ctx.dp(42)
            layoutParams = LayoutParams(ctx.dp(42), MATCH_PARENT)
            setOnClickListener { f() }
        }

    fun toggleMax() {
        val lp = layoutParams
        if (!maximized) {
            savedW = lp.width; savedH = lp.height; savedX = x; savedY = y
            lp.width = MATCH_PARENT; lp.height = MATCH_PARENT
            x = 0f; y = 0f
            maximized = true
        } else {
            lp.width = savedW; lp.height = savedH
            x = savedX; y = savedY
            maximized = false
        }
        layoutParams = lp
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) onFocus(this)
        return false
    }
}
