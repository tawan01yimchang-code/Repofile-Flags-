package com.tawan.windeb

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.widget.TextView

val BG = 0xFF0F1419.toInt()
val CARD = 0xFF1A2230.toInt()
val ACCENT = 0xFF0078D7.toInt()
val GREEN = 0xFFE95420.toInt()
val MUTED = 0xFFB0BEC5.toInt()

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun Context.shape(color: Int, radius: Int = 0, strokeW: Int = 0, strokeC: Int = 0) = GradientDrawable().apply {
    setColor(color)
    cornerRadius = dp(radius).toFloat()
    if (strokeW > 0) setStroke(dp(strokeW), strokeC)
}

fun Context.label(t: String, size: Float = 14f, color: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply {
    text = t
    textSize = size
    setTextColor(color)
    if (bold) setTypeface(typeface, Typeface.BOLD)
}
