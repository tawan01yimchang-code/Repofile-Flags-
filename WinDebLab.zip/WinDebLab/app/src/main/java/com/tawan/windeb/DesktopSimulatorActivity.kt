package com.tawan.windeb

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import java.io.File

class DesktopSimulatorActivity : Activity() {

    private lateinit var root: FrameLayout
    private lateinit var winLayer: FrameLayout
    private lateinit var taskApps: LinearLayout
    private lateinit var wallpaper: View
    private var startMenu: View? = null
    private val taskButtons = HashMap<WinWindow, TextView>()
    private var cascade = 0

    private val apps = listOf(
        "📝" to "Notepad", "🧮" to "Calculator", "📁" to "File Explorer",
        "🌐" to "Browser", "⚙️" to "Settings"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        hideBars()

        root = FrameLayout(this)
        wallpaper = View(this).apply { background = wall(0) }
        root.addView(wallpaper, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        val tbH = dp(46)

        val grid = GridLayout(this).apply {
            orientation = GridLayout.VERTICAL
            rowCount = 4
            setPadding(dp(6), dp(6), 0, 0)
        }
        for ((icon, name) in apps) grid.addView(deskIcon(icon, name) { openApp(name) })
        grid.addView(deskIcon("🗑️", "Recycle Bin") {
            Toast.makeText(this, "ถังขยะว่างเปล่า", Toast.LENGTH_SHORT).show()
        })
        root.addView(grid, FrameLayout.LayoutParams(WRAP_CONTENT, MATCH_PARENT).apply { bottomMargin = tbH })

        winLayer = FrameLayout(this)
        winLayer.setOnClickListener { closeStart() }
        root.addView(winLayer, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT).apply { bottomMargin = tbH })

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0xF2141414.toInt())
        }
        val start = label("⊞", 24f, 0xFF4FC3F7.toInt()).apply {
            gravity = Gravity.CENTER
            setOnClickListener { toggleStart() }
        }
        bar.addView(start, LinearLayout.LayoutParams(dp(52), MATCH_PARENT))
        val search = label("🔍  พิมพ์ที่นี่เพื่อค้นหา", 12f, 0xFFCCCCCC.toInt()).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), 0, dp(10), 0)
            background = shape(0xFF2B2B2B.toInt(), 2)
            setOnClickListener { toggleStart() }
        }
        bar.addView(search, LinearLayout.LayoutParams(dp(170), dp(32)).apply { setMargins(dp(4), 0, dp(8), 0) })
        taskApps = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bar.addView(taskApps, LinearLayout.LayoutParams(0, MATCH_PARENT, 1f))
        val clock = TextClock(this).apply {
            format24Hour = "HH:mm\ndd/MM/yyyy"
            format12Hour = "HH:mm\ndd/MM/yyyy"
            setTextColor(Color.WHITE)
            textSize = 11f
            gravity = Gravity.CENTER
            setPadding(dp(10), 0, dp(10), 0)
        }
        bar.addView(clock, LinearLayout.LayoutParams(WRAP_CONTENT, MATCH_PARENT))
        root.addView(bar, FrameLayout.LayoutParams(MATCH_PARENT, tbH, Gravity.BOTTOM))

        setContentView(root)
        openApp("Notepad")
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    @Suppress("DEPRECATION")
    private fun hideBars() {
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
    }

    // ---------- wallpaper ----------
    private fun wall(i: Int): GradientDrawable {
        val sets = listOf(
            intArrayOf(0xFF0A2A5E.toInt(), 0xFF0078D7.toInt(), 0xFF4FC3F7.toInt()),
            intArrayOf(0xFF2B1055.toInt(), 0xFF5B4B9E.toInt(), 0xFF7597DE.toInt()),
            intArrayOf(0xFF0F2027.toInt(), 0xFF203A43.toInt(), 0xFF2C5364.toInt()),
            intArrayOf(0xFF111111.toInt(), 0xFF222222.toInt(), 0xFF3A3A3A.toInt())
        )
        return GradientDrawable(GradientDrawable.Orientation.BL_TR, sets[i % sets.size])
    }

    // ---------- desktop icons ----------
    private fun deskIcon(icon: String, name: String, onOpen: () -> Unit): View {
        val l = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(4), dp(4), dp(4), dp(4))
            setOnClickListener { onOpen() }
        }
        l.addView(label(icon, 28f))
        l.addView(label(name, 10.5f).apply { gravity = Gravity.CENTER; setShadowLayer(3f, 1f, 1f, Color.BLACK) })
        l.layoutParams = GridLayout.LayoutParams().apply { width = dp(78); height = dp(68) }
        return l
    }

    // ---------- start menu ----------
    private fun closeStart() {
        startMenu?.let { root.removeView(it) }
        startMenu = null
    }

    private fun toggleStart() {
        if (startMenu != null) { closeStart(); return }
        val m = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(0xF2222222.toInt())
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        m.addView(label("แอปทั้งหมด", 12f, 0xFF9E9E9E.toInt()).apply { setPadding(dp(8), 0, 0, dp(4)) })
        for ((icon, name) in apps) m.addView(menuRow(icon, name) { openApp(name) })
        m.addView(menuRow("⏻", "ปิดเครื่อง (ออก)") { finish() })
        root.addView(m, FrameLayout.LayoutParams(dp(260), WRAP_CONTENT, Gravity.BOTTOM).apply { bottomMargin = dp(46) })
        startMenu = m
    }

    private fun menuRow(icon: String, name: String, f: () -> Unit): View =
        label("$icon   $name", 14f).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), 0, dp(10), 0)
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, dp(38))
            setOnClickListener { f() }
        }

    // ---------- windows ----------
    private fun openApp(name: String) {
        closeStart()
        val icon = apps.firstOrNull { it.second == name }?.first ?: "🪟"
        when (name) {
            "Notepad" -> addWindow(icon, name, notepad(), 340, 240)
            "Calculator" -> addWindow(icon, name, calculator(), 230, 320)
            "File Explorer" -> addWindow(icon, name, explorer(), 360, 260)
            "Browser" -> addWindow(icon, name, browser(), 460, 280)
            "Settings" -> addWindow(icon, name, settings(), 340, 220)
        }
    }

    private fun addWindow(icon: String, title: String, content: View, w: Int, h: Int) {
        val dm = resources.displayMetrics
        val maxW = dm.widthPixels
        val maxH = dm.heightPixels - dp(46)
        val ww = minOf(dp(w), maxW - dp(8))
        val hh = minOf(dp(h), maxH - dp(8))
        val win = WinWindow(this, "$icon $title", content, ::closeWin, ::focusWin, ::minWin)
        cascade = (cascade + 1) % 6
        winLayer.addView(win, FrameLayout.LayoutParams(ww, hh))
        win.x = (dp(70) + cascade * dp(24)).coerceAtMost(maxW - ww).toFloat()
        win.y = (dp(10) + cascade * dp(18)).coerceAtMost(maxH - hh).toFloat()
        focusWin(win)

        val tb = label("$icon $title", 12f).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), 0, dp(10), 0)
            background = shape(0xFF3A3A3A.toInt())
            setOnClickListener {
                if (win.visibility == View.VISIBLE) win.visibility = View.GONE
                else { win.visibility = View.VISIBLE; focusWin(win) }
            }
        }
        taskApps.addView(tb, LinearLayout.LayoutParams(WRAP_CONTENT, MATCH_PARENT).apply { setMargins(dp(2), dp(5), dp(2), dp(5)) })
        taskButtons[win] = tb
    }

    private fun focusWin(w: WinWindow) { w.bringToFront(); closeStart() }
    private fun minWin(w: WinWindow) { w.visibility = View.GONE }
    private fun closeWin(w: WinWindow) {
        winLayer.removeView(w)
        taskButtons.remove(w)?.let { taskApps.removeView(it) }
    }

    // ---------- apps ----------
    private fun notepad(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val et = EditText(this).apply {
            hint = "พิมพ์ข้อความที่นี่..."
            setTextColor(Color.BLACK); setHintTextColor(Color.GRAY)
            gravity = Gravity.TOP
            typeface = Typeface.MONOSPACE
            setBackgroundColor(Color.WHITE)
            textSize = 14f
        }
        box.addView(et, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        box.addView(Button(this).apply {
            text = "💾 บันทึก"
            setOnClickListener {
                val dir = getExternalFilesDir(null) ?: filesDir
                val f = File(dir, "note_${System.currentTimeMillis() / 1000}.txt")
                f.writeText(et.text.toString())
                Toast.makeText(this@DesktopSimulatorActivity, "บันทึกแล้ว: ${f.name}", Toast.LENGTH_SHORT).show()
            }
        }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        return box
    }

    private fun calculator(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF202020.toInt()) }
        val display = TextView(this).apply {
            text = "0"; textSize = 26f; gravity = Gravity.END or Gravity.CENTER_VERTICAL
            setTextColor(Color.WHITE); setPadding(dp(10), dp(4), dp(10), dp(4)); maxLines = 1
        }
        box.addView(display, LinearLayout.LayoutParams(MATCH_PARENT, dp(52)))

        var acc: Double? = null
        var op: String? = null
        var cur = ""
        fun fmt(d: Double): String =
            if (d.isNaN() || d.isInfinite()) "Error" else if (d == Math.floor(d) && Math.abs(d) < 1e15) d.toLong().toString() else d.toString()
        fun calc(a: Double, o: String, b: Double): Double = when (o) {
            "+" -> a + b; "−" -> a - b; "×" -> a * b; else -> a / b
        }
        fun press(k: String) {
            when (k) {
                "C" -> { acc = null; op = null; cur = ""; display.text = "0" }
                "⌫" -> { cur = cur.dropLast(1); display.text = if (cur.isEmpty()) "0" else cur }
                "+", "−", "×", "÷" -> {
                    if (cur.isNotEmpty()) {
                        val v = cur.toDouble()
                        acc = if (acc != null && op != null) calc(acc!!, op!!, v) else v
                    }
                    op = k; cur = ""
                    acc?.let { display.text = fmt(it) }
                }
                "=" -> {
                    if (acc != null && op != null && cur.isNotEmpty()) {
                        val r = calc(acc!!, op!!, cur.toDouble())
                        display.text = fmt(r)
                        cur = if (r.isNaN() || r.isInfinite()) "" else fmt(r)
                        acc = null; op = null
                    }
                }
                "." -> { if (!cur.contains(".")) { cur = if (cur.isEmpty()) "0." else "$cur."; display.text = cur } }
                else -> { cur = if (cur == "0") k else cur + k; display.text = cur }
            }
        }
        val rows = listOf(
            listOf("C" to 1f, "⌫" to 1f, "÷" to 1f, "×" to 1f),
            listOf("7" to 1f, "8" to 1f, "9" to 1f, "−" to 1f),
            listOf("4" to 1f, "5" to 1f, "6" to 1f, "+" to 1f),
            listOf("1" to 1f, "2" to 1f, "3" to 1f, "=" to 1f),
            listOf("0" to 3f, "." to 1f)
        )
        for (r in rows) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for ((k, wgt) in r) {
                row.addView(TextView(this).apply {
                    text = k; textSize = 17f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
                    background = shape(if (k == "=") 0xFF0078D7.toInt() else 0xFF3B3B3B.toInt(), 0, 1, 0xFF202020.toInt())
                    setOnClickListener { press(k) }
                }, LinearLayout.LayoutParams(0, MATCH_PARENT, wgt))
            }
            box.addView(row, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        }
        return box
    }

    private fun explorer(): View {
        val base = getExternalFilesDir(null) ?: filesDir
        var dir: File = base
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE) }
        val path = label("", 12f, Color.BLACK).apply { setPadding(dp(8), dp(4), dp(8), dp(4)) }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        fun render() {
            list.removeAllViews()
            path.text = "💻 ที่เก็บแอป › " + dir.relativeTo(base).path
            val items = dir.listFiles()?.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() })) ?: emptyList()
            if (items.isEmpty()) list.addView(label("(โฟลเดอร์ว่าง)", 13f, Color.GRAY).apply { setPadding(dp(12), dp(8), 0, 0) })
            for (f in items) {
                list.addView(label((if (f.isDirectory) "📁 " else "📄 ") + f.name + if (f.isFile) "  (${f.length()} B)" else "", 13f, Color.BLACK).apply {
                    setPadding(dp(12), dp(8), dp(8), dp(8))
                    setOnClickListener { if (f.isDirectory) { dir = f; render() } }
                })
            }
        }
        tools.addView(Button(this).apply {
            text = "⬆ ขึ้น"; textSize = 11f
            setOnClickListener { if (dir != base) { dir = dir.parentFile ?: base; render() } }
        })
        tools.addView(Button(this).apply {
            text = "📁+ โฟลเดอร์ใหม่"; textSize = 11f
            setOnClickListener {
                var n = 1
                while (File(dir, "โฟลเดอร์ใหม่ $n").exists()) n++
                File(dir, "โฟลเดอร์ใหม่ $n").mkdirs()
                render()
            }
        })
        box.addView(tools)
        box.addView(path)
        box.addView(ScrollView(this).apply { addView(list) }, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        render()
        return box
    }

    private fun browser(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE) }
        val addr = EditText(this).apply {
            setText("https://www.google.com"); setSingleLine(); textSize = 13f
            setTextColor(Color.BLACK)
        }
        val web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = WebViewClient()
            loadUrl("https://www.google.com")
        }
        fun go() {
            var u = addr.text.toString().trim()
            if (u.isEmpty()) return
            u = when {
                u.startsWith("http://") || u.startsWith("https://") -> u
                u.contains(".") && !u.contains(" ") -> "https://$u"
                else -> "https://www.google.com/search?q=" + java.net.URLEncoder.encode(u, "UTF-8")
            }
            web.loadUrl(u)
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(addr, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        row.addView(Button(this).apply { text = "ไป"; setOnClickListener { go() } })
        box.addView(row)
        box.addView(web, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        return box
    }

    private fun settings(): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF2B2B2B.toInt()); setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        box.addView(label("⚙️ การตั้งค่า › ส่วนบุคคล › พื้นหลัง", 14f, Color.WHITE, true))
        box.addView(label("เลือกวอลเปเปอร์เดสก์ท็อป", 12f, 0xFFB0B0B0.toInt()).apply { setPadding(0, dp(6), 0, dp(10)) })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (i in 0 until 4) {
            row.addView(View(this).apply {
                background = wall(i)
                setOnClickListener { wallpaper.background = wall(i) }
            }, LinearLayout.LayoutParams(dp(64), dp(44)).apply { rightMargin = dp(10) })
        }
        box.addView(row)
        box.addView(label("WinDeb Lab • Desktop Simulator v1.0\nผู้พัฒนา: tawan.01.yimchang@gmail.com", 11f, 0xFF9E9E9E.toInt()).apply { setPadding(0, dp(18), 0, 0) })
        return box
    }
}
