package com.tawan.windeb

import android.Manifest
import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.net.InetSocketAddress
import java.net.Socket

/**
 * Runs a real Debian (proot-distro inside Termux) with an XFCE desktop themed like Windows 10,
 * then shows it inside the app through noVNC in a WebView — a graphical desktop, not a terminal.
 */
class LinuxDesktopActivity : Activity() {

    private val ACTION = "com.tawan.windeb.TERMUX_RESULT"
    private val TERMUX_PERM = "com.termux.permission.RUN_COMMAND"
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var web: WebView
    private lateinit var status: TextView
    private lateinit var guide: ScrollView
    private var polling = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val kind = i.getStringExtra("kind") ?: return
            val r = i.getBundleExtra("result")
            val code = r?.getInt("exitCode", -1) ?: -1
            val err = (r?.getString("stderr") ?: "").takeLast(350)
            val out = (r?.getString("stdout") ?: "").takeLast(200)
            val msg = r?.getString("errmsg")
            when (kind) {
                "install" -> setStatus(
                    if (code == 0 && out.contains("WINDEB_INSTALL_DONE")) "✅ ติดตั้งเสร็จ — กด ▶ เริ่ม"
                    else "⚠ ติดตั้งจบด้วยรหัส $code\n${msg ?: ""}\n$err"
                )
                "start" -> setStatus("เซสชัน Debian หยุดทำงานแล้ว (รหัส $code) ${msg ?: ""}\n$err")
                "stop" -> setStatus("⏹ หยุดแล้ว")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }

        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t; textSize = 12f; isAllCaps = false
            setOnClickListener { f() }
        }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bar.addView(btn("⬇ ติดตั้ง") { install() })
        bar.addView(btn("▶ เริ่ม") { start() })
        bar.addView(btn("⏹ หยุด") { stop() })
        bar.addView(btn("Termux") { openTermux() })
        col.addView(HorizontalScrollView(this).apply { addView(bar) })

        status = label("พร้อมใช้งาน — อ่านขั้นตอนด้านล่าง", 12f, MUTED).apply { setPadding(dp(10), dp(2), dp(10), dp(4)) }
        col.addView(status)

        val frame = FrameLayout(this)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.useWideViewPort = true
            webViewClient = WebViewClient()
            setBackgroundColor(Color.BLACK)
            visibility = View.GONE
        }
        frame.addView(web, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        guide = ScrollView(this).apply {
            addView(label(
                """
                วิธีใช้ (ทำครั้งแรกครั้งเดียว)

                1) ติดตั้ง Termux จาก F-Droid (ไม่ใช่ Play Store)
                2) เปิด Termux แล้วพิมพ์:
                   mkdir -p ~/.termux && echo "allow-external-apps=true" >> ~/.termux/termux.properties
                   จากนั้นปิด Termux แล้วเปิดใหม่ 1 ครั้ง
                3) ตั้งค่าระบบ › แอป › WinDeb Lab › สิทธิ์ › อนุญาต "Run commands in Termux environment"
                4) กด ⬇ ติดตั้ง (ใช้เวลา ~15–40 นาที ใช้พื้นที่ ~3–4 GB ต้องต่อเน็ต) — ปล่อยให้ Termux ทำงานอยู่
                5) กด ▶ เริ่ม แล้วรอ 10–30 วินาที เดสก์ท็อปจะแสดงที่นี่

                ใช้งาน: แตะ = คลิก, แตะค้างแล้วลาก = ลากหน้าต่าง, ปุ่มคีย์บอร์ดบนแถบ noVNC ใช้พิมพ์ข้อความ
                ธีม Windows 10 เป็นการปรับหน้าตา XFCE ให้คล้ายของจริง
                """.trimIndent(), 13f, 0xFFCFD8DC.toInt()
            ).apply { setPadding(dp(14), dp(10), dp(14), dp(14)) })
        }
        frame.addView(guide, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        col.addView(frame, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        setContentView(col)

        val f = IntentFilter(ACTION)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(receiver, f)
    }

    override fun onDestroy() {
        polling = false
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        web.destroy()
        super.onDestroy()
    }

    private fun setStatus(s: String) = runOnUiThread { status.text = s }

    private fun asset(name: String): String = assets.open(name).bufferedReader().use { it.readText() }

    private fun termuxInstalled(): Boolean = try {
        packageManager.getPackageInfo("com.termux", 0); true
    } catch (_: Exception) { false }

    private fun openTermux() {
        val i = packageManager.getLaunchIntentForPackage("com.termux")
        if (i != null) startActivity(i) else setStatus("ไม่พบ Termux — ติดตั้งจาก F-Droid ก่อน")
    }

    private fun install() {
        val script = asset("install_outer.sh").replace("@@INNER@@", asset("install_inner.sh"))
        setStatus("⏳ กำลังติดตั้ง Debian + XFCE + ธีม Windows 10 ... (อาจนาน 15–40 นาที)")
        runInTermux("install", script)
    }

    private fun start() {
        if (portOpen()) { showDesktop(); return }
        val dm = resources.displayMetrics
        val geom = "1280x720"
        val script = asset("start_outer.sh").replace("@@INNER@@", asset("start_inner.sh").replace("@@GEOM@@", geom))
        setStatus("⏳ กำลังเริ่ม Debian desktop ...")
        if (runInTermux("start", script)) pollUntilReady(dm.widthPixels)
    }

    private fun stop() {
        polling = false
        web.visibility = View.GONE
        guide.visibility = View.VISIBLE
        runInTermux("stop", asset("stop_outer.sh"))
    }

    private fun runInTermux(kind: String, script: String): Boolean {
        if (!termuxInstalled()) { setStatus("❌ ไม่พบ Termux — ติดตั้งจาก F-Droid ก่อน"); return false }
        if (checkSelfPermission(TERMUX_PERM) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(TERMUX_PERM), 1)
            setStatus("กรุณาอนุญาตสิทธิ์ Run commands in Termux แล้วกดอีกครั้ง")
            return false
        }
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
        val resultIntent = Intent(ACTION).setPackage(packageName).putExtra("kind", kind)
        val pi = PendingIntent.getBroadcast(this, kind.hashCode(), resultIntent, flags)
        val i = Intent("com.termux.RUN_COMMAND")
            .setClassName("com.termux", "com.termux.app.RunCommandService")
            .putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/bash")
            .putExtra("com.termux.RUN_COMMAND_ARGUMENTS", arrayOf("-c", script))
            .putExtra("com.termux.RUN_COMMAND_WORKDIR", "/data/data/com.termux/files/home")
            .putExtra("com.termux.RUN_COMMAND_BACKGROUND", true)
            .putExtra("com.termux.RUN_COMMAND_PENDING_INTENT", pi)
        return try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            true
        } catch (e: Exception) {
            setStatus("❌ เรียก Termux ไม่ได้: ${e.message}\nตรวจสอบ allow-external-apps=true แล้วเปิด Termux ใหม่")
            false
        }
    }

    private fun portOpen(): Boolean = try {
        Socket().use { it.connect(InetSocketAddress("127.0.0.1", 6080), 400); true }
    } catch (_: Exception) { false }

    private fun pollUntilReady(@Suppress("UNUSED_PARAMETER") w: Int) {
        polling = true
        Thread {
            var tries = 0
            while (polling && tries < 120) {
                if (portOpen()) {
                    Thread.sleep(1500)
                    runOnUiThread { showDesktop() }
                    return@Thread
                }
                Thread.sleep(1500); tries++
            }
            if (polling) setStatus("⌛ รอนานเกินไป — ตรวจว่า ⬇ ติดตั้ง เสร็จแล้ว หรือเปิดแอป Termux ค้างไว้")
        }.start()
    }

    private fun showDesktop() {
        polling = false
        guide.visibility = View.GONE
        web.visibility = View.VISIBLE
        web.loadUrl("http://127.0.0.1:6080/vnc.html?autoconnect=true&resize=scale&reconnect=true&show_dot=true")
        setStatus("🟢 เดสก์ท็อปกำลังทำงาน")
    }
}
