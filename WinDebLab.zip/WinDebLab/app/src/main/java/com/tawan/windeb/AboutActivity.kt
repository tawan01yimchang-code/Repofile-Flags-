package com.tawan.windeb

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast

class AboutActivity : Activity() {
    private val email = "tawan.01.yimchang@gmail.com"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(28))
        }
        col.addView(label("WinDeb Lab", 28f, Color.WHITE, true))
        col.addView(label("เวอร์ชัน 1.0", 13f, MUTED))

        col.addView(label("ผู้พัฒนา", 16f, 0xFF4FC3F7.toInt(), true).apply { setPadding(0, dp(22), 0, dp(4)) })
        col.addView(label(email, 15f, Color.WHITE))
        col.addView(Button(this).apply {
            text = "✉ ส่งอีเมลถึงผู้พัฒนา"
            setOnClickListener {
                try {
                    startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$email")).putExtra(Intent.EXTRA_SUBJECT, "WinDeb Lab"))
                } catch (e: Exception) {
                    Toast.makeText(this@AboutActivity, "ไม่พบแอปอีเมล", Toast.LENGTH_SHORT).show()
                }
            }
        }, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = dp(8) })

        col.addView(label("คุณสมบัติของแอป", 16f, 0xFF4FC3F7.toInt(), true).apply { setPadding(0, dp(24), 0, dp(4)) })
        col.addView(label(
            """
            🖥️ Desktop Simulator
            • เดสก์ท็อปจำลองทรง Windows 10 ในแอป
            • Taskbar, Start Menu, นาฬิกา, ไอคอนบนเดสก์ท็อป
            • หน้าต่างหลายใบ ลาก ย่อ ขยาย ปิดได้
            • Notepad (บันทึกไฟล์), Calculator, File Explorer (สร้างโฟลเดอร์ได้), Browser, Settings (เปลี่ยนวอลเปเปอร์)

            🐧 Linux Debian GUI
            • Debian จริง (proot-distro) + XFCE4 เดสก์ท็อปจริง ไม่ใช่ Terminal
            • ปรับธีม Windows-10, แถบงานด้านล่าง, เมนู Start (Whisker)
            • แสดงผลในแอปผ่าน VNC/noVNC รองรับทัช เมาส์ และคีย์บอร์ด
            • มี Firefox ESR, Thunar, Mousepad ติดตั้งให้
            • ควบคุมติดตั้ง/เริ่ม/หยุดจากปุ่มในแอป (สั่งผ่าน Termux)

            ℹ️ หมายเหตุ
            • โหมด Linux ต้องติดตั้ง Termux จาก F-Droid และเปิด allow-external-apps=true
            • ธีมเป็นการปรับแต่งหน้าตาให้เหมือน Windows 10 ไม่ได้เป็น Windows จริง
            """.trimIndent(), 13.5f, 0xFFCFD8DC.toInt()
        ))
        setContentView(ScrollView(this).apply { setBackgroundColor(BG); addView(col) })
    }
}
