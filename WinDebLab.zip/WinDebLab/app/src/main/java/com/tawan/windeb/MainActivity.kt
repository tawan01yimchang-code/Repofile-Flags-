package com.tawan.windeb

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(28), dp(18), dp(28))
        }
        col.addView(label("WinDeb Lab", 30f, Color.WHITE, true))
        col.addView(label("เลือกโหมดที่ต้องการใช้งาน", 14f, MUTED))

        col.addView(card(
            "🖥️", "1) Desktop Simulator",
            "จำลองเดสก์ท็อปทรง Windows 10 ในตัวแอป พร้อมใช้งานได้ทันที ไม่ต้องติดตั้งอะไรเพิ่ม",
            listOf(
                "แถบงาน (Taskbar) + ปุ่ม Start + ช่องค้นหา + นาฬิกา",
                "หน้าต่างลากย้ายได้ ย่อ/ขยาย/ปิดได้ เปิดหลายหน้าต่างพร้อมกัน",
                "แอปในตัว: Notepad (บันทึกไฟล์ได้), Calculator, File Explorer, Browser, Settings",
                "เปลี่ยนวอลเปเปอร์เดสก์ท็อปได้ 4 แบบ",
                "ทำงานออฟไลน์ (ยกเว้น Browser)"
            ), ACCENT
        ) { startActivity(Intent(this, DesktopSimulatorActivity::class.java)) })

        col.addView(card(
            "🐧", "2) Linux Debian GUI (ทรง Windows 10)",
            "รัน Debian Linux จริงพร้อมเดสก์ท็อป XFCE ปรับธีม/ไอคอน/แถบงานให้เหมือน Windows 10 แสดงผลเป็นหน้าจอกราฟิกในแอป ไม่ใช่ Terminal",
            listOf(
                "Debian จริงผ่าน proot-distro + XFCE4 (ไม่ต้องรูท)",
                "ธีม Windows-10 (GTK/ไอคอน), แถบงานล่าง, เมนู Whisker แบบ Start",
                "จอแสดงผลผ่าน VNC + noVNC ใน WebView — คลิก/ลาก/คีย์บอร์ดได้",
                "ติดตั้ง Firefox ESR, Thunar (ไฟล์), Mousepad (แก้ข้อความ) ให้ในตัว",
                "ปุ่มติดตั้ง / เริ่ม / หยุด ควบคุมจากในแอป",
                "ต้องมี Termux (จาก F-Droid) + พื้นที่ว่างประมาณ 3–4 GB + อินเทอร์เน็ตตอนติดตั้ง"
            ), GREEN
        ) { startActivity(Intent(this, LinuxDesktopActivity::class.java)) })

        col.addView(card(
            "ℹ️", "3) เกี่ยวกับ / ผู้พัฒนา",
            "ข้อมูลแอป เวอร์ชัน และช่องทางติดต่อผู้พัฒนา",
            listOf(
                "ผู้พัฒนา: tawan.01.yimchang@gmail.com",
                "รายละเอียดคุณสมบัติทั้งหมดของแอป",
                "ปุ่มส่งอีเมลถึงผู้พัฒนาโดยตรง"
            ), 0xFF43A047.toInt()
        ) { startActivity(Intent(this, AboutActivity::class.java)) })

        setContentView(ScrollView(this).apply { setBackgroundColor(BG); addView(col) })
    }

    private fun card(icon: String, title: String, desc: String, feats: List<String>, accent: Int, onClick: () -> Unit): View {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = shape(CARD, 16, 1, accent)
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(14) }
        }
        c.addView(label("$icon  $title", 18f, Color.WHITE, true))
        c.addView(label(desc, 13f, MUTED).apply { setPadding(0, dp(6), 0, dp(8)) })
        c.addView(label(feats.joinToString("\n") { "✓ $it" }, 12.5f, 0xFFCFD8DC.toInt()))
        c.addView(Button(this).apply {
            text = "เปิด"
            setOnClickListener { onClick() }
        }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(12) })
        return c
    }
}
