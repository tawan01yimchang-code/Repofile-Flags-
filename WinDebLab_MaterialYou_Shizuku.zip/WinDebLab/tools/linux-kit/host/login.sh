#!/system/bin/sh
# Runs a command inside the Debian rootfs through proot. Executed as the ADB shell user (via Shizuku).
BASE=/data/local/tmp/windeb
export PROOT_TMP_DIR="$BASE/tmp"
export PROOT_NO_SECCOMP=1
unset LD_PRELOAD
mkdir -p "$PROOT_TMP_DIR"
FB=""
for f in stat loadavg uptime version vmstat; do
  [ -r "/proc/$f" ] || FB="$FB -b $BASE/fake/$f:/proc/$f"
done
[ -d /storage/emulated/0 ] && FB="$FB -b /storage/emulated/0:/sdcard"
[ $# -eq 0 ] && set -- /bin/bash -l
exec "$BASE/proot" --kill-on-exit --link2symlink -0 -r "$BASE/rootfs" -w /root \
  -b /dev -b /dev/urandom:/dev/random -b "$BASE/tmp:/dev/shm" -b /proc -b /sys \
  -b /proc/self/fd:/dev/fd -b /proc/self/fd/0:/dev/stdin -b /proc/self/fd/1:/dev/stdout -b /proc/self/fd/2:/dev/stderr \
  -b "$BASE/tmp:/tmp" $FB \
  /usr/bin/env -i HOME=/root USER=root LOGNAME=root SHELL=/bin/bash TERM=xterm-256color LANG=C.UTF-8 \
  PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games \
  DISPLAY=:1 MOZ_FAKE_NO_SANDBOX=1 "$@"
