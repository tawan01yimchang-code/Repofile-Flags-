#!/usr/bin/env python3
"""Rebuilds app/src/main/assets/linux/{hostkit,guestkit}.tar from the folders next to this script.
hostkit  -> extracted into /data/local/tmp/windeb
guestkit -> extracted into the Debian rootfs (config files, scripts, wallpaper)"""
import tarfile, os, sys
here = os.path.dirname(os.path.abspath(__file__))
out = os.path.join(here, '..', '..', 'app', 'src', 'main', 'assets', 'linux')
os.makedirs(out, exist_ok=True)
for name in ('host', 'guest'):
    src = os.path.join(here, name)
    with tarfile.open(os.path.join(out, name + 'kit.tar'), 'w', format=tarfile.GNU_FORMAT) as t:
        for root, dirs, files in os.walk(src):
            dirs.sort()
            for f in sorted(files):
                p = os.path.join(root, f)
                ti = t.gettarinfo(p, arcname=os.path.relpath(p, src))
                ti.uid = ti.gid = 0; ti.uname = ti.gname = ''
                with open(p, 'rb') as fh: t.addfile(ti, fh)
print('kits written to', os.path.abspath(out))
