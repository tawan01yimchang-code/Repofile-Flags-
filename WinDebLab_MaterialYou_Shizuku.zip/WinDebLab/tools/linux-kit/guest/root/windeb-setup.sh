#!/bin/bash
# Installs XFCE + a macOS look (WhiteSur theme/icons/cursors, Plank dock, top menu bar) + VNC/noVNC.
export DEBIAN_FRONTEND=noninteractive LANG=C.UTF-8
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
MARK=/root/.windeb-desktop-ok
step() { echo; echo "==> $*"; }

step "Preparing package manager"
dpkg --configure -a || true
apt-get update || { echo "apt update failed: check internet connection"; exit 1; }

step "Installing XFCE desktop, VNC server and noVNC (this takes a while)"
PKGS="xfce4 xfce4-terminal xfce4-whiskermenu-plugin xfce4-notifyd xfce4-appfinder thunar mousepad \
 dbus-x11 x11-xserver-utils x11-utils tigervnc-standalone-server novnc websockify \
 plank adwaita-icon-theme librsvg2-common gtk2-engines-murrine gtk2-engines-pixbuf \
 fonts-inter fonts-noto-core fonts-dejavu-core procps sudo nano git curl wget ca-certificates \
 sassc libglib2.0-dev-bin libxml2-utils"
for i in 1 2 3; do
  apt-get install -y --no-install-recommends $PKGS && break
  echo "retrying ($i)..."; apt-get -f install -y || true
done
command -v Xtigervnc >/dev/null || { echo "Xtigervnc missing: install failed"; exit 1; }

step "macOS look: WhiteSur GTK theme"
mkdir -p /opt/windeb-theme && cd /opt/windeb-theme
if [ ! -d /usr/share/themes/WhiteSur-Dark ]; then
  rm -rf WhiteSur-gtk-theme
  git clone --depth=1 https://github.com/vinceliuice/WhiteSur-gtk-theme.git \
    && (cd WhiteSur-gtk-theme && ./install.sh -d /usr/share/themes) || echo "WARNING: GTK theme not installed, falling back to Adwaita-dark"
fi
step "macOS look: WhiteSur icons"
if [ ! -d /usr/share/icons/WhiteSur-dark ]; then
  rm -rf WhiteSur-icon-theme
  git clone --depth=1 https://github.com/vinceliuice/WhiteSur-icon-theme.git \
    && (cd WhiteSur-icon-theme && ./install.sh -d /usr/share/icons) || echo "WARNING: icon theme not installed"
fi
step "macOS look: WhiteSur cursors"
if [ ! -d /usr/share/icons/WhiteSur-cursors ]; then
  rm -rf WhiteSur-cursors
  git clone --depth=1 https://github.com/vinceliuice/WhiteSur-cursors.git \
    && (cd WhiteSur-cursors && ./install.sh) || echo "WARNING: cursor theme not installed"
fi

X=/root/.config/xfce4/xfconf/xfce-perchannel-xml
if [ ! -d /usr/share/themes/WhiteSur-Dark ]; then
  sed -i 's/WhiteSur-Dark/Adwaita-dark/' $X/xsettings.xml
  sed -i 's/value="WhiteSur-Dark"/value="Default"/' $X/xfwm4.xml
fi
[ -d /usr/share/icons/WhiteSur-dark ] || sed -i 's/WhiteSur-dark/Adwaita/' $X/xsettings.xml
[ -d /usr/share/icons/WhiteSur-cursors ] || sed -i 's/WhiteSur-cursors/Adwaita/' $X/xsettings.xml
fc-cache -f >/dev/null 2>&1 || true

touch "$MARK"
echo
echo "DONE. Close this screen and tap 'Start XFCE desktop' in WinDeb Lab."
