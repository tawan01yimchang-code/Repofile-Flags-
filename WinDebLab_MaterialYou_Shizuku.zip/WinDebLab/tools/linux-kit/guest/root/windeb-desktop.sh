#!/bin/bash
# Starts Xtigervnc + XFCE + websockify/noVNC. Viewed in-app through a WebView on 127.0.0.1:6080.
GEOM="${WINDEB_GEOMETRY:-1280x720}"
export DISPLAY=:1 XDG_SESSION_TYPE=x11 XDG_CURRENT_DESKTOP=XFCE GDK_BACKEND=x11 LIBGL_ALWAYS_SOFTWARE=1
export XDG_RUNTIME_DIR=/tmp/runtime-root
mkdir -p "$XDG_RUNTIME_DIR" && chmod 700 "$XDG_RUNTIME_DIR"
pkill -x Xtigervnc 2>/dev/null; pkill -f 'websockify' 2>/dev/null
rm -f /tmp/.X1-lock /tmp/.X11-unix/X1
echo "[windeb] starting VNC server ($GEOM)"
Xtigervnc :1 -geometry "$GEOM" -depth 24 -rfbport 5901 -localhost -SecurityTypes None -AlwaysShared >/tmp/xvnc.log 2>&1 &
sleep 2
echo "[windeb] starting noVNC on 127.0.0.1:6080"
websockify --web /usr/share/novnc 127.0.0.1:6080 127.0.0.1:5901 >/tmp/websockify.log 2>&1 &
eval "$(dbus-launch --sh-syntax)"
export DBUS_SESSION_BUS_ADDRESS
echo "[windeb] starting XFCE"
startxfce4 >/tmp/xfce.log 2>&1 &
(
  sleep 6
  for i in 1 2 3 4 5 6 7 8; do
    for p in $(xfconf-query -c xfce4-desktop -l 2>/dev/null | grep last-image); do
      xfconf-query -c xfce4-desktop -p "$p" -s /usr/share/backgrounds/windeb-mac.jpg
    done
    sleep 3
  done
  D=/net/launchpad/plank/docks/dock1/
  S=net.launchpad.plank.dock.settings:$D
  gsettings set $S theme 'Transparent' 2>/dev/null
  gsettings set $S icon-size 48 2>/dev/null
  gsettings set $S zoom-enabled true 2>/dev/null
) &
echo "[windeb] desktop session is up"
wait
