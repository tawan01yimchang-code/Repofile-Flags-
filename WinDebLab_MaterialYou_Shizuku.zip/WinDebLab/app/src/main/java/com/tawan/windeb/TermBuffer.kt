package com.tawan.windeb

import android.graphics.Color
import android.text.Editable
import android.text.Spanned
import android.text.style.ForegroundColorSpan

/** Minimal terminal emulator for a line-oriented shell: SGR colors, \r, \b, clear screen; other escapes are dropped. */
class TermBuffer(private val ed: Editable, private val defaultFg: Int) {
  private var inEsc = false
  private var csi = false
  private var osc = false
  private var skipNext = false
  private var seq = StringBuilder()
  private var cr = false
  private var fg = defaultFg
  private val run = StringBuilder()

  private val ansi = intArrayOf(
    0xFF3B4252.toInt(), 0xFFE06C75.toInt(), 0xFF98C379.toInt(), 0xFFE5C07B.toInt(),
    0xFF61AFEF.toInt(), 0xFFC678DD.toInt(), 0xFF56B6C2.toInt(), 0xFFDCDFE4.toInt(),
    0xFF5C6370.toInt(), 0xFFFF7B86.toInt(), 0xFFB5E890.toInt(), 0xFFF0D090.toInt(),
    0xFF7FC4FF.toInt(), 0xFFE08CFF.toInt(), 0xFF7BDDE8.toInt(), 0xFFFFFFFF.toInt()
  )

  fun feed(text: String) {
    for (ch in text) handle(ch)
    flush()
    trim()
  }

  fun clear() { ed.clear(); run.setLength(0); cr = false }

  private fun flush() {
    if (run.isEmpty()) return
    val start = ed.length
    ed.append(run)
    if (fg != defaultFg) ed.setSpan(ForegroundColorSpan(fg), start, ed.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    run.setLength(0)
  }

  private fun trim() {
    if (ed.length > 120_000) ed.delete(0, 40_000)
  }

  private fun lineStart(): Int {
    var i = ed.length - 1
    while (i >= 0 && ed[i] != '\n') i--
    return i + 1
  }

  private fun handle(c: Char) {
    if (skipNext) { skipNext = false; return }
    if (osc) {
      if (c == '\u0007') osc = false
      else if (c == '\u001b') { osc = false; skipNext = true }
      return
    }
    if (csi) {
      seq.append(c)
      if (c in '@'..'~') { csi = false; inEsc = false; csiDone(c, seq.toString().dropLast(1)); seq = StringBuilder() }
      return
    }
    if (inEsc) {
      when (c) {
        '[' -> { csi = true; seq = StringBuilder() }
        ']' -> { osc = true; inEsc = false }
        '(', ')', '*', '+' -> { skipNext = true; inEsc = false }
        else -> inEsc = false
      }
      return
    }
    when (c) {
      '\u001b' -> inEsc = true
      '\r' -> { flush(); cr = true }
      '\n' -> { cr = false; run.append('\n') }
      '\b' -> { flush(); if (ed.isNotEmpty() && ed[ed.length - 1] != '\n') ed.delete(ed.length - 1, ed.length) }
      '\u0007', '\u0000' -> {}
      else -> {
        if (cr) { flush(); ed.delete(lineStart(), ed.length); cr = false }
        run.append(c)
      }
    }
  }

  private fun csiDone(fin: Char, params: String) {
    when (fin) {
      'm' -> { flush(); sgr(params) }
      'J' -> if (params == "2" || params == "3") { flush(); ed.clear() }
      else -> {}
    }
  }

  private fun sgr(params: String) {
    val p = if (params.isEmpty()) listOf(0) else params.split(';').map { it.toIntOrNull() ?: 0 }
    var i = 0
    while (i < p.size) {
      val n = p[i]
      when {
        n == 0 || n == 39 -> fg = defaultFg
        n in 30..37 -> fg = ansi[n - 30]
        n in 90..97 -> fg = ansi[n - 90 + 8]
        n == 38 && i + 2 < p.size && p[i + 1] == 5 -> { fg = xterm256(p[i + 2]); i += 2 }
        n == 38 && i + 4 < p.size && p[i + 1] == 2 -> { fg = Color.rgb(p[i + 2], p[i + 3], p[i + 4]); i += 4 }
        n == 48 -> i += if (i + 1 < p.size && p[i + 1] == 5) 2 else if (i + 1 < p.size && p[i + 1] == 2) 4 else 0
      }
      i++
    }
  }

  private fun xterm256(n: Int): Int = when {
    n < 16 -> ansi[n.coerceAtLeast(0)]
    n < 232 -> {
      val v = n - 16
      val lv = intArrayOf(0, 95, 135, 175, 215, 255)
      Color.rgb(lv[v / 36], lv[(v / 6) % 6], lv[v % 6])
    }
    else -> { val g = 8 + (n - 232) * 10; Color.rgb(g, g, g) }
  }
}
