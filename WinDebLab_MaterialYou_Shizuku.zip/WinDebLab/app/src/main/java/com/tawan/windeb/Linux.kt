package com.tawan.windeb

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.lang.reflect.InvocationTargetException
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.util.zip.GZIPInputStream
import rikka.shizuku.Shizuku

/**
 * Real Linux runtime for WinDeb Lab.
 *
 * Android blocks apps from executing downloaded binaries, so everything runs as the ADB shell user through
 * Shizuku: proot + a Debian rootfs live in /data/local/tmp/windeb (shell-owned, executable) and are started
 * with `sh login.sh <command>`. No Termux and no external terminal app is used.
 */
object Linux {
  const val BASE = "/data/local/tmp/windeb"
  const val LOGIN = "$BASE/login.sh"
  const val DESKTOP_MARK = "$BASE/rootfs/root/.windeb-desktop-ok"
  const val NOVNC_PORT = 6080
  private const val UA = "WinDebLab/2.0"

  fun arch(): String = when (Build.SUPPORTED_ABIS.firstOrNull()) {
    "arm64-v8a" -> "aarch64"
    "armeabi-v7a" -> "armv7"
    "x86_64" -> "x86_64"
    "x86" -> "x86"
    else -> "aarch64"
  }

  private fun debianBranch(): String = when (arch()) {
    "aarch64" -> "dist-arm64v8"
    "armv7" -> "dist-arm32v7"
    "x86_64" -> "dist-amd64"
    else -> "dist-i386"
  }

  private fun prootUrls() = listOf(
    "https://skirsten.github.io/proot-portable-android-binaries/${arch()}/proot"
  )

  private fun rootfsUrls() = listOf(
    "https://github.com/debuerreotype/docker-debian-artifacts/raw/refs/heads/${debianBranch()}/bookworm/slim/oci/blobs/rootfs.tar.gz",
    "https://github.com/debuerreotype/docker-debian-artifacts/raw/refs/heads/${debianBranch()}/trixie/slim/oci/blobs/rootfs.tar.gz"
  )

  // ------------------------------------------------------------------ Shizuku shell

  fun shizukuReady(): Boolean = try {
    Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
  } catch (_: Throwable) { false }

  /** Starts a process as the ADB shell user. Shizuku 13 keeps newProcess private, so it is called reflectively. */
  fun spawn(cmd: Array<String>): Process {
    val m = Shizuku::class.java.getDeclaredMethod(
      "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
    )
    m.isAccessible = true
    try {
      return m.invoke(null, cmd, null, null) as Process
    } catch (e: InvocationTargetException) {
      throw e.targetException ?: e
    }
  }

  fun sh(script: String): Process = spawn(arrayOf("sh", "-c", script))

  /** Runs a short shell snippet and returns (exit code, combined output). */
  fun run(script: String): Pair<Int, String> {
    val p = sh("exec 2>&1; $script")
    try { p.outputStream.close() } catch (_: Exception) {}
    val out = p.inputStream.bufferedReader().readText()
    return p.waitFor() to out
  }

  /** Logs in to the Debian rootfs and runs [cmd] (default: bash). */
  fun loginProcess(vararg cmd: String): Process = spawn(arrayOf("sh", LOGIN) + cmd)

  /** Kills every process whose command line contains [tag] (used to stop terminals / the desktop). */
  fun killTag(tag: String) {
    try { sh("pkill -9 -f '$tag'; exit 0").waitFor() } catch (_: Throwable) {}
  }

  // ------------------------------------------------------------------ state checks

  fun prootInstalled(): Boolean = run("[ -x $BASE/proot ] && echo Y").second.contains("Y")
  fun rootfsInstalled(): Boolean = run("[ -e $BASE/rootfs/etc/debian_version ] && echo Y").second.contains("Y")
  fun desktopInstalled(): Boolean = run("[ -e $DESKTOP_MARK ] && echo Y").second.contains("Y")
  fun installed(): Boolean = prootInstalled() && rootfsInstalled() && run("[ -f $LOGIN ] && echo Y").second.contains("Y")

  fun desktopPortOpen(): Boolean = try {
    Socket().use { it.connect(InetSocketAddress("127.0.0.1", NOVNC_PORT), 400); true }
  } catch (_: Exception) { false }

  // ------------------------------------------------------------------ provisioning

  private fun assetNames(ctx: Context): Set<String> =
    try { ctx.assets.list("linux")?.toSet() ?: emptySet() } catch (_: Exception) { emptySet() }

  private fun copy(input: InputStream, out: java.io.OutputStream, onBytes: (Long) -> Unit): Long {
    val buf = ByteArray(64 * 1024)
    var total = 0L
    while (true) {
      val n = input.read(buf)
      if (n < 0) break
      out.write(buf, 0, n)
      total += n
      onBytes(total)
    }
    out.flush()
    return total
  }

  private fun download(urls: List<String>, dest: File, log: (String, Int) -> Unit, label: String) {
    var last: Exception? = null
    for (u in urls) {
      try {
        var conn = URL(u).openConnection() as HttpURLConnection
        conn.connectTimeout = 20000
        conn.readTimeout = 30000
        conn.setRequestProperty("User-Agent", UA)
        conn.instanceFollowRedirects = true
        var redirects = 0
        while (conn.responseCode in 300..399 && redirects < 5) {
          val loc = conn.getHeaderField("Location") ?: break
          conn = URL(URL(u), loc).openConnection() as HttpURLConnection
          conn.connectTimeout = 20000
          conn.readTimeout = 30000
          conn.setRequestProperty("User-Agent", UA)
          redirects++
        }
        if (conn.responseCode != 200) throw RuntimeException("HTTP ${conn.responseCode}")
        val total = conn.contentLengthLong
        val part = File(dest.path + ".part")
        conn.inputStream.use { ins ->
          FileOutputStream(part).use { fos ->
            var lastPct = -1
            copy(ins, fos) { done ->
              val pct = if (total > 0) (done * 100 / total).toInt() else -1
              if (pct != lastPct) {
                lastPct = pct
                log("$label: ${done / 1048576} MB" + if (total > 0) " / ${total / 1048576} MB" else "", pct)
              }
            }
          }
        }
        if (dest.exists()) dest.delete()
        if (!part.renameTo(dest)) throw RuntimeException("rename failed")
        return
      } catch (e: Exception) {
        last = e
        log("$label: ${e.message} ($u)", -1)
      }
    }
    throw RuntimeException("Download failed: ${last?.message}")
  }

  /** Streams [input] into a remote file written as the shell user. */
  private fun push(input: InputStream, remote: String, mode: String, onBytes: (Long) -> Unit) {
    val p = sh("exec 2>&1; cat > '$remote.part' && chmod $mode '$remote.part' && mv '$remote.part' '$remote'")
    p.outputStream.use { copy(input, it, onBytes) }
    val out = p.inputStream.bufferedReader().readText()
    val code = p.waitFor()
    if (code != 0) throw RuntimeException("push $remote failed ($code): $out")
  }

  /** Streams a plain tar into [dir] with the shell user's tar. Non-zero exit is tolerated (mknod/chown errors). */
  private fun untar(input: InputStream, dir: String, onBytes: (Long) -> Unit): String {
    val p = sh("exec 2>&1; mkdir -p '$dir' && cd '$dir' && tar -xf -")
    p.outputStream.use { copy(input, it, onBytes) }
    val out = p.inputStream.bufferedReader().readText()
    p.waitFor()
    return out
  }

  /**
   * Installs proot + Debian. Uses files from app/src/main/assets/linux when present
   * (proot-<arch>, rootfs-<arch>.tar.gz), otherwise downloads them on first run.
   * [log] receives a message and a percentage (-1 = indeterminate).
   */
  fun provision(ctx: Context, log: (String, Int) -> Unit) {
    val arch = arch()
    val assets = assetNames(ctx)

    log("เตรียมโฟลเดอร์ระบบ", -1)
    val mk = run("mkdir -p $BASE/tmp $BASE/rootfs && echo OK")
    if (!mk.second.contains("OK")) throw RuntimeException("สร้าง $BASE ไม่ได้: ${mk.second}")

    log("ติดตั้งสคริปต์ควบคุม", -1)
    ctx.assets.open("linux/hostkit.tar").use { untar(it, BASE) { } }
    run("chmod 755 $LOGIN")

    // proot
    if (!prootInstalled()) {
      val assetName = "proot-$arch"
      if (assetName in assets) {
        log("ติดตั้ง proot (จากในแอป)", -1)
        ctx.assets.open("linux/$assetName").use { push(it, "$BASE/proot", "755") { } }
      } else {
        val f = File(ctx.cacheDir, "proot-$arch")
        log("ดาวน์โหลด proot", 0)
        download(prootUrls(), f, log, "proot")
        if (f.length() < 100_000) throw RuntimeException("ไฟล์ proot ไม่สมบูรณ์")
        log("ติดตั้ง proot", -1)
        f.inputStream().use { push(it, "$BASE/proot", "755") { } }
        f.delete()
      }
    }

    // rootfs
    if (!rootfsInstalled()) {
      val gzAsset = "rootfs-$arch.tar.gz"
      val tarAsset = "rootfs-$arch.tar"
      val input: InputStream
      var cached: File? = null
      when {
        gzAsset in assets -> input = GZIPInputStream(BufferedInputStream(ctx.assets.open("linux/$gzAsset"), 1 shl 16))
        tarAsset in assets -> input = BufferedInputStream(ctx.assets.open("linux/$tarAsset"), 1 shl 16)
        else -> {
          val f = File(ctx.filesDir, "rootfs-$arch.tar.gz")
          if (!f.exists() || f.length() < 5_000_000) {
            log("ดาวน์โหลด Debian rootfs", 0)
            download(rootfsUrls(), f, log, "Debian")
          }
          cached = f
          input = GZIPInputStream(BufferedInputStream(f.inputStream(), 1 shl 16))
        }
      }
      log("แตกไฟล์ Debian (อาจใช้เวลาหลายนาที)", -1)
      var lastMb = -1L
      val tarOut = input.use {
        untar(it, "$BASE/rootfs") { b ->
          val mb = b / 1048576
          if (mb != lastMb) { lastMb = mb; log("แตกไฟล์ Debian: $mb MB", -1) }
        }
      }
      // some rootfs archives wrap everything in one top-level folder
      run("cd $BASE/rootfs && if [ ! -e etc ]; then set -- */; if [ \$# -eq 1 ] && [ -d \"\$1\" ]; then mv \"\$1\"/* \"\$1\"/.[!.]* . 2>/dev/null; rmdir \"\$1\" 2>/dev/null; fi; fi")
      if (!rootfsInstalled()) throw RuntimeException("แตกไฟล์ rootfs ไม่สำเร็จ: ${tarOut.take(400)}")
      cached?.delete()
    }

    log("ติดตั้งไฟล์ตั้งค่าและธีม macOS", -1)
    run("rm -f $BASE/rootfs/etc/resolv.conf; true") // may be a dangling symlink in the base image
    ctx.assets.open("linux/guestkit.tar").use { untar(it, "$BASE/rootfs") { } }

    log("ทดสอบรัน Debian", -1)
    val t = run("sh $LOGIN /bin/echo windeb-ok")
    if (!t.second.contains("windeb-ok")) {
      throw RuntimeException("proot รัน Debian ไม่ได้ (exit ${t.first}): ${t.second.take(500)}")
    }
    log("พร้อมใช้งาน", 100)
  }

  fun removeAll(): String = run("pkill -9 -f '$BASE/proot'; rm -rf $BASE; echo done").second

  /** Optional: stop Android 12+ from killing background shell children ("phantom process killer"). */
  fun relaxPhantomKiller(): String = run(
    "settings put global settings_enable_monitor_phantom_procs false; " +
      "device_config put activity_manager max_phantom_processes 2147483647; echo done"
  ).second

  // ------------------------------------------------------------------ desktop session

  @Volatile private var desktopProc: Process? = null
  @Volatile var desktopLog: String = ""
    private set

  fun startDesktop(geometry: String) {
    if (desktopPortOpen()) return
    killTag("windeb-desktop.sh")
    desktopLog = ""
    val p = loginProcess("WINDEB_GEOMETRY=$geometry", "/root/windeb-desktop.sh")
    desktopProc = p
    Thread {
      try {
        p.outputStream.close()
        p.inputStream.bufferedReader().forEachLine { line ->
          desktopLog = (desktopLog + line + "\n").takeLast(4000)
        }
      } catch (_: Exception) {}
    }.start()
  }

  fun stopDesktop() {
    killTag("windeb-desktop.sh")
    try { desktopProc?.destroy() } catch (_: Throwable) {}
    desktopProc = null
  }
}
