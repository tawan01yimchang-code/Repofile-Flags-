package com.tawan.windeb

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.widget.TextView

// Material You inspired tonal palette. Dynamic system colors are applied on Android 12+.
val BG = 0xFF101318.toInt()
val SURFACE = 0xFF191D24.toInt()
val CARD = 0xFF202630.toInt()
val ACCENT = 0xFFB4C5FF.toInt()
val GREEN = 0xFF9CCFB0.toInt()
val MUTED = 0xFFC1C7D0.toInt()
val OUTLINE = 0xFF414750.toInt()
val ON_SURFACE = 0xFFE1E2E9.toInt()

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun Context.shape(color: Int, radius: Int = 0, strokeW: Int = 0, strokeC: Int = 0) = GradientDrawable().apply {
  setColor(color)
  cornerRadius = dp(radius).toFloat()
  if (strokeW > 0) setStroke(dp(strokeW), strokeC)
}

fun Context.label(t: String, size: Float = 14f, color: Int = ON_SURFACE, bold: Boolean = false) = TextView(this).apply {
  text = t
  textSize = size
  setTextColor(color)
  if (bold) setTypeface(typeface, Typeface.BOLD)
  includeFontPadding = true
}
