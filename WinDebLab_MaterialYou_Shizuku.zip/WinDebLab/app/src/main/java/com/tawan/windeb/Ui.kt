package com.tawan.windeb

import android.app.Activity
import android.content.Context
import android.content.res.Configuration
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.widget.TextView
import com.google.android.material.button.MaterialButton
import com.google.android.material.color.MaterialColors

// Fixed palette: used only by the Desktop Simulator (it is intentionally NOT Material You).
val BG = 0xFF101318.toInt()
val SURFACE = 0xFF191D24.toInt()
val CARD = 0xFF202630.toInt()
val ACCENT = 0xFFB4C5FF.toInt()
val GREEN = 0xFF9CCFB0.toInt()
val MUTED = 0xFFC1C7D0.toInt()
val OUTLINE = 0xFF414750.toInt()
val ON_SURFACE = 0xFFE1E2E9.toInt()

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun Context.shape(color: Int, radius: Int = 0, strokeW: Int = 0, strokeC: Int = 0) = GradientDrawable().apply {
  setColor(color)
  cornerRadius = dp(radius).toFloat()
  if (strokeW > 0) setStroke(dp(strokeW), strokeC)
}

fun Context.label(t: String, size: Float = 14f, color: Int = ON_SURFACE, bold: Boolean = false) = TextView(this).apply {
  text = t
  textSize = size
  setTextColor(color)
  if (bold) setTypeface(typeface, Typeface.BOLD)
  includeFontPadding = true
}

// ---- Material You (dynamic color) palette for the app shell: follows the device colors ----
class Pal(
  val bg: Int, val surface: Int, val card: Int, val accent: Int, val onAccent: Int,
  val accent2: Int, val text: Int, val muted: Int, val outline: Int
)

fun Context.pal(): Pal {
  fun c(attr: Int, fb: Int) = MaterialColors.getColor(this, attr, fb)
  val a = com.google.android.material.R.attr.colorSurface
  return Pal(
    bg = c(a, BG),
    surface = c(com.google.android.material.R.attr.colorSurfaceContainer, SURFACE),
    card = c(com.google.android.material.R.attr.colorSurfaceContainerHigh, CARD),
    accent = c(com.google.android.material.R.attr.colorPrimary, ACCENT),
    onAccent = c(com.google.android.material.R.attr.colorOnPrimary, 0xFF1B2B4B.toInt()),
    accent2 = c(com.google.android.material.R.attr.colorTertiary, GREEN),
    text = c(com.google.android.material.R.attr.colorOnSurface, ON_SURFACE),
    muted = c(com.google.android.material.R.attr.colorOnSurfaceVariant, MUTED),
    outline = c(com.google.android.material.R.attr.colorOutlineVariant, OUTLINE)
  )
}

fun Activity.styleBars(p: Pal) {
  window.statusBarColor = p.bg
  window.navigationBarColor = p.bg
  val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
  var f = window.decorView.systemUiVisibility
  val light = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
  f = if (night) f and light.inv() else f or light
  window.decorView.systemUiVisibility = f
}

fun Context.mbtn(t: String, outlined: Boolean = false): MaterialButton = MaterialButton(
  this, null,
  if (outlined) com.google.android.material.R.attr.materialButtonOutlinedStyle
  else com.google.android.material.R.attr.materialButtonStyle
).apply {
  text = t
  cornerRadius = dp(16)
  minimumHeight = dp(50)
}
