package com.tawan.windeb

import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.google.android.material.color.DynamicColors
import java.io.InputStreamReader
import java.util.concurrent.Executors

/**
 * Built-in Linux terminal. Runs bash (or a given command) inside the Debian rootfs through Shizuku.
 * A pty is created inside the guest with `script`, so line editing, Ctrl+C and job control behave normally.
 */
class TerminalActivity : Activity() {
  companion object {
    const val EXTRA_TITLE = "title"
    const val EXTRA_CMD = "cmd"
    private var counter = 0
  }

  private lateinit var out: TextView
  private lateinit var scroll: ScrollView
  private lateinit var input: EditText
  private lateinit var term: TermBuffer
  private var proc: Process? = null
  private var alive = false
  private val ui = Handler(Looper.getMainLooper())
  private val writer = Executors.newSingleThreadExecutor()
  private val tag = "windeb-term-${System.nanoTime()}-${counter++}"

  override fun onCreate(savedInstanceState: Bundle?) {
    DynamicColors.applyToActivityIfAvailable(this)
    super.onCreate(savedInstanceState)
    val p = pal()
    styleBars(p)

    val page = LinearLayout(this).apply {
      orientation = LinearLayout.VERTICAL
      setBackgroundColor(p.bg)
      setPadding(dp(12), dp(14), dp(12), dp(10))
    }
    page.addView(label(intent.getStringExtra(EXTRA_TITLE) ?: "Terminal", 20f, p.text, true))
    page.addView(label("Debian • proot • Shizuku", 12f, p.accent, true).apply { setPadding(0, dp(2), 0, dp(10)) })

    val termBg = 0xFF0D1117.toInt()
    out = TextView(this).apply {
      typeface = Typeface.MONOSPACE
      textSize = 12.5f
      setTextColor(0xFFE6EDF3.toInt())
      setPadding(dp(10), dp(8), dp(10), dp(8))
      setTextIsSelectable(true)
    }
    out.setText("", TextView.BufferType.EDITABLE)
    term = TermBuffer(out.editableText, 0xFFE6EDF3.toInt())
    scroll = ScrollView(this).apply {
      background = shape(termBg, 16, 1, p.outline)
      isFillViewport = true
      addView(out)
    }
    page.addView(scroll, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))

    // quick keys
    val keys = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
    fun key(name: String, seq: String?, action: (() -> Unit)? = null) {
      keys.addView(mbtn(name, true).apply {
        minimumHeight = dp(40); minimumWidth = 0
        setPadding(dp(14), 0, dp(14), 0)
        setOnClickListener { if (action != null) action() else send(seq!!) }
      }, LinearLayout.LayoutParams(WRAP_CONTENT, dp(40)).apply { rightMargin = dp(6) })
    }
    key("Tab", "\t"); key("Ctrl+C", "\u0003"); key("Ctrl+D", "\u0004"); key("Esc", "\u001b")
    key("Up", "\u001b[A"); key("Down", "\u001b[B"); key("Left", "\u001b[D"); key("Right", "\u001b[C")
    key("Clear", null) { term.clear() }
    page.addView(HorizontalScrollView(this).apply {
      isHorizontalScrollBarEnabled = false
      addView(keys)
    }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(8) })

    // input row
    val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    input = EditText(this).apply {
      typeface = Typeface.MONOSPACE
      textSize = 14f
      hint = "พิมพ์คำสั่ง แล้วกด Enter"
      setTextColor(p.text)
      setHintTextColor(p.muted)
      background = shape(p.surface, 16, 1, p.outline)
      setPadding(dp(14), dp(10), dp(14), dp(10))
      isSingleLine = true
      imeOptions = EditorInfo.IME_ACTION_SEND
      inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or
        InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
      setOnEditorActionListener { _, _, _ -> submit(); true }
      setOnKeyListener { _, code, ev ->
        if (code == KeyEvent.KEYCODE_ENTER && ev.action == KeyEvent.ACTION_DOWN) { submit(); true } else false
      }
    }
    row.addView(input, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
    row.addView(mbtn("ส่ง").apply { setOnClickListener { submit() } },
      LinearLayout.LayoutParams(WRAP_CONTENT, dp(48)).apply { leftMargin = dp(8) })
    page.addView(row, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(8) })
    setContentView(page)

    if (!Linux.shizukuReady()) {
      term.feed("Shizuku ยังไม่พร้อม กลับไปหน้า Linux แล้วกด ตรวจสอบ / ขอสิทธิ์ Shizuku ก่อน\n")
      return
    }
    out.post { startSession() }
  }

  private fun startSession() {
    val colsGuess = ((out.width - out.paddingLeft - out.paddingRight) / out.paint.measureText("M")).toInt()
      .coerceIn(30, 200)
    val userCmd = intent.getStringExtra(EXTRA_CMD)
    val inner = "stty cols $colsGuess rows 40 2>/dev/null; : $tag; " + (userCmd ?: "exec /bin/bash -l")
    try {
      val pr = Linux.loginProcess("/usr/bin/script", "-qfc", inner, "/dev/null")
      proc = pr
      alive = true
      Thread {
        try {
          val rd = InputStreamReader(pr.inputStream, Charsets.UTF_8)
          val buf = CharArray(4096)
          while (true) {
            val n = rd.read(buf)
            if (n < 0) break
            val s = String(buf, 0, n)
            ui.post { term.feed(s); scroll.post { scroll.fullScroll(View.FOCUS_DOWN) } }
          }
        } catch (_: Exception) {}
        val code = try { pr.waitFor() } catch (_: Exception) { -1 }
        alive = false
        ui.post { term.feed("\n[ออกจากเซสชันแล้ว • exit $code]\n"); scroll.post { scroll.fullScroll(View.FOCUS_DOWN) } }
      }.start()
    } catch (e: Throwable) {
      term.feed("เริ่มเทอร์มินัลไม่ได้: ${e.message}\n")
    }
  }

  private fun submit() {
    val t = input.text.toString()
    input.setText("")
    send(t + "\n")
  }

  private fun send(s: String) {
    val pr = proc ?: return
    if (!alive) return
    writer.execute {
      try { pr.outputStream.write(s.toByteArray(Charsets.UTF_8)); pr.outputStream.flush() } catch (_: Exception) {}
    }
  }

  override fun onDestroy() {
    val pr = proc
    proc = null
    if (pr != null) {
      Thread {
        Linux.killTag(tag)
        try { pr.destroy() } catch (_: Throwable) {}
      }.start()
    }
    writer.shutdown()
    super.onDestroy()
  }
}
