package com.tawan.windeb

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import com.google.android.material.color.DynamicColors

class MainActivity : Activity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    DynamicColors.applyToActivityIfAvailable(this)
    super.onCreate(savedInstanceState)
    window.statusBarColor = BG
    window.navigationBarColor = BG

    val page = LinearLayout(this).apply {
      orientation = LinearLayout.VERTICAL
      setPadding(dp(20), dp(26), dp(20), dp(24))
      setBackgroundColor(BG)
    }
    page.addView(label("WinDeb Lab", 29f, ON_SURFACE, true))
    page.addView(label("พื้นที่ทำงาน Linux และ Desktop บน Android", 13f, MUTED).apply {
      setPadding(0, dp(4), 0, dp(22))
    })

    val hero = LinearLayout(this).apply {
      orientation = LinearLayout.VERTICAL
      setPadding(dp(18), dp(18), dp(18), dp(18))
      background = shape(SURFACE, 24)
    }
    hero.addView(label("WORKSPACE", 11f, ACCENT, true))
    hero.addView(label("เลือกสภาพแวดล้อมที่ต้องการ", 19f, ON_SURFACE, true).apply {
      setPadding(0, dp(7), 0, dp(5))
    })
    hero.addView(label("เปิดเดสก์ท็อปจำลองได้ทันที หรือเชื่อมต่อ Shizuku ก่อนเริ่มตั้งค่า Linux", 13f, MUTED))
    page.addView(hero, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(16) })

    page.addView(modeCard(
      "01", "Start Linux", "Debian Desktop Environment",
      "เชื่อมต่อ Shizuku และตรวจสอบสิทธิ์ก่อนเริ่มระบบ Linux", ACCENT
    ) { startActivity(Intent(this, LinuxDesktopActivity::class.java)) })

    page.addView(modeCard(
      "02", "Desktop Simulator", "Desktop จำลองภายในแอป",
      "ใช้งานหน้าต่าง แอปพื้นฐาน แถบงาน และตัวจัดการไฟล์ได้ทันที", GREEN
    ) { startActivity(Intent(this, DesktopSimulatorActivity::class.java)) })

    val about = Button(this).apply {
      text = "เกี่ยวกับ WinDeb Lab"
      isAllCaps = false
      setTextColor(ACCENT)
      setBackgroundTintList(android.content.res.ColorStateList.valueOf(SURFACE))
      setOnClickListener { startActivity(Intent(this@MainActivity, AboutActivity::class.java)) }
    }
    page.addView(about, LinearLayout.LayoutParams(MATCH_PARENT, dp(52)).apply { topMargin = dp(12) })
    page.addView(label("WINDEB LAB • ANDROID", 10f, MUTED).apply {
      gravity = Gravity.CENTER
      setPadding(0, dp(24), 0, 0)
    })
    setContentView(ScrollView(this).apply { isFillViewport = true; addView(page) })
  }

  private fun modeCard(number: String, title: String, subtitle: String, detail: String, accent: Int, click: () -> Unit): View {
    val card = LinearLayout(this).apply {
      orientation = LinearLayout.VERTICAL
      setPadding(dp(18), dp(17), dp(18), dp(16))
      background = shape(CARD, 22, 1, OUTLINE)
      layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(14) }
    }
    card.addView(label(number, 12f, accent, true))
    card.addView(label(title, 21f, ON_SURFACE, true).apply { setPadding(0, dp(6), 0, dp(2)) })
    card.addView(label(subtitle, 13f, accent, true))
    card.addView(label(detail, 13f, MUTED).apply { setPadding(0, dp(9), 0, dp(13)) })
    card.addView(Button(this).apply {
      text = if (title == "Start Linux") "ตั้งค่าและเริ่ม Linux" else "เปิด Desktop Simulator"
      isAllCaps = false
      setOnClickListener { click() }
    }, LinearLayout.LayoutParams(MATCH_PARENT, dp(50)))
    return card
  }
}
