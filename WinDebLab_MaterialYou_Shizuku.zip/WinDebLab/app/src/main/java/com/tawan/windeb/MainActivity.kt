package com.tawan.windeb

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.LinearLayout
import android.widget.ScrollView
import com.google.android.material.color.DynamicColors

class MainActivity : Activity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    DynamicColors.applyToActivityIfAvailable(this)
    super.onCreate(savedInstanceState)
    val p = pal()
    styleBars(p)

    val page = LinearLayout(this).apply {
      orientation = LinearLayout.VERTICAL
      setPadding(dp(20), dp(26), dp(20), dp(24))
      setBackgroundColor(p.bg)
    }
    page.addView(label("WinDeb Lab", 29f, p.text, true))
    page.addView(label("พื้นที่ทำงาน Linux และ Desktop บน Android", 13f, p.muted).apply {
      setPadding(0, dp(4), 0, dp(22))
    })

    val hero = LinearLayout(this).apply {
      orientation = LinearLayout.VERTICAL
      setPadding(dp(18), dp(18), dp(18), dp(18))
      background = shape(p.surface, 24)
    }
    hero.addView(label("WORKSPACE", 11f, p.accent, true))
    hero.addView(label("เลือกสภาพแวดล้อมที่ต้องการ", 19f, p.text, true).apply { setPadding(0, dp(7), 0, dp(5)) })
    hero.addView(label("Linux จริงพร้อมเทอร์มินัลในแอป หรือเปิดเดสก์ท็อปจำลองได้ทันที", 13f, p.muted))
    page.addView(hero, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(16) })

    page.addView(modeCard(p, "01", "Start Linux", "Debian • XFCE สไตล์ macOS • Terminal",
      "เชื่อมต่อ Shizuku แล้วติดตั้ง/เริ่ม Debian จริงในแอป ไม่ต้องใช้ Termux", p.accent, "ตั้งค่าและเริ่ม Linux") {
      startActivity(Intent(this, LinuxDesktopActivity::class.java))
    })
    page.addView(modeCard(p, "02", "Desktop Simulator", "Desktop จำลองภายในแอป",
      "ใช้งานหน้าต่าง แอปพื้นฐาน แถบงาน และตัวจัดการไฟล์ได้ทันที", p.accent2, "เปิด Desktop Simulator") {
      startActivity(Intent(this, DesktopSimulatorActivity::class.java))
    })

    page.addView(mbtn("เกี่ยวกับ WinDeb Lab", true).apply {
      setOnClickListener { startActivity(Intent(this@MainActivity, AboutActivity::class.java)) }
    }, LinearLayout.LayoutParams(MATCH_PARENT, dp(52)).apply { topMargin = dp(12) })
    page.addView(label("WINDEB LAB • ANDROID", 10f, p.muted).apply {
      gravity = Gravity.CENTER
      setPadding(0, dp(24), 0, 0)
    })
    setContentView(ScrollView(this).apply { isFillViewport = true; addView(page) })
  }

  private fun modeCard(p: Pal, number: String, title: String, subtitle: String, detail: String,
                       accent: Int, action: String, click: () -> Unit): View {
    val card = LinearLayout(this).apply {
      orientation = LinearLayout.VERTICAL
      setPadding(dp(18), dp(17), dp(18), dp(16))
      background = shape(p.card, 22, 1, p.outline)
      layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(14) }
    }
    card.addView(label(number, 12f, accent, true))
    card.addView(label(title, 21f, p.text, true).apply { setPadding(0, dp(6), 0, dp(2)) })
    card.addView(label(subtitle, 13f, accent, true))
    card.addView(label(detail, 13f, p.muted).apply { setPadding(0, dp(9), 0, dp(13)) })
    card.addView(mbtn(action).apply { setOnClickListener { click() } }, LinearLayout.LayoutParams(MATCH_PARENT, dp(50)))
    return card
  }
}
