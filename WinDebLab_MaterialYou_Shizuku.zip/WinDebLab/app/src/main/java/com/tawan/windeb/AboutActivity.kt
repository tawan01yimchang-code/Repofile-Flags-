package com.tawan.windeb

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import com.google.android.material.color.DynamicColors

class AboutActivity : Activity() {
    private val email = "tawan.01.yimchang@gmail.com"

    override fun onCreate(savedInstanceState: Bundle?) {
        DynamicColors.applyToActivityIfAvailable(this)
        super.onCreate(savedInstanceState)
        val p = pal()
        styleBars(p)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(26), dp(20), dp(28))
            setBackgroundColor(p.bg)
        }
        col.addView(label("WinDeb Lab", 28f, p.text, true))
        col.addView(label("เวอร์ชัน 2.0 • Material You", 13f, p.muted))
        col.addView(label("ผู้พัฒนา", 16f, p.accent, true).apply { setPadding(0, dp(22), 0, dp(5)) })
        col.addView(label(email, 14f, p.text))
        col.addView(mbtn("ส่งอีเมลถึงผู้พัฒนา", true).apply {
            setOnClickListener {
                try { startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$email")).putExtra(Intent.EXTRA_SUBJECT, "WinDeb Lab")) }
                catch (_: Exception) { Toast.makeText(this@AboutActivity, "ไม่พบแอปอีเมล", Toast.LENGTH_SHORT).show() }
            }
        }, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = dp(8) })

        col.addView(label("คุณสมบัติ", 17f, p.accent, true).apply { setPadding(0, dp(24), 0, dp(8)) })
        col.addView(infoCard(p, "Desktop Simulator", "เดสก์ท็อปจำลองภายในแอป พร้อม Taskbar, Start Menu, หน้าต่างหลายใบ, Notepad, Calculator, File Explorer, Browser และ Settings (ไม่ใช้ธีม Material You)"))
        col.addView(infoCard(p, "Linux Environment", "Debian จริงผ่าน proot รันด้วยสิทธิ์ ADB Shell ของ Shizuku มีเทอร์มินัลในแอป และเดสก์ท็อป XFCE สไตล์ macOS แสดงผลในแอปผ่าน noVNC"))
        col.addView(label("ธีมและการแสดงผล", 16f, p.accent, true).apply { setPadding(0, dp(20), 0, dp(6)) })
        col.addView(label("ส่วนแอปใช้สี Material You ตามสีของเครื่อง (Android 12 ขึ้นไป) ส่วน Desktop Simulator ใช้ธีมของตัวเอง", 13f, p.muted))
        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun infoCard(p: Pal, title: String, detail: String) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(15), dp(14), dp(15), dp(14))
        background = shape(p.card, 18, 1, p.outline)
        addView(label(title, 15f, p.text, true))
        addView(label(detail, 13f, p.muted).apply { setPadding(0, dp(6), 0, 0) })
        layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(10) }
    }
}
