package com.tawan.windeb

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import com.google.android.material.color.DynamicColors

class AboutActivity : Activity() {
    private val email = "tawan.01.yimchang@gmail.com"

    override fun onCreate(savedInstanceState: Bundle?) {
        DynamicColors.applyToActivityIfAvailable(this)
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(26), dp(20), dp(28))
            setBackgroundColor(BG)
        }
        col.addView(label("WinDeb Lab", 28f, ON_SURFACE, true))
        col.addView(label("เวอร์ชัน 1.1 • Material You", 13f, MUTED))
        col.addView(label("ผู้พัฒนา", 16f, ACCENT, true).apply { setPadding(0, dp(22), 0, dp(5)) })
        col.addView(label(email, 14f, ON_SURFACE))
        col.addView(Button(this).apply {
            text = "ส่งอีเมลถึงผู้พัฒนา"
            isAllCaps = false
            setOnClickListener {
                try { startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$email")).putExtra(Intent.EXTRA_SUBJECT, "WinDeb Lab")) }
                catch (_: Exception) { Toast.makeText(this@AboutActivity, "ไม่พบแอปอีเมล", Toast.LENGTH_SHORT).show() }
            }
        }, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = dp(8) })

        col.addView(label("คุณสมบัติ", 17f, ACCENT, true).apply { setPadding(0, dp(24), 0, dp(8)) })
        col.addView(infoCard("Desktop Simulator", "เดสก์ท็อปจำลองภายในแอป พร้อม Taskbar, Start Menu, หน้าต่างหลายใบ, Notepad, Calculator, File Explorer, Browser และ Settings"))
        col.addView(infoCard("Linux Environment", "ส่วนเชื่อมต่อ Shizuku สำหรับตรวจสอบและขอสิทธิ์ ADB Shell ยังต้องเพิ่ม embedded proot และ Debian root filesystem ก่อนจึงจะรัน Linux จริงได้"))
        col.addView(label("ธีมและการแสดงผล", 16f, ACCENT, true).apply { setPadding(0, dp(20), 0, dp(6)) })
        col.addView(label("ใช้โทนสี Material You และรองรับ Dynamic Color บนอุปกรณ์ Android ที่รองรับ", 13f, MUTED))
        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun infoCard(title: String, detail: String) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(15), dp(14), dp(15), dp(14))
        background = shape(CARD, 18, 1, OUTLINE)
        addView(label(title, 15f, ON_SURFACE, true))
        addView(label(detail, 13f, MUTED).apply { setPadding(0, dp(6), 0, 0) })
        layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(10) }
    }
}
