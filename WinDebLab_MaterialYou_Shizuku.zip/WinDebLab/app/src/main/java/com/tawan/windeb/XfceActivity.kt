package com.tawan.windeb

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.google.android.material.color.DynamicColors

/**
 * Shows the XFCE (macOS look) desktop inside the app: Xtigervnc + websockify/noVNC run in Debian,
 * and a WebView displays noVNC from 127.0.0.1.
 */
class XfceActivity : Activity() {
  private lateinit var web: WebView
  private lateinit var overlay: TextView
  private val ui = Handler(Looper.getMainLooper())
  @Volatile private var closed = false

  @SuppressLint("SetJavaScriptEnabled")
  override fun onCreate(savedInstanceState: Bundle?) {
    DynamicColors.applyToActivityIfAvailable(this)
    super.onCreate(savedInstanceState)
    val p = pal()
    styleBars(p)
    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)

    val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(p.bg) }

    val bar = LinearLayout(this).apply {
      orientation = LinearLayout.HORIZONTAL
      gravity = Gravity.CENTER_VERTICAL
      setPadding(dp(10), dp(6), dp(10), dp(6))
      setBackgroundColor(p.surface)
    }
    bar.addView(label("XFCE • macOS", 14f, p.text, true), LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
    fun btn(t: String, outlined: Boolean, click: () -> Unit) {
      bar.addView(mbtn(t, outlined).apply {
        minimumHeight = dp(38); minimumWidth = 0
        setPadding(dp(14), 0, dp(14), 0)
        setOnClickListener { click() }
      }, LinearLayout.LayoutParams(WRAP_CONTENT, dp(38)).apply { leftMargin = dp(6) })
    }
    btn("คีย์บอร์ด", true) { showKeyboard() }
    btn("หยุด", true) { Thread { Linux.stopDesktop() }.start(); finish() }
    btn("ซ่อน", false) { finish() }
    root.addView(bar, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

    val frame = FrameLayout(this)
    web = WebView(this).apply {
      setBackgroundColor(0xFF000000.toInt())
      settings.javaScriptEnabled = true
      settings.domStorageEnabled = true
      settings.mediaPlaybackRequiresUserGesture = false
      settings.useWideViewPort = true
      settings.loadWithOverviewMode = true
      webViewClient = WebViewClient()
      webChromeClient = WebChromeClient()
      visibility = View.INVISIBLE
    }
    frame.addView(web, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
    overlay = label("กำลังเตรียมเดสก์ท็อป…", 14f, p.text).apply {
      gravity = Gravity.CENTER
      setPadding(dp(24), dp(24), dp(24), dp(24))
    }
    frame.addView(overlay, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
    root.addView(frame, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
    setContentView(root)

    boot()
  }

  private fun say(msg: String) = ui.post { if (!closed) overlay.text = msg }

  private fun boot() {
    Thread {
      if (!Linux.shizukuReady()) { say("Shizuku ยังไม่พร้อม กลับไปหน้า Linux แล้วขอสิทธิ์ก่อน"); return@Thread }
      if (!Linux.desktopInstalled()) {
        say("ยังไม่ได้ติดตั้ง XFCE กลับไปหน้า Linux แล้วกด ติดตั้ง XFCE + ธีม macOS"); return@Thread
      }
      if (!Linux.desktopPortOpen()) {
        say("กำลังเริ่ม XFCE (ครั้งแรกอาจใช้ 20–60 วินาที)…")
        val dm = resources.displayMetrics
        val long = maxOf(dm.widthPixels, dm.heightPixels).toFloat()
        val short = minOf(dm.widthPixels, dm.heightPixels).toFloat()
        val w = minOf(long, 1600f).toInt() and 1.inv()
        val h = (w * short / long).toInt() and 1.inv()
        try { Linux.startDesktop("${w}x${h}") } catch (e: Throwable) { say("เริ่มเดสก์ท็อปไม่ได้: ${e.message}"); return@Thread }
      }
      var waited = 0
      while (!closed && !Linux.desktopPortOpen() && waited < 120) { Thread.sleep(1000); waited++ }
      if (closed) return@Thread
      if (!Linux.desktopPortOpen()) {
        say("เดสก์ท็อปไม่ตอบสนอง\n\n" + Linux.desktopLog.takeLast(800)); return@Thread
      }
      Thread.sleep(1500)
      ui.post {
        if (closed) return@post
        web.loadUrl("http://127.0.0.1:${Linux.NOVNC_PORT}/vnc.html?autoconnect=1&resize=scale&reconnect=1&reconnect_delay=1000")
        web.visibility = View.VISIBLE
        overlay.visibility = View.GONE
      }
    }.start()
  }

  private fun showKeyboard() {
    web.requestFocus()
    web.evaluateJavascript(
      "(function(){var b=document.getElementById('noVNC_keyboard_button');if(b){b.click();}})();", null
    )
    val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
    imm.showSoftInput(web, InputMethodManager.SHOW_IMPLICIT)
  }

  override fun onDestroy() {
    closed = true
    web.destroy()
    super.onDestroy()
  }
}
