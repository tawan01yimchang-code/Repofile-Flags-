WinDeb Lab 2.0 - Android / Kotlin

What changed in 2.0
- Real Debian Linux inside the app (proot), started through Shizuku. No Termux, no external terminal.
- Built-in terminal (TerminalActivity): bash with a real pty, colors, Tab / Ctrl+C / arrow keys.
- XFCE desktop with a macOS look (WhiteSur GTK theme, icons, cursors, Plank dock, top menu bar,
  traffic-light window buttons on the left, Inter font). It only starts when you tap "Start XFCE desktop".
  It is shown inside the app (Xtigervnc + noVNC + WebView on 127.0.0.1:6080).
- App shell uses Material You: colors follow the device (Dynamic Color, Android 12+).
  Desktop Simulator keeps its own fixed theme (not Material You).
- New app icon from the supplied logo, sized inside the adaptive-icon safe zone (plus themed monochrome layer).

How it works
Android does not let apps execute downloaded binaries, so everything runs as the ADB shell user through
Shizuku. Files live in /data/local/tmp/windeb (proot, rootfs, scripts). Shizuku must be running and
WinDeb Lab must be allowed in the Shizuku app.

First run
1. Start Shizuku (Wireless debugging or ADB), open Start Linux, tap "ตรวจสอบ / ขอสิทธิ์ Shizuku".
2. Tap "Start Linux": downloads proot + Debian bookworm rootfs (~30 MB) unless they are embedded
   (see app/src/main/assets/linux/README.txt), extracts them and tests the system.
3. Optional desktop: tap "ติดตั้ง XFCE + ธีม macOS". apt + git run in the terminal; expect ~300-500 MB
   download and ~1.5 GB of storage. Wait for "DONE".
4. Tap "Start XFCE desktop".

Build
1. Open this folder in Android Studio with JDK 17 (or use the GitHub Actions workflow).
2. Build > Build APK(s).

Rebuilding the Linux kit (scripts/config/wallpaper): edit files in tools/linux-kit/{host,guest}, then run
python3 tools/linux-kit/build-kit.py

Known limits
- Terminal has no full-screen apps (vim, nano, top, htop) - use the XFCE desktop for those.
- proot is slower than native Linux; the desktop is software-rendered (no GPU).
- Android 12+ may kill background shell processes: use Tools > "ปิด phantom process killer" in the Linux page.
- Needs internet on first run (apt, git clones for the macOS theme).
- This source was written without access to an Android SDK, so it has not been compiled or run on a device.
