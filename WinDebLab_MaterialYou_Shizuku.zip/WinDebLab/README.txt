WinDeb Lab 1.1 — Android / Kotlin

Design update:
- Material 3 theme with Android Dynamic Color support on Android 12+
- Emoji-free interface and adaptive Android launcher icon
- Redesigned home screen with Start Linux and Desktop Simulator as primary actions
- Shizuku permission connection screen for the Linux workflow
- Desktop Simulator remains an in-app experience

Build:
1. Open this folder in Android Studio with JDK 17.
2. Allow Gradle to resolve dependencies.
3. Build > Build APK(s).

Important Linux runtime status:
This revision removes the Termux command integration and adds Shizuku connection/permission handling.
It does NOT yet include an embedded proot executable or Debian root filesystem. Shizuku provides
ADB-shell command access; it does not itself provide a Linux distribution or desktop runtime.
Therefore Start Linux currently validates Shizuku access and reports that the embedded runtime
must be added. Do not treat this source revision as a working standalone Debian launcher yet.

Requirements:
- Android 8.0+ (API 26+)
- Android Studio / JDK 17 to build
- Android 12+ for system Dynamic Color where supported
- Shizuku app/service for the Shizuku permission workflow
