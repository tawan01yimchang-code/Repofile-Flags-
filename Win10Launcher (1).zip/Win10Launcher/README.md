# Win10 Launcher (Android, Kotlin + Compose)
Build: push to GitHub -> Actions "Build APK" (or `gradle assembleDebug`). Then:
1. Install, press Home, choose Win10 Launcher -> Always.
2. Long-press empty desktop: enable Accessibility, Notification access, Overlay permission, pick wallpaper / live wallpaper, switch icon pack.
