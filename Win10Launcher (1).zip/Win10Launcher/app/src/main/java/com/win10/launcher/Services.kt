package com.win10.launcher
import android.accessibilityservice.AccessibilityService
import android.graphics.*
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.service.wallpaper.WallpaperService
import android.view.accessibility.AccessibilityEvent
import androidx.compose.runtime.mutableStateListOf

class NotifService : NotificationListenerService() {
    companion object { val items = mutableStateListOf<Triple<String, String, String>>() }
    private fun sync() {
        try { items.clear(); activeNotifications.filter { it.isClearable }.forEach {
            val e = it.notification.extras
            items.add(Triple(it.packageName, e.getCharSequence("android.title")?.toString() ?: "", e.getCharSequence("android.text")?.toString() ?: "")) } } catch (_: Throwable) {}
    }
    override fun onListenerConnected() = sync()
    override fun onNotificationPosted(s: StatusBarNotification?) = sync()
    override fun onNotificationRemoved(s: StatusBarNotification?) = sync()
}

class A11y : AccessibilityService() {
    companion object { var inst: A11y? = null }
    override fun onServiceConnected() { inst = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(i: android.content.Intent?): Boolean { inst = null; return super.onUnbind(i) }
}

class LiveWall : WallpaperService() {
    override fun onCreateEngine() = object : Engine() {
        val h = Handler(Looper.getMainLooper()); var t = 0f; var on = false
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val run = object : Runnable { override fun run() { draw(); if (on) h.postDelayed(this, 33) } }
        fun draw() {
            val hd = surfaceHolder; val c = hd.lockCanvas() ?: return
            val w = c.width.toFloat(); val ht = c.height.toFloat(); t += 0.02f
            p.shader = LinearGradient(0f, 0f, w, ht, 0xFF001E4D.toInt(), 0xFF0078D7.toInt(), Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w, ht, p); p.shader = null
            for (i in 0..4) { p.color = Color.argb(28, 255, 255, 255)
                val a = Math.sin((t + i).toDouble()).toFloat()
                val path = Path().apply { moveTo(w * (0.5f + 0.1f * a), ht * 0.5f); lineTo(w * (0.2f * i + a * 0.1f), ht); lineTo(w * (0.2f * i + 0.35f), ht); close() }
                c.drawPath(path, p) }
            hd.unlockCanvasAndPost(c)
        }
        override fun onVisibilityChanged(v: Boolean) { on = v; h.removeCallbacks(run); if (v) h.post(run) }
        override fun onDestroy() { on = false; h.removeCallbacks(run) }
    }
}
