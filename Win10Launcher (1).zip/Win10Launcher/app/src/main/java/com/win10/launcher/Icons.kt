package com.win10.launcher
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

private fun st(w: Float) = Stroke(w * 0.09f, cap = StrokeCap.Round, join = StrokeJoin.Round)

@Composable fun IcSearch(c: Color = Color.White, s: Dp = 18.dp) = Canvas(Modifier.size(s)) {
    val w = size.width
    drawCircle(c, w * 0.3f, Offset(w * 0.62f, w * 0.38f), style = st(w))
    drawLine(c, Offset(w * 0.4f, w * 0.6f), Offset(w * 0.1f, w * 0.9f), w * 0.09f, StrokeCap.Round) }

@Composable fun IcWifi(c: Color = Color.White, s: Dp = 18.dp) = Canvas(Modifier.size(s)) {
    val w = size.width; val cx = w / 2; val cy = w * 0.85f
    for (r in listOf(0.3f, 0.55f, 0.8f)) drawArc(c, -135f, 90f, false, Offset(cx - w * r, cy - w * r), Size(w * r * 2, w * r * 2), style = st(w))
    drawCircle(c, w * 0.06f, Offset(cx, cy)) }

@Composable fun IcVolume(c: Color = Color.White, s: Dp = 18.dp) = Canvas(Modifier.size(s)) {
    val w = size.width
    drawPath(Path().apply { moveTo(.1f * w, .4f * w); lineTo(.3f * w, .4f * w); lineTo(.55f * w, .2f * w); lineTo(.55f * w, .8f * w); lineTo(.3f * w, .6f * w); lineTo(.1f * w, .6f * w); close() }, c)
    for (r in listOf(0.2f, 0.36f)) drawArc(c, -45f, 90f, false, Offset(.55f * w - w * r, .5f * w - w * r), Size(w * r * 2, w * r * 2), style = st(w)) }

@Composable fun IcBattery(level: Int, charging: Boolean, c: Color = Color.White, s: Dp = 22.dp) = Canvas(Modifier.size(s)) {
    val w = size.width
    drawRect(c, Offset(.05f * w, .28f * w), Size(.78f * w, .44f * w), style = Stroke(w * 0.06f))
    drawRect(c, Offset(.85f * w, .42f * w), Size(.08f * w, .16f * w))
    drawRect(if (level < 20 && !charging) Color(0xFFE81123) else c, Offset(.1f * w, .33f * w), Size(.68f * w * level.coerceIn(0, 100) / 100f, .34f * w))
    if (charging) drawPath(Path().apply { moveTo(.5f * w, .3f * w); lineTo(.38f * w, .52f * w); lineTo(.48f * w, .52f * w); lineTo(.42f * w, .72f * w); lineTo(.62f * w, .46f * w); lineTo(.52f * w, .46f * w); close() }, Color(0xFF202020)) }

@Composable fun IcChat(c: Color = Color.White, s: Dp = 18.dp) = Canvas(Modifier.size(s)) {
    val w = size.width
    drawRect(c, Offset(.1f * w, .15f * w), Size(.8f * w, .55f * w), style = st(w))
    drawPath(Path().apply { moveTo(.3f * w, .7f * w); lineTo(.3f * w, .88f * w); lineTo(.48f * w, .7f * w) }, c, style = st(w)) }

@Composable fun IcChevron(c: Color = Color.White, s: Dp = 14.dp) = Canvas(Modifier.size(s)) {
    val w = size.width
    drawPath(Path().apply { moveTo(.2f * w, .65f * w); lineTo(.5f * w, .35f * w); lineTo(.8f * w, .65f * w) }, c, style = st(w)) }

@Composable fun IcGear(c: Color = Color.White, s: Dp = 20.dp) = Canvas(Modifier.size(s)) {
    val w = size.width; val m = Offset(w / 2, w / 2)
    drawCircle(c, w * 0.2f, m, style = st(w))
    for (i in 0..7) { val a = Math.toRadians(i * 45.0); val ca = Math.cos(a).toFloat(); val sa = Math.sin(a).toFloat()
        drawLine(c, Offset(m.x + ca * w * .3f, m.y + sa * w * .3f), Offset(m.x + ca * w * .42f, m.y + sa * w * .42f), w * 0.1f, StrokeCap.Round) } }

@Composable fun IcPower(c: Color = Color.White, s: Dp = 20.dp) = Canvas(Modifier.size(s)) {
    val w = size.width
    drawArc(c, -60f, 300f, false, Offset(.2f * w, .25f * w), Size(.6f * w, .6f * w), style = st(w))
    drawLine(c, Offset(.5f * w, .1f * w), Offset(.5f * w, .5f * w), w * 0.09f, StrokeCap.Round) }

@Composable fun IcSun(c: Color = Color.White, s: Dp = 18.dp) = Canvas(Modifier.size(s)) {
    val w = size.width; val m = Offset(w / 2, w / 2)
    drawCircle(c, w * 0.16f, m, style = st(w))
    for (i in 0..7) { val a = Math.toRadians(i * 45.0); val ca = Math.cos(a).toFloat(); val sa = Math.sin(a).toFloat()
        drawLine(c, Offset(m.x + ca * w * .28f, m.y + sa * w * .28f), Offset(m.x + ca * w * .42f, m.y + sa * w * .42f), w * 0.07f, StrokeCap.Round) } }
