package com.win10.launcher
import android.app.ActivityOptions
import android.content.*
import android.graphics.Rect
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.Settings
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.*
import androidx.compose.ui.text.font.FontWeight
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

fun Modifier.acrylic() = this.background(Brush.verticalGradient(listOf(Color(0xE8323232), Color(0xE61E1E1E)))).border(1.dp, Color(0x33FFFFFF))
fun blur(a: android.app.Activity, r: Int) { if (android.os.Build.VERSION.SDK_INT >= 31) try { a.window.setBackgroundBlurRadius(r) } catch (_: Throwable) {} }
val Blue = Color(0xFF0078D7); val Dark = Color(0xF21F1F1F); val Panel = Color(0xF0282828)
data class AppItem(val label: String, val pkg: String, val icon: ImageBitmap)

class MainActivity : ComponentActivity() {
    var locked by mutableStateOf(true); var tick by mutableIntStateOf(0); var hideBars = true
    private val rx = object : BroadcastReceiver() { override fun onReceive(c: Context?, i: Intent?) { locked = true } }
    override fun onCreate(b: Bundle?) {
        super.onCreate(b); WindowCompat.setDecorFitsSystemWindows(window, false)
        hideBars = getSharedPreferences("p", 0).getBoolean("hide", true)
        registerReceiver(rx, IntentFilter(Intent.ACTION_SCREEN_OFF))
        setContent { Root(this) }
    }
    override fun onResume() { super.onResume(); tick++; bars(hideBars) }
    override fun onDestroy() { unregisterReceiver(rx); super.onDestroy() }
    fun bars(h: Boolean) { hideBars = h; val c = WindowInsetsControllerCompat(window, window.decorView)
        if (h) c.hide(WindowInsetsCompat.Type.statusBars()) else c.show(WindowInsetsCompat.Type.statusBars()) }
}

fun loadApps(c: Context, order: List<String>): List<AppItem> {
    val pm = c.packageManager
    val l = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        .filter { it.activityInfo.packageName != c.packageName }
        .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm).toBitmap(96, 96).asImageBitmap()) }
        .distinctBy { it.pkg }.sortedBy { it.label.lowercase() }
    return l.sortedBy { val i = order.indexOf(it.pkg); if (i < 0) Int.MAX_VALUE else i }
}

/** mode 0 normal, 1 popup window, 2 maximized (not fullscreen), 3 fullscreen + caption buttons */
fun launch(c: Context, pkg: String, mode: Int) {
    val i = c.packageManager.getLaunchIntentForPackage(pkg) ?: return
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    val d = c.resources.displayMetrics; val w = d.widthPixels; val h = d.heightPixels; val tb = (48 * d.density).toInt()
    val o = ActivityOptions.makeBasic()
    if (mode == 1 || mode == 2) {
        val ok = c.packageManager.hasSystemFeature("android.software.freeform_window_management") ||
            Settings.Global.getInt(c.contentResolver, "enable_freeform_support", 0) == 1
        if (!ok) android.widget.Toast.makeText(c, "เครื่องนี้ยังไม่เปิดหน้าต่างลอย (Freeform) — อาจเปิดเต็มจอแทน", android.widget.Toast.LENGTH_LONG).show()
        o.setLaunchBounds(if (mode == 1) Rect(w / 8, h / 6, w * 7 / 8, h * 5 / 6) else Rect(0, 0, w, h - tb))
        try { ActivityOptions::class.java.getMethod("setLaunchWindowingMode", Int::class.java).invoke(o, 5) } catch (_: Throwable) {}
    }
    if (mode == 3) { if (Settings.canDrawOverlays(c)) Overlay.show(c)
        else c.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${c.packageName}")).addFlags(268435456)) }
    c.startActivity(i, o.toBundle())
}
fun sys(c: Context, a: String) = try { c.startActivity(Intent(a).addFlags(268435456)) } catch (_: Throwable) {}

@Composable fun Glyph(s: Boolean = true) = Canvas(Modifier.size(18.dp)) {
    val g = size.width * 0.06f; val q = (size.width - g) / 2
    for (x in 0..1) for (y in 0..1) drawRect(Color.White, Offset(x * (q + g), y * (q + g)), androidx.compose.ui.geometry.Size(q, q)) }

@Composable fun Ico(a: AppItem, shape: Int, size: Dp) {
    val m = Modifier.size(size)
    when (shape) {
        0 -> Box(m.background(Blue), Alignment.Center) { Image(a.icon, null, Modifier.size(size * 0.62f)) }
        1 -> Image(a.icon, null, m.clip(RoundedCornerShape(size * 0.22f)).background(Color(0x33FFFFFF)))
        2 -> Image(a.icon, null, m.clip(CircleShape).background(Color(0x33FFFFFF)))
        else -> Image(a.icon, null, m)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable fun Press(onClick: () -> Unit, onLong: () -> Unit = {}, mod: Modifier = Modifier, content: @Composable () -> Unit) {
    val src = remember { MutableInteractionSource() }; val p by src.collectIsPressedAsState()
    val s by animateFloatAsState(if (p) 0.86f else 1f, spring(0.45f, 600f), label = "s")
    Box(mod.scale(s).combinedClickable(src, null, onClick = onClick, onLongClick = onLong)) { content() }
}

@Composable fun Root(a: MainActivity) {
    val c: Context = a; val sp = remember { c.getSharedPreferences("p", 0) }
    fun list(k: String) = sp.getString(k, "")!!.split(",").filter { it.isNotEmpty() }
    var order by remember { mutableStateOf(list("order")) }
    var apps by remember { mutableStateOf(emptyList<AppItem>()) }
    var pins by remember { mutableStateOf(list("pins")) }
    var shape by remember { mutableIntStateOf(sp.getInt("shape", 0)) }
    var dm by remember { mutableIntStateOf(sp.getInt("dm", 0)) }
    var hide by remember { mutableStateOf(sp.getBoolean("hide", true)) }
    var start by remember { mutableStateOf(false) }; var ac by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf<AppItem?>(null) }; var desk by remember { mutableStateOf(false) }
    var moving by remember { mutableStateOf<AppItem?>(null) }; var q by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf(sp.getString("pin", "")!!) }
    var setPin by remember { mutableIntStateOf(0) }; var tmp by remember { mutableStateOf("") }
    var entry by remember { mutableStateOf("") }; var wrong by remember { mutableStateOf(false) }; var showPad by remember { mutableStateOf(false) }
    LaunchedEffect(a.locked) { if (a.locked) { showPad = false; entry = ""; wrong = false } }
    LaunchedEffect(a.locked && showPad) { blur(a, if (a.locked && showPad) 60 else 0) }
    fun digit(d: String) { if (entry.length < 4) { entry += d; wrong = false
        if (entry.length == 4) {
            if (setPin == 1) { tmp = entry; entry = ""; setPin = 2 }
            else if (setPin == 2) { if (entry == tmp) { pin = entry; sp.edit().putString("pin", pin).apply(); setPin = 0 } else { wrong = true; setPin = 1 }; entry = "" }
            else { if (entry == pin) { a.locked = false; showPad = false } else wrong = true; entry = "" } } } }
    LaunchedEffect(a.tick) { apps = loadApps(c, order) }
    LaunchedEffect(hide) { a.bars(hide); sp.edit().putBoolean("hide", hide).apply() }
    fun savePins(l: List<String>) { pins = l; sp.edit().putString("pins", l.joinToString(",")).apply() }
    BackHandler(start || ac) { start = false; ac = false }

    val time by produceState(Date()) { while (true) { value = Date(); delay(1000) } }
    val bat by produceState(0 to false) { while (true) {
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val l = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        value = l to ((i?.getIntExtra(BatteryManager.EXTRA_STATUS, 0) ?: 0) == BatteryManager.BATTERY_STATUS_CHARGING); delay(5000) } }

    @Composable fun AppMenu(x: AppItem) = DropdownMenu(true, { menu = null }, containerColor = Panel) {
        @Composable fun it(t: String, f: () -> Unit) = DropdownMenuItem({ Text(t, color = Color.White) }, { menu = null; f() })
        it("เปิด") { launch(c, x.pkg, 0); start = false }
        it("เปิดแบบป๊อปอัป") { launch(c, x.pkg, 1); start = false }
        it("ขยายสุด (ไม่เต็มจอ)") { launch(c, x.pkg, 2); start = false }
        it("เต็มจอ + ปุ่ม — ▢ ✕") { launch(c, x.pkg, 3); start = false }
        it(if (x.pkg in pins) "เลิกปักหมุดจากทาสก์บาร์" else "ปักหมุดที่ทาสก์บาร์") { savePins(if (x.pkg in pins) pins - x.pkg else pins + x.pkg) }
        it("ย้ายแอป (แตะแอปปลายทาง)") { moving = x }
        it("ข้อมูลแอป") { c.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${x.pkg}")).addFlags(268435456)) }
        it("ถอนการติดตั้ง") { c.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${x.pkg}")).addFlags(268435456)) }
    }

    Box(Modifier.fillMaxSize().background(Color(0x22000000))) {
        // Desktop
        Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures(onTap = { start = false; ac = false; moving = null }, onLongPress = { desk = true }) })
        LazyVerticalGrid(GridCells.Adaptive(84.dp), Modifier.fillMaxSize(),
            contentPadding = PaddingValues(8.dp, 40.dp, 8.dp, 70.dp)) {
            items(apps, key = { it.pkg }) { x ->
                Box(Modifier.animateItem()) {
                    Press({ val m = moving
                        if (m != null) { val l = apps.map { it.pkg }.toMutableList(); val i = l.indexOf(m.pkg); val j = l.indexOf(x.pkg)
                            l.removeAt(i); l.add(j, m.pkg); order = l; sp.edit().putString("order", l.joinToString(",")).apply(); apps = loadApps(c, l); moving = null }
                        else launch(c, x.pkg, dm) }, { menu = x }, Modifier.padding(6.dp)) {
                        Column(Modifier.width(72.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Ico(x, shape, 52.dp)
                            Text(x.label, color = Color.White, fontSize = 11.sp, maxLines = 2, lineHeight = 13.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center) } }
                    if (menu == x && !start) AppMenu(x)
                }
            }
        }
        DropdownMenu(desk, { desk = false }, Modifier.align(Alignment.Center), containerColor = Panel) {
            @Composable fun it(t: String, f: () -> Unit) = DropdownMenuItem({ Text(t, color = Color.White) }, { desk = false; f() })
            it("เปลี่ยนวอลเปเปอร์") { c.startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper").addFlags(268435456)) }
            it("วอลเปเปอร์เคลื่อนไหว (Win10 Beam)") { c.startActivity(Intent(android.app.WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
                .putExtra(android.app.WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, ComponentName(c, LiveWall::class.java)).addFlags(268435456)) }
            it("ไอคอนแพ็ก: ${listOf("Win10 Tile", "Rounded", "Circle", "Original")[shape]} (แตะเพื่อสลับ)") { shape = (shape + 1) % 4; sp.edit().putInt("shape", shape).apply() }
            it("โหมดแตะเปิดแอป: ${listOf("ธรรมดา", "ป๊อปอัป", "ขยายสุด (ไม่เต็มจอ)", "เต็มจอ + ปุ่ม — ▢ ✕")[dm]} (แตะเพื่อสลับ)") { dm = (dm + 1) % 4; sp.edit().putInt("dm", dm).apply() }
            it(if (hide) "แสดงแถบสถานะ" else "ซ่อนแถบสถานะ") { hide = !hide }
            it("ตั้งเป็น Launcher หลัก") { sys(c, Settings.ACTION_HOME_SETTINGS) }
            it("เปิดการเข้าถึง (API เต็มตัว)") { sys(c, Settings.ACTION_ACCESSIBILITY_SETTINGS) }
            it("สิทธิ์อ่านการแจ้งเตือน") { sys(c, "android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS") }
            it("สิทธิ์แสดงทับแอปอื่น") { c.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${c.packageName}")).addFlags(268435456)) }
            it(if (pin.isEmpty()) "ตั้งรหัส PIN หน้าจอล็อก" else "เปลี่ยนรหัส PIN") { entry = ""; wrong = false; setPin = 1 }
            if (pin.isNotEmpty()) it("ลบรหัส PIN") { pin = ""; sp.edit().remove("pin").apply() }
            it("ล็อกหน้าจอ") { a.locked = true }
        }
        if (start || ac) Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { start = false; ac = false } })

        // Start menu (spring scale like macOS)
        val sw = (LocalContext.current.resources.displayMetrics.widthPixels / LocalContext.current.resources.displayMetrics.density).dp
        AnimatedVisibility(start, Modifier.align(Alignment.BottomStart).padding(bottom = 48.dp),
            enter = scaleIn(spring(0.6f, 350f), 0.88f, TransformOrigin(0.05f, 1f)) + slideInVertically(spring(0.7f, 300f)) { it / 4 } + fadeIn(),
            exit = scaleOut(tween(160), 0.92f, TransformOrigin(0.05f, 1f)) + fadeOut(tween(140))) {
            Row(Modifier.width(minOf(sw - 8.dp, 620.dp)).height(480.dp).acrylic()) {
                Column(Modifier.width(48.dp).fillMaxHeight(), verticalArrangement = Arrangement.Bottom) {
                    listOf("⚙" to { sys(c, Settings.ACTION_SETTINGS) }, "⏻" to { a.locked = true; start = false }).forEach { (g, f) ->
                        Box(Modifier.size(48.dp).clickable { f() }, Alignment.Center) { if (g == "⚙") IcGear() else IcPower() } } }
                Column(Modifier.weight(1f).padding(top = 8.dp)) {
                    BasicTextField(q, { q = it }, Modifier.fillMaxWidth().padding(8.dp, 0.dp).background(Color(0xFF3A3A3A)).padding(10.dp),
                        textStyle = androidx.compose.ui.text.TextStyle(Color.White, 14.sp), cursorBrush = SolidColor(Blue),
                        decorationBox = { f -> if (q.isEmpty()) Text("พิมพ์ที่นี่เพื่อค้นหา", color = Color.Gray, fontSize = 14.sp); f() })
                    LazyColumn { val gr = apps.filter { it.label.contains(q, true) }.sortedBy { it.label.lowercase() }
                        .groupBy { val ch = it.label.first().uppercaseChar(); if (ch.isLetter()) ch.toString() else "#" }.toSortedMap()
                        gr.forEach { (k, v) -> item(key = "h$k") { Text(k, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(12.dp, 10.dp, 0.dp, 2.dp)) }
                        items(v, key = { it.pkg }) { x ->
                        Box { Press({ launch(c, x.pkg, dm); start = false }, { menu = x }, Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(10.dp, 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Ico(x, shape, 32.dp); Spacer(Modifier.width(12.dp)); Text(x.label, color = Color.White, fontSize = 14.sp) } }
                            if (menu == x && start) AppMenu(x) } } } }
                }
                LazyVerticalGrid(GridCells.Fixed(2), Modifier.weight(1f).padding(8.dp), horizontalArrangement = Arrangement.spacedBy(4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(apps.filter { it.pkg in pins }, key = { it.pkg }) { x ->
                        Press({ launch(c, x.pkg, dm); start = false }, { menu = x }, Modifier.fillMaxWidth().aspectRatio(1f).background(Blue)) {
                            Column(Modifier.fillMaxSize().padding(8.dp), Arrangement.SpaceBetween) { Image(x.icon, null, Modifier.size(40.dp)); Text(x.label, color = Color.White, fontSize = 11.sp, maxLines = 1) } } } }
            }
        }

        // Action center
        AnimatedVisibility(ac, Modifier.align(Alignment.BottomEnd).padding(bottom = 48.dp),
            enter = slideInHorizontally(spring(0.75f, 320f)) { it } + fadeIn(), exit = slideOutHorizontally(tween(180)) { it } + fadeOut()) {
            val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            Column(Modifier.width(minOf(sw, 340.dp)).fillMaxHeight(0.85f).acrylic().padding(12.dp)) {
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                    Text("การแจ้งเตือน", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("ล้างทั้งหมด", color = Color(0xFF7FBAFF), fontSize = 12.sp, modifier = Modifier.clickable { A11yClear() }) }
                LazyColumn(Modifier.weight(1f).padding(vertical = 8.dp)) {
                    if (NotifService.items.isEmpty()) item { Text("ไม่มีการแจ้งเตือนใหม่", color = Color.Gray, modifier = Modifier.padding(8.dp)) }
                    items(NotifService.items) { n -> Column(Modifier.fillMaxWidth().padding(vertical = 3.dp).background(Color(0xFF3A3A3A)).padding(10.dp)) {
                        Text(n.first.substringAfterLast('.'), color = Color.Gray, fontSize = 10.sp)
                        Text(n.second, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                        Text(n.third, color = Color(0xFFCCCCCC), fontSize = 12.sp, maxLines = 2) } } }
                IcVolume(); var vol by remember { mutableFloatStateOf(am.getStreamVolume(3).toFloat() / am.getStreamMaxVolume(3)) }
                Slider(vol, { vol = it; am.setStreamVolume(3, (it * am.getStreamMaxVolume(3)).toInt(), 0) }, colors = SliderDefaults.colors(thumbColor = Blue, activeTrackColor = Blue))
                IcSun(); var br by remember { mutableFloatStateOf(0.8f) }
                Slider(br, { br = it; val at = a.window.attributes; at.screenBrightness = it.coerceIn(0.02f, 1f); a.window.attributes = at }, colors = SliderDefaults.colors(thumbColor = Blue, activeTrackColor = Blue))
                LazyVerticalGrid(GridCells.Fixed(4), Modifier.height(130.dp), horizontalArrangement = Arrangement.spacedBy(4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(listOf("Wi-Fi" to Settings.ACTION_WIFI_SETTINGS, "Bluetooth" to Settings.ACTION_BLUETOOTH_SETTINGS, "Airplane" to Settings.ACTION_AIRPLANE_MODE_SETTINGS,
                        "Location" to Settings.ACTION_LOCATION_SOURCE_SETTINGS, "Display" to Settings.ACTION_DISPLAY_SETTINGS, "Sound" to Settings.ACTION_SOUND_SETTINGS,
                        "Battery" to Intent.ACTION_POWER_USAGE_SUMMARY, "All settings" to Settings.ACTION_SETTINGS)) { (n, act) ->
                        Box(Modifier.aspectRatio(1.3f).background(Blue).clickable { sys(c, act) }.padding(4.dp), Alignment.Center) { Text(n, color = Color.White, fontSize = 10.sp) } } }
            }
        }

        // Taskbar
        Row(Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xF0252525), Color(0xF21A1A1A)))).navigationBarsPadding().height(48.dp), verticalAlignment = Alignment.CenterVertically) {
            Press({ start = !start; ac = false; q = "" }, mod = Modifier.size(48.dp)) { Box(Modifier.fillMaxSize(), Alignment.Center) { Glyph() } }
            if (sw > 520.dp) Row(Modifier.width(190.dp).height(34.dp).background(Color(0xFFF2F2F2)).clickable { start = true }.padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                IcSearch(Color(0xFF444444), 16.dp); Spacer(Modifier.width(8.dp)); Text("พิมพ์ที่นี่เพื่อค้นหา", color = Color(0xFF555555), fontSize = 12.sp, maxLines = 1) }
            else Box(Modifier.size(48.dp).clickable { start = true }, Alignment.Center) { IcSearch() }
            Row(Modifier.weight(1f).horizontalScroll(rememberScrollState())) {
                apps.filter { it.pkg in pins }.forEach { x -> Box {
                    Press({ launch(c, x.pkg, dm) }, { menu = x }, Modifier.size(48.dp)) { Box(Modifier.fillMaxSize(), Alignment.Center) { Ico(x, shape, 30.dp) } }
                    Box(Modifier.align(Alignment.BottomCenter).width(16.dp).height(2.dp).background(Blue))
                    if (menu == x && !start) AppMenu(x) } } }
            var tray by remember { mutableStateOf(false) }
            Box { Box(Modifier.size(32.dp, 48.dp).clickable { tray = true }, Alignment.Center) { IcChevron() }
                DropdownMenu(tray, { tray = false }, containerColor = Panel) {
                    listOf("การเข้าถึง" to Settings.ACTION_ACCESSIBILITY_SETTINGS, "สิทธิ์การแจ้งเตือน" to "android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS", "ตั้งค่า" to Settings.ACTION_SETTINGS)
                        .forEach { (t, act) -> DropdownMenuItem({ Text(t, color = Color.White) }, { tray = false; sys(c, act) }) } } }
            Box(Modifier.size(30.dp, 48.dp).clickable { sys(c, Settings.ACTION_WIFI_SETTINGS) }, Alignment.Center) { IcWifi() }
            Box(Modifier.size(30.dp, 48.dp).clickable { ac = !ac; start = false }, Alignment.Center) { IcVolume() }
            Box(Modifier.size(34.dp, 48.dp).clickable { sys(c, Intent.ACTION_POWER_USAGE_SUMMARY) }, Alignment.Center) { IcBattery(bat.first, bat.second) }
            Column(Modifier.padding(horizontal = 6.dp), horizontalAlignment = Alignment.End) {
                Text(SimpleDateFormat("h:mm a", Locale.getDefault()).format(time), color = Color.White, fontSize = 11.sp)
                Text(SimpleDateFormat("d/M/yyyy", Locale.getDefault()).format(time), color = Color.White, fontSize = 11.sp) }
            Box(Modifier.size(48.dp).clickable { ac = !ac; start = false }, Alignment.Center) { Box(contentAlignment = Alignment.Center) { IcChat(if (NotifService.items.isEmpty()) Color.White else Color(0xFF7FBAFF), 20.dp)
                if (NotifService.items.isNotEmpty()) Text("${NotifService.items.size}", color = Color.White, fontSize = 8.sp, modifier = Modifier.padding(bottom = 3.dp)) } }
            Box(Modifier.width(4.dp).fillMaxHeight().clickable { a.startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)) }) // Show desktop
        }

        // Lock screen (Windows 10 style)
        var off by remember { mutableFloatStateOf(0f) }
        val animOff by animateFloatAsState(if (a.locked) off else -3000f, spring(0.8f, 250f), label = "lock")
        if (animOff > -2999f) Box(Modifier.fillMaxSize().graphicsLayer { translationY = animOff }.background(Color(0xCC001A38))
            .pointerInput(Unit) { detectVerticalDragGestures(onDragEnd = { if (off < -300f) { if (pin.isEmpty()) a.locked = false else showPad = true }; off = 0f }) { _, d -> off = (off + d).coerceAtMost(0f) } }) {
            Column(Modifier.align(Alignment.BottomStart).padding(40.dp, 40.dp, 40.dp, 90.dp)) {
                Text(SimpleDateFormat("HH:mm", Locale.getDefault()).format(time), color = Color.White, fontSize = 84.sp, fontWeight = FontWeight.Light)
                Text(SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(time), color = Color.White, fontSize = 26.sp)
                Spacer(Modifier.height(12.dp)); Row(verticalAlignment = Alignment.CenterVertically) { IcBattery(bat.first, bat.second); Text(" ${bat.first}%", color = Color.White)
                    Spacer(Modifier.width(18.dp)); IcChat(); Text(" ${NotifService.items.size}", color = Color.White) } }
            Text("ปัดขึ้นเพื่อปลดล็อก", color = Color(0xAAFFFFFF), modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 36.dp))
        }
        if (setPin > 0) PinPad(if (setPin == 1) "ตั้งรหัส PIN 4 หลัก" else "ยืนยันรหัส PIN อีกครั้ง", entry.length, wrong, ::digit, { entry = entry.dropLast(1) }, { setPin = 0; entry = "" })
        else if (a.locked && showPad) PinPad("ใส่รหัส PIN", entry.length, wrong, ::digit, { entry = entry.dropLast(1) }, { showPad = false; entry = "" })
    }
}

@Composable fun PinPad(title: String, len: Int, wrong: Boolean, onKey: (String) -> Unit, onBack: () -> Unit, onCancel: () -> Unit) {
    Column(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { } }.background(Color(0xF0001A38)), Arrangement.Center, Alignment.CenterHorizontally) {
        Text(title, color = Color.White, fontSize = 20.sp)
        Row(Modifier.padding(20.dp)) { repeat(4) { Box(Modifier.padding(6.dp).size(14.dp).clip(CircleShape).background(if (it < len) Color.White else Color(0x55FFFFFF))) } }
        Text(if (wrong) "รหัสไม่ถูกต้อง" else " ", color = Color(0xFFFF6B6B))
        listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("ยกเลิก", "0", "⌫")).forEach { r ->
            Row { r.forEach { k -> Box(Modifier.padding(6.dp).size(72.dp).background(Color(0x33FFFFFF)).clickable {
                when (k) { "ยกเลิก" -> onCancel(); "⌫" -> onBack(); else -> onKey(k) } }, Alignment.Center) {
                Text(k, color = Color.White, fontSize = if (k.length > 1) 13.sp else 24.sp) } } } }
    }
}
fun A11yClear() { /* notifications cleared via listener */ NotifService.items.clear() }
