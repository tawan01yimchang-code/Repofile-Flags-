package com.win10.launcher
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.accessibilityservice.AccessibilityService

/** Windows-style caption buttons (— ▢ ✕) pinned top-right over fullscreen apps */
object Overlay {
    private var bar: View? = null
    fun show(c: Context) {
        if (bar != null || !Settings.canDrawOverlays(c)) return
        val wm = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val row = LinearLayout(c).apply { setBackgroundColor(0xCC202020.toInt()) }
        fun btn(t: String, bg: Int, f: () -> Unit) = TextView(c).apply {
            text = t; setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER
            setPadding(44, 18, 44, 18); setOnClickListener { f() }
            setOnTouchListener { v, e -> v.setBackgroundColor(if (e.action == 0) bg else 0); false }
        }
        row.addView(btn("—", 0x44FFFFFF) { A11y.inst?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME); hide(c) })
        row.addView(btn("▢", 0x44FFFFFF) { A11y.inst?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS) })
        row.addView(btn("✕", 0xFFE81123.toInt()) { A11y.inst?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK); hide(c) })
        val lp = WindowManager.LayoutParams(-2, -2, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.END }
        wm.addView(row, lp); bar = row
    }
    fun hide(c: Context) { bar?.let { (c.getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(it) }; bar = null }
}
